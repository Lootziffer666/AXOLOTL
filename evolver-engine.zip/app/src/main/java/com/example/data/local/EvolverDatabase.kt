package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [SnapshotEntity::class, RuntimeLogEntity::class, LLMConfigEntity::class],
    version = 1,
    exportSchema = false
)
abstract class EvolverDatabase : RoomDatabase() {

    abstract fun evolverDao(): EvolverDao

    companion object {
        @Volatile
        private var INSTANCE: EvolverDatabase? = null

        fun getDatabase(context: Context): EvolverDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    EvolverDatabase::class.java,
                    "evolver_engine_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
