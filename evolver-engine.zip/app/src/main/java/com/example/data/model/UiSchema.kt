package com.example.data.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class UiSchema(
    val title: String = "Evolver Engine",
    val version: String = "v4.2.0-Alpha (Self-Healing)",
    val integrityScore: Double = 99.8,
    val layout: UiComponent = defaultLayout()
) {
    companion object {
        fun defaultLayout(): UiComponent = UiComponent(
            type = "CONTAINER",
            id = "root_container",
            children = listOf(
                UiComponent(
                    type = "PULSE_RING",
                    id = "main_pulse",
                    label = "INTEGRITY",
                    value = "99.8%"
                ),
                UiComponent(
                    type = "LOG_STREAM",
                    id = "main_log_stream",
                    label = "RUNTIME_LOG"
                ),
                UiComponent(
                    type = "ROW",
                    id = "metrics_row",
                    children = listOf(
                        UiComponent(
                            type = "METRIC_CARD",
                            id = "metric_active_modules",
                            label = "ACTIVE MODULES",
                            value = "4",
                            unit = "Active",
                            accentColor = "cyan",
                            icon = "code"
                        ),
                        UiComponent(
                            type = "METRIC_CARD",
                            id = "metric_patch_status",
                            label = "HMR RELOAD",
                            value = "0ms",
                            unit = "Latency",
                            accentColor = "emerald",
                            icon = "bolt"
                        )
                    )
                ),
                UiComponent(
                    type = "CUSTOM_CARD",
                    id = "controls_card",
                    label = "EVOLUTION CONTROL",
                    children = listOf(
                        UiComponent(
                            type = "TOGGLE_SWITCH",
                            id = "toggle_self_healing",
                            label = "Auto Self-Healing Loop",
                            isChecked = true,
                            action = "TOGGLE_SELF_HEALING"
                        ),
                        UiComponent(
                            type = "TOGGLE_SWITCH",
                            id = "toggle_sandbox",
                            label = "Wasm Security Sandbox",
                            isChecked = true,
                            action = "TOGGLE_SANDBOX"
                        ),
                        UiComponent(
                            type = "ACTION_BUTTON",
                            id = "btn_repair_engine",
                            label = "Trigger Self-Healing Test",
                            action = "TRIGGER_REPAIR",
                            accentColor = "cyan",
                            icon = "bolt"
                        )
                    )
                )
            )
        )
    }
}

@JsonClass(generateAdapter = true)
data class UiComponent(
    val type: String, // CONTAINER, PULSE_RING, LOG_STREAM, METRIC_CARD, ACTION_BUTTON, TOGGLE_SWITCH, TEXT, BADGE, CUSTOM_CARD, ROW
    val id: String,
    val label: String? = null,
    val value: String? = null,
    val unit: String? = null,
    val subtext: String? = null,
    val accentColor: String? = "cyan",
    val icon: String? = null,
    val isChecked: Boolean? = null,
    val action: String? = null,
    val children: List<UiComponent>? = null
)
