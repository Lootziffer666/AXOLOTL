package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface EvolverDao {

    // --- Snapshots ---
    @Query("SELECT * FROM snapshots ORDER BY timestamp DESC")
    fun getAllSnapshots(): Flow<List<SnapshotEntity>>

    @Query("SELECT * FROM snapshots ORDER BY id DESC LIMIT 1")
    suspend fun getLatestSnapshot(): SnapshotEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnapshot(snapshot: SnapshotEntity): Long

    @Query("DELETE FROM snapshots")
    suspend fun clearSnapshots()

    // --- Runtime Logs ---
    @Query("SELECT * FROM runtime_logs ORDER BY timestamp DESC LIMIT 200")
    fun getRecentLogs(): Flow<List<RuntimeLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: RuntimeLogEntity): Long

    @Query("DELETE FROM runtime_logs")
    suspend fun clearLogs()

    // --- LLM Config ---
    @Query("SELECT * FROM llm_configs WHERE id = 1")
    fun getLLMConfig(): Flow<LLMConfigEntity?>

    @Query("SELECT * FROM llm_configs WHERE id = 1")
    suspend fun getLLMConfigDirect(): LLMConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveLLMConfig(config: LLMConfigEntity)
}
