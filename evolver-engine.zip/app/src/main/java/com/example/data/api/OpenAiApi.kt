package com.example.data.api

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Url

interface OpenAiApi {
    @POST
    suspend fun createChatCompletion(
        @Url url: String,
        @Header("Authorization") authHeader: String,
        @Body request: ChatCompletionRequest
    ): Response<ChatCompletionResponse>
}

@JsonClass(generateAdapter = true)
data class ChatCompletionRequest(
    val model: String,
    val messages: List<ChatMessage>,
    val temperature: Float = 0.7f,
    @Json(name = "response_format") val responseFormat: ResponseFormat? = ResponseFormat("json_object")
)

@JsonClass(generateAdapter = true)
data class ChatMessage(
    val role: String,
    val content: String
)

@JsonClass(generateAdapter = true)
data class ResponseFormat(
    val type: String = "json_object"
)

@JsonClass(generateAdapter = true)
data class ChatCompletionResponse(
    val choices: List<ChatChoice>? = null,
    val error: ApiErrorDetail? = null
)

@JsonClass(generateAdapter = true)
data class ChatChoice(
    val message: ChatMessage? = null
)

@JsonClass(generateAdapter = true)
data class ApiErrorDetail(
    val message: String? = null,
    val type: String? = null
)
