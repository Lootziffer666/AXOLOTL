package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "snapshots")
data class SnapshotEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val title: String,
    val version: String,
    val integrityScore: Double,
    val uiSchemaJson: String,
    val patchDescription: String,
    val isSuccessful: Boolean = true
)

@Entity(tableName = "runtime_logs")
data class RuntimeLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val level: String, // "INFO", "WARN", "ERROR", "PATCH", "ROLLBACK"
    val message: String,
    val module: String = "EVOLVER_CORE"
)

@Entity(tableName = "llm_configs")
data class LLMConfigEntity(
    @PrimaryKey val id: Int = 1, // Single active config row
    val provider: String = "GEMINI", // "GEMINI" or "OPENAI_COMPATIBLE"
    val baseUrl: String = "https://api.openai.com/v1/",
    val apiKey: String = "",
    val modelName: String = "gemini-2.5-flash",
    val temperature: Float = 0.7f
)
