package com.example.data.repository

import com.example.BuildConfig
import com.example.data.api.ChatCompletionRequest
import com.example.data.api.ChatMessage
import com.example.data.api.GeminiApi
import com.example.data.api.GeminiContent
import com.example.data.api.GeminiPart
import com.example.data.api.GeminiRequest
import com.example.data.api.OpenAiApi
import com.example.data.local.EvolverDao
import com.example.data.local.LLMConfigEntity
import com.example.data.local.RuntimeLogEntity
import com.example.data.local.SnapshotEntity
import com.example.data.model.LLMConfig
import com.example.data.model.LLMProvider
import com.example.data.model.UiSchema
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

class EvolverRepository(
    private val evolverDao: EvolverDao
) {
    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val uiSchemaAdapter = moshi.adapter(UiSchema::class.java)

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val openAiRetrofit = Retrofit.Builder()
        .baseUrl("https://api.openai.com/v1/") // Placeholder base URL for Retrofit instantiation
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    private val openAiApi = openAiRetrofit.create(OpenAiApi::class.java)

    private val geminiRetrofit = Retrofit.Builder()
        .baseUrl("https://generativelanguage.googleapis.com/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    private val geminiApi = geminiRetrofit.create(GeminiApi::class.java)

    val allSnapshots: Flow<List<SnapshotEntity>> = evolverDao.getAllSnapshots()
    val recentLogs: Flow<List<RuntimeLogEntity>> = evolverDao.getRecentLogs()
    val savedLLMConfig: Flow<LLMConfigEntity?> = evolverDao.getLLMConfig()

    suspend fun logMessage(level: String, message: String, module: String = "EVOLVER_CORE") {
        evolverDao.insertLog(
            RuntimeLogEntity(
                level = level,
                message = message,
                module = module
            )
        )
    }

    suspend fun saveLLMConfig(config: LLMConfig) {
        evolverDao.saveLLMConfig(
            LLMConfigEntity(
                provider = config.provider.name,
                baseUrl = config.baseUrl,
                apiKey = config.apiKey,
                modelName = config.modelName,
                temperature = config.temperature
            )
        )
        logMessage("INFO", "Updated LLM Configuration (${config.provider.name} -> ${config.modelName})")
    }

    suspend fun getCurrentLLMConfig(): LLMConfig {
        val entity = evolverDao.getLLMConfigDirect()
        val apiKeyFromEnv = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }

        return if (entity != null) {
            val providerEnum = when (entity.provider) {
                "OPENAI_COMPATIBLE" -> LLMProvider.OPENAI_COMPATIBLE
                "GEMINI" -> LLMProvider.GEMINI
                else -> LLMProvider.BUILT_IN_GEMINI
            }
            LLMConfig(
                provider = providerEnum,
                baseUrl = entity.baseUrl.ifBlank { "https://api.openai.com/v1/" },
                apiKey = if (providerEnum == LLMProvider.BUILT_IN_GEMINI) apiKeyFromEnv else entity.apiKey.ifBlank { apiKeyFromEnv },
                modelName = entity.modelName.ifBlank { "gemini-2.5-flash" },
                temperature = entity.temperature
            )
        } else {
            LLMConfig(
                provider = LLMProvider.BUILT_IN_GEMINI,
                apiKey = apiKeyFromEnv,
                modelName = "gemini-2.5-flash"
            )
        }
    }

    suspend fun saveSnapshot(uiSchema: UiSchema, patchDescription: String): Long {
        val jsonStr = uiSchemaAdapter.toJson(uiSchema)
        val snapshotId = evolverDao.insertSnapshot(
            SnapshotEntity(
                title = uiSchema.title,
                version = uiSchema.version,
                integrityScore = uiSchema.integrityScore,
                uiSchemaJson = jsonStr,
                patchDescription = patchDescription,
                isSuccessful = true
            )
        )
        logMessage("PATCH", "Saved Snapshot #$snapshotId: $patchDescription")
        return snapshotId
    }

    suspend fun rollbackToLatestWorkingSnapshot(): UiSchema? {
        val latest = evolverDao.getLatestSnapshot()
        return if (latest != null) {
            try {
                val schema = uiSchemaAdapter.fromJson(latest.uiSchemaJson)
                logMessage("ROLLBACK", "Rolled back state to Snapshot #${latest.id}: ${latest.patchDescription}")
                schema
            } catch (e: Exception) {
                logMessage("ERROR", "Failed to deserialize snapshot #${latest.id}: ${e.message}")
                null
            }
        } else {
            logMessage("WARN", "No snapshot available for rollback.")
            null
        }
    }

    suspend fun requestEvolution(
        userPrompt: String,
        currentSchema: UiSchema,
        llmConfig: LLMConfig
    ): Result<UiSchema> {
        logMessage("INFO", "Syncing with LLM Engine (${llmConfig.provider.name} - ${llmConfig.modelName})...")

        var attempt = 0
        val maxAttempts = 3
        var lastErrorMessage = ""

        while (attempt < maxAttempts) {
            attempt++
            try {
                if (attempt > 1) {
                    logMessage("WARN", "Self-Healing Loop (Attempt $attempt/$maxAttempts): Fixing previous error: $lastErrorMessage")
                }

                val systemPromptWithContext = buildString {
                    append(llmConfig.systemPrompt)
                    append("\n\n[CURRENT_APP_STATE]\n")
                    append(uiSchemaAdapter.toJson(currentSchema))
                    if (lastErrorMessage.isNotBlank()) {
                        append("\n\n[PREVIOUS_EXECUTION_ERROR_STACKTRACE]\n")
                        append("Your previous output failed validation: ")
                        append(lastErrorMessage)
                        append("\nPlease fix this error and return valid JSON conforming to the schema.")
                    }
                }

                val jsonResponseText = if (llmConfig.provider == LLMProvider.OPENAI_COMPATIBLE) {
                    callOpenAiCompatibleApi(userPrompt, systemPromptWithContext, llmConfig)
                } else {
                    callGeminiApi(userPrompt, systemPromptWithContext, llmConfig)
                }

                val cleanedJson = extractJsonFromString(jsonResponseText)
                logMessage("INFO", "Received structure update from LLM")

                val parsedSchema = uiSchemaAdapter.fromJson(cleanedJson)
                    ?: throw IllegalArgumentException("Parsed JSON output was null.")

                logMessage("PATCH", "Applying HMR Hot-Reload to Module Layout")
                saveSnapshot(parsedSchema, "Evolutive Patch: $userPrompt")
                return Result.success(parsedSchema)

            } catch (e: Exception) {
                lastErrorMessage = e.message ?: "Unknown syntax/schema error"
                logMessage("ERROR", "Execution exception in attempt $attempt: $lastErrorMessage")
            }
        }

        logMessage("ERROR", "Self-Healing Loop failed after $maxAttempts attempts. Triggering automatic rollback.")
        val rolledBack = rollbackToLatestWorkingSnapshot()
        return if (rolledBack != null) {
            Result.failure(Exception("Self-Healing Loop failed. Rolled back to previous stable snapshot."))
        } else {
            Result.failure(Exception("Self-Healing Loop failed and no snapshot found."))
        }
    }

    private suspend fun callOpenAiCompatibleApi(
        userPrompt: String,
        systemPrompt: String,
        config: LLMConfig
    ): String {
        var fullUrl = config.baseUrl.trim()
        if (!fullUrl.endsWith("/")) fullUrl += "/"
        if (!fullUrl.endsWith("chat/completions")) {
            fullUrl += "chat/completions"
        }

        val authHeader = if (config.apiKey.isNotBlank()) "Bearer ${config.apiKey.trim()}" else "Bearer none"

        val request = ChatCompletionRequest(
            model = config.modelName,
            messages = listOf(
                ChatMessage("system", systemPrompt),
                ChatMessage("user", userPrompt)
            ),
            temperature = config.temperature
        )

        val response = openAiApi.createChatCompletion(fullUrl, authHeader, request)
        if (response.isSuccessful) {
            val body = response.body()
            val text = body?.choices?.firstOrNull()?.message?.content
            if (!text.isNullOrBlank()) {
                return text
            } else {
                throw IllegalStateException("Empty response from OpenAI-compatible provider.")
            }
        } else {
            val errBody = response.errorBody()?.string() ?: response.message()
            throw IllegalStateException("OpenAI API HTTP ${response.code()}: $errBody")
        }
    }

    private suspend fun callGeminiApi(
        userPrompt: String,
        systemPrompt: String,
        config: LLMConfig
    ): String {
        val apiKey = config.apiKey.ifBlank {
            try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }
        }

        if (apiKey.isBlank()) {
            throw IllegalArgumentException("Gemini API Key is missing. Configure it in Settings or AI Studio Secrets panel.")
        }

        val modelName = config.modelName.ifBlank { "gemini-2.5-flash" }
        val fullUrl = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent"

        val request = GeminiRequest(
            contents = listOf(
                GeminiContent(
                    role = "user",
                    parts = listOf(
                        GeminiPart("SYSTEM INSTRUCTIONS:\n$systemPrompt\n\nUSER PROMPT:\n$userPrompt")
                    )
                )
            )
        )

        val response = geminiApi.generateContent(fullUrl, apiKey, request)
        if (response.isSuccessful) {
            val body = response.body()
            val text = body?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (!text.isNullOrBlank()) {
                return text
            } else {
                throw IllegalStateException("Empty candidate response from Gemini API.")
            }
        } else {
            val errBody = response.errorBody()?.string() ?: response.message()
            throw IllegalStateException("Gemini API HTTP ${response.code()}: $errBody")
        }
    }

    private fun extractJsonFromString(input: String): String {
        val trimmed = input.trim()
        if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
            return trimmed
        }
        val codeBlockRegex = Regex("```(?:json)?\\s*(\\{[\\s\\S]*?\\})\\s*```", RegexOption.IGNORE_CASE)
        val match = codeBlockRegex.find(trimmed)
        if (match != null) {
            return match.groupValues[1].trim()
        }
        val firstBrace = trimmed.indexOf('{')
        val lastBrace = trimmed.lastIndexOf('}')
        if (firstBrace != -1 && lastBrace > firstBrace) {
            return trimmed.substring(firstBrace, lastBrace + 1)
        }
        return trimmed
    }
}
