package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.EvolverDatabase
import com.example.data.local.RuntimeLogEntity
import com.example.data.local.SnapshotEntity
import com.example.data.model.LLMConfig
import com.example.data.model.UiComponent
import com.example.data.model.UiSchema
import com.example.data.repository.EvolverRepository
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AppTab {
    HOME,
    STACK,
    STATUS,
    SETTINGS
}

data class EvolverUiState(
    val activeTab: AppTab = AppTab.HOME,
    val currentSchema: UiSchema = UiSchema(),
    val llmConfig: LLMConfig = LLMConfig(),
    val isEvolving: Boolean = false,
    val isSelfHealingActive: Boolean = true,
    val isSandboxActive: Boolean = true,
    val promptInput: String = "",
    val errorMessage: String? = null,
    val showConfigDialog: Boolean = false,
    val showHistoryDialog: Boolean = false,
    val showIntegrityInfoDialog: Boolean = false
)

class EvolverViewModel(application: Application) : AndroidViewModel(application) {

    private val db = EvolverDatabase.getDatabase(application)
    private val repository = EvolverRepository(db.evolverDao())

    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    private val schemaAdapter = moshi.adapter(UiSchema::class.java)

    private val _uiState = MutableStateFlow(EvolverUiState())
    val uiState: StateFlow<EvolverUiState> = _uiState.asStateFlow()

    val snapshots: StateFlow<List<SnapshotEntity>> = repository.allSnapshots
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val logs: StateFlow<List<RuntimeLogEntity>> = repository.recentLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            // Load saved LLM config
            val config = repository.getCurrentLLMConfig()
            _uiState.update { it.copy(llmConfig = config) }

            // Initial log entries
            repository.logMessage("INFO", "Evolver Engine v4.2.0-Alpha initialized")
            repository.logMessage("INFO", "Active LLM Provider: ${config.provider.name} (${config.modelName})")
            repository.logMessage("WARN", "Verifying Security Sandbox... OK")

            // Save initial snapshot
            repository.saveSnapshot(_uiState.value.currentSchema, "Initial Baseline State")
        }
    }

    fun selectTab(tab: AppTab) {
        _uiState.update { it.copy(activeTab = tab) }
        viewModelScope.launch {
            repository.logMessage("INFO", "Switched view tab to: ${tab.name}")
        }
    }

    fun toggleIntegrityInfoDialog(show: Boolean) {
        _uiState.update { it.copy(showIntegrityInfoDialog = show) }
    }

    fun onPromptChange(newPrompt: String) {
        _uiState.update { it.copy(promptInput = newPrompt) }
    }

    fun toggleConfigDialog(show: Boolean) {
        _uiState.update { it.copy(showConfigDialog = show) }
    }

    fun toggleHistoryDialog(show: Boolean) {
        _uiState.update { it.copy(showHistoryDialog = show) }
    }

    fun saveLLMConfig(newConfig: LLMConfig) {
        viewModelScope.launch {
            repository.saveLLMConfig(newConfig)
            _uiState.update { it.copy(llmConfig = newConfig) }
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            db.evolverDao().clearLogs()
            repository.logMessage("INFO", "Runtime console cleared")
        }
    }

    fun restoreSnapshot(snapshot: SnapshotEntity) {
        viewModelScope.launch {
            try {
                val schema = schemaAdapter.fromJson(snapshot.uiSchemaJson)
                if (schema != null) {
                    _uiState.update { it.copy(currentSchema = schema) }
                    repository.logMessage("ROLLBACK", "Restored Snapshot #${snapshot.id}: ${snapshot.patchDescription}")
                }
            } catch (e: Exception) {
                repository.logMessage("ERROR", "Failed to restore snapshot #${snapshot.id}: ${e.message}")
            }
        }
    }

    fun submitEvolutionPrompt(prompt: String? = null) {
        val targetPrompt = prompt ?: _uiState.value.promptInput
        if (targetPrompt.isBlank()) return

        viewModelScope.launch {
            _uiState.update { it.copy(isEvolving = true, errorMessage = null) }
            repository.logMessage("INFO", "Processing Prompt: \"$targetPrompt\"")

            val result = repository.requestEvolution(
                userPrompt = targetPrompt,
                currentSchema = _uiState.value.currentSchema,
                llmConfig = _uiState.value.llmConfig
            )

            result.onSuccess { newSchema ->
                _uiState.update {
                    it.copy(
                        currentSchema = newSchema,
                        isEvolving = false,
                        promptInput = ""
                    )
                }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        isEvolving = false,
                        errorMessage = error.message
                    )
                }
                repository.logMessage("ERROR", "Evolution request failed: ${error.message}")
            }
        }
    }

    fun handleComponentAction(actionTag: String, value: Any?) {
        viewModelScope.launch {
            when (actionTag) {
                "TOGGLE_SELF_HEALING" -> {
                    val active = value as? Boolean ?: !_uiState.value.isSelfHealingActive
                    _uiState.update { it.copy(isSelfHealingActive = active) }
                    repository.logMessage("INFO", "Self-Healing Loop set to ${if (active) "ACTIVE" else "DISABLED"}")
                }
                "TOGGLE_SANDBOX" -> {
                    val active = value as? Boolean ?: !_uiState.value.isSandboxActive
                    _uiState.update { it.copy(isSandboxActive = active) }
                    repository.logMessage("WARN", "Wasm Security Sandbox set to ${if (active) "ENFORCED" else "BYPASSED"}")
                }
                "TRIGGER_REPAIR" -> {
                    repository.logMessage("WARN", "Simulating UI Runtime Syntax Error...")
                    repository.logMessage("ERROR", "SyntaxError: Unexpected token < in JSON at position 142")
                    repository.logMessage("INFO", "Auto-Triggering Self-Healing Loop...")
                    submitEvolutionPrompt("Fix runtime syntax error and restore full layout functionality with updated metrics")
                }
                else -> {
                    repository.logMessage("INFO", "Triggered Action Event: $actionTag")
                }
            }
        }
    }
}
