package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.RuntimeLogEntity
import com.example.data.model.UiComponent
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.RoseError
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun GenerativeUiRenderer(
    component: UiComponent,
    integrityScore: Double,
    logs: List<RuntimeLogEntity>,
    onClearLogs: () -> Unit,
    onComponentAction: (actionTag: String, value: Any?) -> Unit,
    onIntegrityClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    when (component.type.uppercase()) {
        "CONTAINER" -> {
            Column(
                modifier = modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                component.children?.forEach { child ->
                    GenerativeUiRenderer(
                        component = child,
                        integrityScore = integrityScore,
                        logs = logs,
                        onClearLogs = onClearLogs,
                        onComponentAction = onComponentAction,
                        onIntegrityClick = onIntegrityClick
                    )
                }
            }
        }

        "ROW" -> {
            Row(
                modifier = modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                component.children?.forEach { child ->
                    Box(modifier = Modifier.weight(1f)) {
                        GenerativeUiRenderer(
                            component = child,
                            integrityScore = integrityScore,
                            logs = logs,
                            onClearLogs = onClearLogs,
                            onComponentAction = onComponentAction,
                            onIntegrityClick = onIntegrityClick
                        )
                    }
                }
            }
        }

        "PULSE_RING" -> {
            Box(
                modifier = modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                PulseVisualizer(
                    integrityScore = integrityScore,
                    label = component.label ?: "INTEGRITY",
                    onClick = onIntegrityClick
                )
            }
        }

        "LOG_STREAM" -> {
            RuntimeLogConsole(
                logs = logs,
                onClearLogs = onClearLogs,
                modifier = modifier.padding(vertical = 6.dp)
            )
        }

        "METRIC_CARD" -> {
            val accentColor = resolveColor(component.accentColor)
            Card(
                modifier = modifier
                    .fillMaxWidth()
                    .border(1.dp, DarkBorder, RoundedCornerShape(18.dp))
                    .testTag("metric_card_${component.id}"),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(18.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = (component.label ?: "METRIC").uppercase(),
                            color = TextMuted,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = component.value ?: "--",
                                color = TextPrimary,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (!component.unit.isNullOrBlank()) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = component.unit,
                                    color = accentColor,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(accentColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = resolveIcon(component.icon),
                            contentDescription = component.label,
                            tint = accentColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        "ACTION_BUTTON" -> {
            val accentColor = resolveColor(component.accentColor)
            Button(
                onClick = { onComponentAction(component.action ?: component.id, null) },
                modifier = modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("action_btn_${component.id}"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = accentColor,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(
                    imageVector = resolveIcon(component.icon ?: "bolt"),
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = component.label ?: "Execute Action",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }

        "TOGGLE_SWITCH" -> {
            Card(
                modifier = modifier
                    .fillMaxWidth()
                    .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = component.label ?: "Option",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Switch(
                        checked = component.isChecked ?: true,
                        onCheckedChange = { checked ->
                            onComponentAction(component.action ?: component.id, checked)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = CyanPrimary,
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = DarkSurface
                        ),
                        modifier = Modifier.testTag("switch_${component.id}")
                    )
                }
            }
        }

        "CUSTOM_CARD" -> {
            val accentColor = resolveColor(component.accentColor)
            Card(
                modifier = modifier
                    .fillMaxWidth()
                    .border(1.dp, DarkBorder, RoundedCornerShape(20.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!component.label.isNullOrBlank()) {
                        Text(
                            text = component.label.uppercase(),
                            color = accentColor,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        )
                    }

                    if (!component.subtext.isNullOrBlank()) {
                        Text(
                            text = component.subtext,
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    component.children?.forEach { child ->
                        GenerativeUiRenderer(
                            component = child,
                            integrityScore = integrityScore,
                            logs = logs,
                            onClearLogs = onClearLogs,
                            onComponentAction = onComponentAction
                        )
                    }
                }
            }
        }

        "TEXT" -> {
            val accentColor = resolveColor(component.accentColor)
            Column(modifier = modifier.padding(vertical = 2.dp)) {
                Text(
                    text = component.value ?: "",
                    color = accentColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                if (!component.subtext.isNullOrBlank()) {
                    Text(
                        text = component.subtext,
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }
        }

        "BADGE" -> {
            val accentColor = resolveColor(component.accentColor)
            Box(
                modifier = modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(accentColor.copy(alpha = 0.2f))
                    .border(1.dp, accentColor.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = component.label ?: "",
                    color = accentColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        else -> {
            Text(
                text = "Unrecognized Widget: ${component.type}",
                color = RoseError,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

private fun resolveColor(colorTag: String?): Color {
    return when (colorTag?.lowercase()) {
        "cyan" -> CyanGlow
        "emerald" -> EmeraldSuccess
        "amber" -> AmberWarning
        "purple" -> PurpleAccent
        "rose" -> RoseError
        else -> CyanPrimary
    }
}

private fun resolveIcon(iconTag: String?): ImageVector {
    return when (iconTag?.lowercase()) {
        "bolt" -> Icons.Default.Bolt
        "code" -> Icons.Default.Code
        "terminal" -> Icons.Default.Terminal
        "speed" -> Icons.Default.Speed
        "bug" -> Icons.Default.BugReport
        "security" -> Icons.Default.Security
        "memory" -> Icons.Default.Memory
        "refresh" -> Icons.Default.Refresh
        else -> Icons.Default.CheckCircle
    }
}
