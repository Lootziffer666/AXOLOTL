package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF0F1117)
val DarkSurface = Color(0xFF161B26)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkBorder = Color(0xFF334155)

val CyanPrimary = Color(0xFF06B6D4)
val CyanGlow = Color(0xFF22D3EE)
val CyanLight = Color(0xFF67E8F9)
val CyanDark = Color(0xFF0891B2)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val EmeraldSuccess = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val RoseError = Color(0xFFF43F5E)
val PurpleAccent = Color(0xFFA855F7)
