package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.AppTab
import com.example.ui.EvolverUiState
import com.example.ui.EvolverViewModel
import com.example.ui.components.GenerativeUiRenderer
import com.example.ui.components.IntegrityInfoDialog
import com.example.ui.components.LLMConfigDialog
import com.example.ui.components.RuntimeLogConsole
import com.example.ui.components.SnapshotHistoryDialog
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.EvolverTheme
import com.example.ui.theme.RoseError
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {

    private val viewModel: EvolverViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            EvolverTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                val snapshots by viewModel.snapshots.collectAsStateWithLifecycle()
                val logs by viewModel.logs.collectAsStateWithLifecycle()

                EvolverAppContent(
                    uiState = uiState,
                    snapshots = snapshots,
                    logs = logs,
                    onPromptChange = viewModel::onPromptChange,
                    onSubmitPrompt = { viewModel.submitEvolutionPrompt() },
                    onSuggestionClick = { prompt -> viewModel.submitEvolutionPrompt(prompt) },
                    onComponentAction = viewModel::handleComponentAction,
                    onClearLogs = viewModel::clearLogs,
                    onToggleConfigDialog = viewModel::toggleConfigDialog,
                    onToggleHistoryDialog = viewModel::toggleHistoryDialog,
                    onToggleIntegrityInfo = viewModel::toggleIntegrityInfoDialog,
                    onSelectTab = viewModel::selectTab,
                    onSaveConfig = viewModel::saveLLMConfig,
                    onRestoreSnapshot = viewModel::restoreSnapshot
                )
            }
        }
    }
}

@Composable
fun EvolverAppContent(
    uiState: EvolverUiState,
    snapshots: List<com.example.data.local.SnapshotEntity>,
    logs: List<com.example.data.local.RuntimeLogEntity>,
    onPromptChange: (String) -> Unit,
    onSubmitPrompt: () -> Unit,
    onSuggestionClick: (String) -> Unit,
    onComponentAction: (actionTag: String, value: Any?) -> Unit,
    onClearLogs: () -> Unit,
    onToggleConfigDialog: (Boolean) -> Unit,
    onToggleHistoryDialog: (Boolean) -> Unit,
    onToggleIntegrityInfo: (Boolean) -> Unit,
    onSelectTab: (AppTab) -> Unit,
    onSaveConfig: (com.example.data.model.LLMConfig) -> Unit,
    onRestoreSnapshot: (com.example.data.local.SnapshotEntity) -> Unit
) {
    val statusBarPadding = WindowInsets.statusBars.asPaddingValues()
    val navigationBarPadding = WindowInsets.navigationBars.asPaddingValues()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = DarkBackground,
        topBar = {
            // App Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(statusBarPadding)
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .shadow(8.dp, CircleShape, spotColor = CyanGlow)
                                .background(CyanGlow, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = uiState.currentSchema.title,
                            color = TextPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = (-0.5).sp
                        )
                    }
                    Text(
                        text = uiState.currentSchema.version,
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Patch History Button
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(DarkSurface)
                            .border(1.dp, DarkBorder, RoundedCornerShape(14.dp))
                            .clickable { onToggleHistoryDialog(true) }
                            .testTag("btn_history_dialog"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "History",
                            tint = CyanGlow,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // LLM Config Button
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(DarkSurface)
                            .border(1.dp, DarkBorder, RoundedCornerShape(14.dp))
                            .clickable { onToggleConfigDialog(true) }
                            .testTag("btn_settings_dialog"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = "LLM Settings",
                            tint = CyanGlow,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        },
        bottomBar = {
            // Bottom Navigation
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface)
                    .padding(navigationBarPadding)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(DarkBorder)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp, horizontal = 24.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NavItem(
                        label = "Home",
                        icon = Icons.Default.Home,
                        isSelected = uiState.activeTab == AppTab.HOME,
                        onClick = { onSelectTab(AppTab.HOME) }
                    )
                    NavItem(
                        label = "Stack",
                        icon = Icons.Default.Layers,
                        isSelected = uiState.activeTab == AppTab.STACK,
                        onClick = { onSelectTab(AppTab.STACK) }
                    )
                    NavItem(
                        label = "Status",
                        icon = Icons.Default.Info,
                        isSelected = uiState.activeTab == AppTab.STATUS,
                        onClick = { onSelectTab(AppTab.STATUS) }
                    )
                    NavItem(
                        label = "Profile",
                        icon = Icons.Default.Person,
                        isSelected = uiState.activeTab == AppTab.SETTINGS,
                        onClick = { onSelectTab(AppTab.SETTINGS) }
                    )
                }

                // Android System Gesture Pill
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .width(96.dp)
                            .height(4.dp)
                            .background(DarkBorder, CircleShape)
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 18.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Error banner if any
            if (uiState.errorMessage != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RoseError.copy(alpha = 0.15f), RoundedCornerShape(14.dp))
                        .border(1.dp, RoseError, RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = "Error: ${uiState.errorMessage}",
                        color = RoseError,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            when (uiState.activeTab) {
                AppTab.HOME -> {
                    // Main Generative UI Container
                    GenerativeUiRenderer(
                        component = uiState.currentSchema.layout,
                        integrityScore = uiState.currentSchema.integrityScore,
                        logs = logs,
                        onClearLogs = onClearLogs,
                        onComponentAction = onComponentAction,
                        onIntegrityClick = { onToggleIntegrityInfo(true) }
                    )

                    // Evolution Prompt Box Section
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, DarkBorder, RoundedCornerShape(20.dp))
                            .testTag("evolution_prompt_box"),
                        color = DarkSurface,
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "EVOLUTION PROMPT",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.2.sp
                                )

                                Text(
                                    text = "${uiState.llmConfig.provider.name} • ${uiState.llmConfig.modelName}",
                                    color = CyanGlow,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            // Quick suggestion chips
                            val suggestions = listOf(
                                "Add dark-mode toggle to side panel",
                                "Add CPU & Ram monitor metric cards",
                                "Simulate UI syntax error (Test Self-Healing)",
                                "Add security status badge"
                            )

                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                items(suggestions) { suggestion ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(DarkBackground)
                                            .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
                                            .clickable { onSuggestionClick(suggestion) }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = suggestion,
                                            color = TextSecondary,
                                            fontSize = 10.5.sp
                                        )
                                    }
                                }
                            }

                            // Prompt Input Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = uiState.promptInput,
                                    onValueChange = onPromptChange,
                                    placeholder = {
                                        Text(
                                            "\"Add a dark-mode toggle to side panel...\"",
                                            color = TextMuted,
                                            fontSize = 12.5.sp
                                        )
                                    },
                                    enabled = !uiState.isEvolving,
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = CyanGlow,
                                        unfocusedBorderColor = DarkBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary,
                                        focusedContainerColor = DarkBackground,
                                        unfocusedContainerColor = DarkBackground
                                    ),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("input_evolution_prompt")
                                )

                                Spacer(modifier = Modifier.width(10.dp))

                                // Submit Execution Button
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(CyanPrimary)
                                        .clickable(enabled = !uiState.isEvolving) { onSubmitPrompt() }
                                        .testTag("btn_submit_evolution"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (uiState.isEvolving) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(20.dp),
                                            color = Color.White,
                                            strokeWidth = 2.dp
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Default.AutoAwesome,
                                            contentDescription = "Execute",
                                            tint = Color.White,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                AppTab.STACK -> {
                    // Stack / Snapshot History View
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "PATCH HISTORY & SNAPSHOT ROLLBACK",
                            color = CyanGlow,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )

                        if (snapshots.isEmpty()) {
                            Text("No patch snapshots recorded yet.", color = TextMuted, fontSize = 12.sp)
                        } else {
                            snapshots.forEach { snapshot ->
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
                                    color = DarkSurface,
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = snapshot.patchDescription,
                                                color = TextPrimary,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "Snapshot #${snapshot.id} • ${snapshot.version} • Integrity: ${String.format("%.1f%%", snapshot.integrityScore)}",
                                                color = TextMuted,
                                                fontSize = 10.5.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(8.dp))

                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(CyanPrimary.copy(alpha = 0.2f))
                                                .border(1.dp, CyanPrimary, RoundedCornerShape(10.dp))
                                                .clickable { onRestoreSnapshot(snapshot) }
                                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                        ) {
                                            Text(
                                                text = "ROLLBACK",
                                                color = CyanGlow,
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                AppTab.STATUS -> {
                    // Status & Log Console View
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "SYSTEM STATUS & RUNTIME DIAGNOSTICS",
                            color = CyanGlow,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )

                        RuntimeLogConsole(
                            logs = logs,
                            onClearLogs = onClearLogs
                        )
                    }
                }

                AppTab.SETTINGS -> {
                    // Profile / LLM Configuration Tab
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "LLM ENGINE & SYSTEM PREFERENCES",
                            color = CyanGlow,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, DarkBorder, RoundedCornerShape(20.dp)),
                            color = DarkSurface,
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "Active Provider: ${uiState.llmConfig.provider.name}",
                                    color = TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                Text(
                                    text = "Model: ${uiState.llmConfig.modelName}",
                                    color = TextSecondary,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(CyanPrimary)
                                        .clickable { onToggleConfigDialog(true) }
                                        .padding(horizontal = 16.dp, vertical = 10.dp)
                                ) {
                                    Text(
                                        text = "Configure LLM Settings",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Modal Dialogs
    if (uiState.showIntegrityInfoDialog) {
        IntegrityInfoDialog(
            integrityScore = uiState.currentSchema.integrityScore,
            onDismiss = { onToggleIntegrityInfo(false) }
        )
    }

    if (uiState.showConfigDialog) {
        LLMConfigDialog(
            initialConfig = uiState.llmConfig,
            onDismiss = { onToggleConfigDialog(false) },
            onSaveConfig = onSaveConfig
        )
    }

    if (uiState.showHistoryDialog) {
        SnapshotHistoryDialog(
            snapshots = snapshots,
            onDismiss = { onToggleHistoryDialog(false) },
            onRestoreSnapshot = onRestoreSnapshot
        )
    }
}

@Composable
private fun NavItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .width(44.dp)
                .height(28.dp)
                .clip(CircleShape)
                .background(if (isSelected) CyanPrimary.copy(alpha = 0.15f) else Color.Transparent),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) CyanGlow else TextMuted,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            color = if (isSelected) CyanGlow else TextMuted,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
