import React, { useState } from 'react';
import { 
  HallData, 
  StartPoint, 
  SelectedElement, 
  NavigationMode, 
  ViewTab, 
  CityGMLBuilding, 
  InteriorPhoto 
} from './types/koelnmesse';
import { 
  KOELNMESSE_HALLS, 
  KOELNMESSE_STARTPOINTS, 
  MATERIAL_PRESETS 
} from './data/koelnmesseData';
import { getDemoNRWCityGMLBuildings } from './utils/citygmlParser';
import { exportSessionData } from './utils/sessionExport';

import { HeaderNav } from './components/HeaderNav';
import { ThreeCanvas } from './components/ThreeCanvas';
import { StartPointsPanel } from './components/StartPointsPanel';
import { InspectorPanel } from './components/InspectorPanel';
import { CityGMLImporter } from './components/CityGMLImporter';
import { PhotoAligner } from './components/PhotoAligner';

export default function App() {
  // Navigation & View States
  const [activeTab, setActiveTab] = useState<ViewTab>('3d');
  const [navMode, setNavMode] = useState<NavigationMode>('walk');
  const [selectedStartPoint, setSelectedStartPoint] = useState<StartPoint>(
    KOELNMESSE_STARTPOINTS.find(p => p.id === 'nordeingang-haupt') || KOELNMESSE_STARTPOINTS[0]
  );

  // 3D Scene Interactive States
  const [selectedElement, setSelectedElement] = useState<SelectedElement | null>(null);
  const [customMaterials, setCustomMaterials] = useState<Record<string, string>>({});

  // CityGML NRW Datasets
  const [cityGMLBuildings, setCityGMLBuildings] = useState<CityGMLBuilding[]>(
    getDemoNRWCityGMLBuildings()
  );
  const [showCityGML, setShowCityGML] = useState<boolean>(true);

  // Interior Photos
  const [photos, setPhotos] = useState<InteriorPhoto[]>([]);

  // Material Customizer Handler
  const handleApplyMaterial = (elementId: string, materialPresetId: string) => {
    setCustomMaterials(prev => ({
      ...prev,
      [elementId]: materialPresetId
    }));
    if (selectedElement) {
      setSelectedElement({
        ...selectedElement,
        materialPresetId
      });
    }
  };

  // Export Session Handler
  const handleExportSession = () => {
    const sessionPayload = {
      app: 'Koelnmesse 3D Studio',
      timestamp: new Date().toISOString(),
      activeStartPoint: selectedStartPoint,
      navigationMode: navMode,
      customMaterials,
      cityGMLBuildingsCount: cityGMLBuildings.length,
      cityGMLBuildings,
      photosCount: photos.length,
      photos: photos.map(p => ({
        id: p.id,
        name: p.name,
        hallId: p.hallId,
        cameraHeight: p.cameraHeight,
        opacity: p.opacity
      }))
    };
    exportSessionData(sessionPayload, `koelnmesse_3d_session_${Date.now()}.json`);
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-950 font-sans overflow-hidden select-none">
      {/* Header Bar */}
      <HeaderNav 
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        navMode={navMode}
        onChangeNavMode={setNavMode}
        onExportSession={handleExportSession}
      />

      {/* Main Viewport Container */}
      <div className="flex-1 relative flex overflow-hidden">
        {/* Main 3D Canvas */}
        <div className="flex-1 h-full relative">
          <ThreeCanvas 
            halls={KOELNMESSE_HALLS}
            startPoints={KOELNMESSE_STARTPOINTS}
            selectedStartPoint={selectedStartPoint}
            navMode={navMode}
            selectedElement={selectedElement}
            onSelectElement={setSelectedElement}
            cityGMLBuildings={cityGMLBuildings}
            showCityGML={showCityGML}
            photos={photos}
            materialPresets={MATERIAL_PRESETS}
            customMaterials={customMaterials}
          />

          {/* Interactive Material Inspector Panel when a 3D element is selected */}
          <InspectorPanel 
            selectedElement={selectedElement}
            materialPresets={MATERIAL_PRESETS}
            onApplyMaterial={handleApplyMaterial}
            onClose={() => setSelectedElement(null)}
          />
        </div>

        {/* Start Points Teleport Drawer / Sidebar */}
        {activeTab === 'startpoints' && (
          <div className="w-80 sm:w-96 h-full relative z-20 animate-in slide-in-from-right duration-300">
            <StartPointsPanel 
              startPoints={KOELNMESSE_STARTPOINTS}
              selectedStartPoint={selectedStartPoint}
              onSelectStartPoint={(pt) => {
                setSelectedStartPoint(pt);
                setActiveTab('3d');
              }}
            />
          </div>
        )}

        {/* CityGML NRW Importer Modal / Drawer */}
        {activeTab === 'citygml' && (
          <div className="absolute top-4 right-4 z-20 animate-in fade-in slide-in-from-top-4 duration-200">
            <CityGMLImporter 
              buildings={cityGMLBuildings}
              onImportBuildings={(newBldgs) => {
                setCityGMLBuildings(newBldgs);
                setShowCityGML(true);
              }}
              showCityGML={showCityGML}
              onToggleCityGML={() => setShowCityGML(!showCityGML)}
            />
          </div>
        )}

        {/* Interior Photo Matcher Drawer */}
        {activeTab === 'photos' && (
          <div className="absolute top-4 right-4 z-20 animate-in fade-in slide-in-from-top-4 duration-200">
            <PhotoAligner 
              halls={KOELNMESSE_HALLS}
              photos={photos}
              onAddPhoto={(newP) => setPhotos(prev => [...prev, newP])}
              onRemovePhoto={(id) => setPhotos(prev => prev.filter(p => p.id !== id))}
              onUpdatePhoto={(updatedP) => setPhotos(prev => prev.map(p => p.id === updatedP.id ? updatedP : p))}
            />
          </div>
        )}
      </div>
    </div>
  );
}
