import { HallData, StartPoint, MaterialPreset } from '../types/koelnmesse';

export const KOELNMESSE_HALLS: HallData[] = [
  // Nordeingang Area & North Halls
  {
    id: 'halle-6',
    name: 'Halle 6 (gamescom Main Stage / Esports)',
    hallNumber: '6',
    position: [-130, 10, -120],
    size: [120, 20, 100],
    levels: 1,
    color: '#3b82f6',
    description: 'Große, säulenfreie Halle im Nordbereich. Häufig genutzt für große Messestände und eSports Arenen.',
    hasPassageTo: ['halle-7', 'boulevard-nord', 'nordeingang']
  },
  {
    id: 'halle-7',
    name: 'Halle 7 (Major Publishers)',
    hallNumber: '7',
    position: [-130, 10, -10],
    size: [120, 20, 100],
    levels: 1,
    color: '#2563eb',
    description: 'Zentrale Nordhalle direkt am Boulevard mit direkter Anbindung an Halle 6 und Halle 8.',
    hasPassageTo: ['halle-6', 'halle-9', 'boulevard-mitte']
  },
  {
    id: 'halle-8',
    name: 'Halle 8 (Entertainment Area Nord)',
    hallNumber: '8',
    position: [130, 10, -120],
    size: [120, 20, 100],
    levels: 1,
    color: '#1d4ed8',
    description: 'Östliche Nordhalle direkt verbunden mit der Eingangshalle Nord.',
    hasPassageTo: ['halle-5', 'boulevard-nord', 'nordeingang']
  },

  // Middle Halls
  {
    id: 'halle-9',
    name: 'Halle 9 (gamescom Major Booths)',
    hallNumber: '9',
    position: [-130, 10, 90],
    size: [120, 20, 90],
    levels: 1,
    color: '#0284c7',
    description: 'Große Halle mit Zugang zum Messebalkon und der Passage zu Halle 10.',
    hasPassageTo: ['halle-7', 'halle-10', 'boulevard-mitte']
  },
  {
    id: 'halle-5',
    name: 'Halle 5 (5.1 & 5.2 - Merchandise & Boardgames)',
    hallNumber: '5',
    position: [130, 16, -10],
    size: [120, 32, 90],
    levels: 2,
    color: '#0369a1',
    description: 'Zweigeschossige Halle (5.1 unten, 5.2 oben). Beliebt für Merchandise, Retro Games und Cosplay Village.',
    hasPassageTo: ['halle-8', 'halle-4', 'boulevard-mitte']
  },
  {
    id: 'halle-4',
    name: 'Halle 4 (4.1 & 4.2 - Retro & Family)',
    hallNumber: '4',
    position: [130, 16, 90],
    size: [120, 32, 90],
    levels: 2,
    color: '#075985',
    description: 'Zweigeschossige Messehalle mit direkter Passage zu Halle 3 und 11.',
    hasPassageTo: ['halle-5', 'halle-3', 'halle-11', 'boulevard-sued']
  },

  // South & East Halls
  {
    id: 'halle-10',
    name: 'Halle 10 (10.1 & 10.2 - Indie Arena & Hardware)',
    hallNumber: '10',
    position: [-130, 16, 190],
    size: [120, 32, 90],
    levels: 2,
    color: '#0f766e',
    description: 'Zweigeschossige Halle mit Indie Arena Booth im Obergeschoss (10.2) und Hardware/Modding im Erdgeschoss (10.1).',
    hasPassageTo: ['halle-9', 'halle-1', 'boulevard-sued']
  },
  {
    id: 'halle-3',
    name: 'Halle 3 (3.1 & 3.2 - Business Area & Publisher)',
    hallNumber: '3',
    position: [130, 16, 190],
    size: [120, 32, 90],
    levels: 2,
    color: '#115e59',
    description: 'Große Südhalle für VIP, Pressekohorten und Business Lounge.',
    hasPassageTo: ['halle-4', 'halle-2', 'suedeingang']
  },
  {
    id: 'halle-2',
    name: 'Halle 2 (2.1 & 2.2 - Business Area)',
    hallNumber: '2',
    position: [130, 16, 280],
    size: [120, 32, 80],
    levels: 2,
    color: '#134e4a',
    description: 'Exklusive B2B Halle am Südeingang mit Konferenzräumen.',
    hasPassageTo: ['halle-3', 'halle-1', 'suedeingang']
  },
  {
    id: 'halle-1',
    name: 'Halle 1 (Event & Special Exhibition)',
    hallNumber: '1',
    position: [-130, 10, 280],
    size: [120, 20, 80],
    levels: 1,
    color: '#1e3a8a',
    description: 'Kompakte Eventhalle südlich von Halle 10.',
    hasPassageTo: ['halle-10', 'suedeingang']
  },
  {
    id: 'halle-11',
    name: 'Halle 11 (11.1, 11.2 & 11.3 - gamescom Congress & Executive)',
    hallNumber: '11',
    position: [270, 24, 90],
    size: [100, 48, 120],
    levels: 3,
    color: '#4338ca',
    description: 'Dreigeschossiger moderner Hallenkomplex am Osteingang. Heimat des gamescom Congress und Keynote Auditorien.',
    hasPassageTo: ['halle-4', 'osteingang']
  }
];

export const KOELNMESSE_STARTPOINTS: StartPoint[] = [
  {
    id: 'nordeingang-haupt',
    name: 'Nordeingang (Messeplatz Nord)',
    category: 'Entrance',
    position: [0, 4, -265],
    target: [0, 9, -170],
    description: 'Hauptzugang im Norden direkt am Bahnhof Köln Messe/Deutz Nord. Große Glashalle mit Portal und Drehkreuzen.',
    level: 'Foyer EG'
  },
  {
    id: 'boulevard-nord',
    name: 'Messe-Boulevard Nord (Passage 6/8)',
    category: 'Passage',
    position: [0, 3, -120],
    target: [0, 3, -50],
    description: 'Verbindungsgang zwischen Halle 6 (Westen) und Halle 8 (Osten).',
    level: 'EG'
  },
  {
    id: 'boulevard-mitte',
    name: 'Messe-Boulevard Mitte (Gastronomie & Central Hub)',
    category: 'Passage',
    position: [0, 3, 0],
    target: [0, 3, 100],
    description: 'Zentraler Treffpunkt des Geländes mit Gastronomiebereich, Informationsständen und Rolltreppen zu den Hallen 5 & 9.',
    level: 'EG'
  },
  {
    id: 'boulevard-sued',
    name: 'Messe-Boulevard Süd (Passage 4/10)',
    category: 'Passage',
    position: [0, 3, 120],
    target: [0, 3, 200],
    description: 'Südlicher Abschnitt des Boulevards mit Übergang zu Halle 4, 10 und Südeingang.',
    level: 'EG'
  },
  {
    id: 'suedeingang',
    name: 'Südeingang (Entrance South & Congress-Centrum Süd)',
    category: 'Entrance',
    position: [0, 4, 340],
    target: [0, 5, 250],
    description: 'Südlicher Haupteingang nahe Rheinpark und Deutzer Freiheit.',
    level: 'Foyer EG'
  },
  {
    id: 'osteingang',
    name: 'Osteingang & Halle 11 (Congress Center Ost)',
    category: 'Entrance',
    position: [330, 5, 90],
    target: [250, 5, 90],
    description: 'Östlicher Zugang mit direkter Anbindung an den 3-geschossigen Hallenkomplex 11.',
    level: 'Eingang Ost'
  },

  // Individual Hall Start Points
  {
    id: 'sp-halle-1',
    name: 'Halle 1 (Innenansicht)',
    category: 'Hall',
    position: [-130, 3, 280],
    target: [-130, 3, 250],
    description: 'Eventhalle Süd.',
    hallNumber: '1'
  },
  {
    id: 'sp-halle-2',
    name: 'Halle 2 (Business B2B Area)',
    category: 'Hall',
    position: [130, 3, 280],
    target: [130, 3, 250],
    description: 'Business Stände & VIP Lounges.',
    hallNumber: '2'
  },
  {
    id: 'sp-halle-3',
    name: 'Halle 3 (3.1 Partner Lounges)',
    category: 'Hall',
    position: [130, 3, 190],
    target: [130, 3, 160],
    description: 'Presse und Großaussteller.',
    hallNumber: '3'
  },
  {
    id: 'sp-halle-4-1',
    name: 'Halle 4.1 (Retro & Family EG)',
    category: 'Hall',
    position: [130, 3, 90],
    target: [130, 3, 60],
    description: 'Familienecke, Retro-Gaming und Hardware-Zubehör.',
    hallNumber: '4',
    level: '4.1'
  },
  {
    id: 'sp-halle-5-1',
    name: 'Halle 5.1 (Merchandise Area EG)',
    category: 'Hall',
    position: [130, 3, -10],
    target: [130, 3, -40],
    description: 'Große Merchandise Meile & Fanartikel.',
    hallNumber: '5',
    level: '5.1'
  },
  {
    id: 'sp-halle-5-2',
    name: 'Halle 5.2 (Cosplay Village OG)',
    category: 'Hall',
    position: [130, 18, -10],
    target: [130, 18, -40],
    description: 'Cosplay Stage, Fotowände und Brettspiel-Zone.',
    hallNumber: '5',
    level: '5.2'
  },
  {
    id: 'sp-halle-6',
    name: 'Halle 6 (Main Stage & AAA Arena)',
    category: 'Hall',
    position: [-130, 3, -120],
    target: [-130, 3, -150],
    description: 'Spektakuläre Showbühnen und Blockbuster-Games.',
    hallNumber: '6'
  },
  {
    id: 'sp-halle-7',
    name: 'Halle 7 (Entertainment Nord)',
    category: 'Hall',
    position: [-130, 3, -10],
    target: [-130, 3, -40],
    description: 'Große Publisher Stände und Anspielstationen.',
    hallNumber: '7'
  },
  {
    id: 'sp-halle-8',
    name: 'Halle 8 (eSports & Stage Area)',
    category: 'Hall',
    position: [130, 3, -120],
    target: [130, 3, -150],
    description: 'Turnierbühnen und eSports Arenen.',
    hallNumber: '8'
  },
  {
    id: 'sp-halle-9',
    name: 'Halle 9 (Blockbuster Showcases)',
    category: 'Hall',
    position: [-130, 3, 90],
    target: [-130, 3, 60],
    description: 'Beliebte Messehalle mit hoher Besucherdichte.',
    hallNumber: '9'
  },
  {
    id: 'sp-halle-10-1',
    name: 'Halle 10.1 (Hardware & Modding EG)',
    category: 'Hall',
    position: [-130, 3, 190],
    target: [-130, 3, 160],
    description: 'Gaming PCs, Peripherie und Simulationen.',
    hallNumber: '10',
    level: '10.1'
  },
  {
    id: 'sp-halle-10-2',
    name: 'Halle 10.2 (Indie Arena Booth OG)',
    category: 'Hall',
    position: [-130, 18, 190],
    target: [-130, 18, 160],
    description: 'Weltgrößter Stand für unabhängige Spieleentwickler (Indie Arena Booth).',
    hallNumber: '10',
    level: '10.2'
  },
  {
    id: 'sp-halle-11-1',
    name: 'Halle 11.1 (Congress Center & Keynote Auditorium)',
    category: 'Hall',
    position: [270, 3, 90],
    target: [270, 3, 60],
    description: 'Großer Vortragssaal für gamescom congress Entwickler-Panels.',
    hallNumber: '11',
    level: '11.1'
  }
];

export const MATERIAL_PRESETS: MaterialPreset[] = [
  {
    id: 'mat-concrete-light',
    name: 'Messebeton Hell (Standard Hallenboden)',
    color: '#9ca3af',
    roughness: 0.7,
    metalness: 0.1,
    pattern: 'concrete',
    category: 'floor'
  },
  {
    id: 'mat-carpet-blue',
    name: 'gamescom Blauer Teppich (Boulevard / Gang)',
    color: '#1d4ed8',
    roughness: 0.9,
    metalness: 0.0,
    pattern: 'carpet_blue',
    category: 'floor'
  },
  {
    id: 'mat-carpet-red',
    name: 'Red Carpet (VIP & Business)',
    color: '#b91c1c',
    roughness: 0.9,
    metalness: 0.0,
    pattern: 'carpet_red',
    category: 'floor'
  },
  {
    id: 'mat-wall-white',
    name: 'Weiße System-Messewand',
    color: '#f3f4f6',
    roughness: 0.5,
    metalness: 0.1,
    pattern: 'exhibition_panel',
    category: 'wall'
  },
  {
    id: 'mat-wall-dark',
    name: 'Schwarze Showroom-Wand (eSports / Gaming)',
    color: '#111827',
    roughness: 0.4,
    metalness: 0.2,
    pattern: 'exhibition_panel',
    category: 'wall'
  },
  {
    id: 'mat-wood-oak',
    name: 'Eichenholz Dielen (Lounge / Standbau)',
    color: '#b45309',
    roughness: 0.6,
    metalness: 0.05,
    pattern: 'wood',
    category: 'floor'
  },
  {
    id: 'mat-glass-facade',
    name: 'Glaskonstruktion Nordeingang',
    color: '#38bdf8',
    roughness: 0.1,
    metalness: 0.9,
    pattern: 'glass',
    category: 'special'
  },
  {
    id: 'mat-led-wall',
    name: 'LED Video-Wall (Stand-Fassade)',
    color: '#a855f7',
    roughness: 0.2,
    metalness: 0.5,
    pattern: 'led_screen',
    category: 'special'
  },
  {
    id: 'mat-steel-truss',
    name: 'Aluminium Traversen & Säulen',
    color: '#64748b',
    roughness: 0.3,
    metalness: 0.8,
    pattern: 'metal',
    category: 'structure'
  }
];
