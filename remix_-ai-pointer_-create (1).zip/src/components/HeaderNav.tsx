import React from 'react';
import { ViewTab, NavigationMode } from '../types/koelnmesse';
import { ThemeToggle } from './ThemeToggle';
import { 
  Building2, 
  Footprints, 
  Plane, 
  Globe, 
  MapPin, 
  Camera, 
  Download, 
  Sparkles,
  Layers
} from 'lucide-react';

interface HeaderNavProps {
  activeTab: ViewTab;
  onSelectTab: (tab: ViewTab) => void;
  navMode: NavigationMode;
  onChangeNavMode: (mode: NavigationMode) => void;
  onExportSession: () => void;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  activeTab,
  onSelectTab,
  navMode,
  onChangeNavMode,
  onExportSession,
}) => {
  return (
    <header className="w-full bg-slate-900/95 border-b border-slate-800 px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-slate-100 backdrop-blur-md sticky top-0 z-30">
      {/* Brand Title */}
      <div className="flex items-center gap-3">
        <div className="p-2.5 bg-gradient-to-tr from-sky-500 to-indigo-600 rounded-2xl shadow-lg shadow-sky-500/20 text-white">
          <Building2 className="w-5 h-5" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-extrabold text-base tracking-tight text-white">
              Koelnmesse <span className="text-sky-400">3D Studio</span>
            </h1>
            <span className="text-[10px] font-bold px-2 py-0.5 bg-indigo-950 text-indigo-300 rounded-full border border-indigo-700/50">
              gamescom Edition
            </span>
          </div>
          <p className="text-[11px] text-slate-400">
            Hallen 1-11 • Nordeingang • NRW CityGML LoD2
          </p>
        </div>
      </div>

      {/* Camera Navigation Mode Selector */}
      <div className="flex items-center bg-slate-950 p-1 rounded-2xl border border-slate-800">
        <button
          onClick={() => onChangeNavMode('walk')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
            navMode === 'walk' 
              ? 'bg-sky-500 text-slate-950 font-bold shadow' 
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Footprints className="w-3.5 h-3.5" />
          Walk
        </button>

        <button
          onClick={() => onChangeNavMode('fly')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
            navMode === 'fly' 
              ? 'bg-sky-500 text-slate-950 font-bold shadow' 
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Plane className="w-3.5 h-3.5" />
          Fly
        </button>

        <button
          onClick={() => onChangeNavMode('orbit')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
            navMode === 'orbit' 
              ? 'bg-sky-500 text-slate-950 font-bold shadow' 
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Globe className="w-3.5 h-3.5" />
          Orbit
        </button>
      </div>

      {/* Main Feature Tabs */}
      <div className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-2xl border border-slate-800">
        <button
          onClick={() => onSelectTab('startpoints')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition cursor-pointer ${
            activeTab === 'startpoints'
              ? 'bg-indigo-600 text-white font-bold shadow'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <MapPin className="w-3.5 h-3.5 text-sky-400" />
          Startpunkte
        </button>

        <button
          onClick={() => onSelectTab('citygml')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition cursor-pointer ${
            activeTab === 'citygml'
              ? 'bg-indigo-600 text-white font-bold shadow'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Building2 className="w-3.5 h-3.5 text-sky-400" />
          NRW CityGML
        </button>

        <button
          onClick={() => onSelectTab('photos')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition cursor-pointer ${
            activeTab === 'photos'
              ? 'bg-indigo-600 text-white font-bold shadow'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Camera className="w-3.5 h-3.5 text-emerald-400" />
          Foto Matcher
        </button>
      </div>

      {/* Actions & Session Export */}
      <div className="flex items-center gap-2">
        <button
          onClick={onExportSession}
          className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl transition cursor-pointer border border-slate-700 active:scale-95 shadow"
        >
          <Download className="w-3.5 h-3.5 text-sky-400" />
          Session Export
        </button>
        <ThemeToggle />
      </div>
    </header>
  );
};
