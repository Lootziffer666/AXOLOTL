import React, { useState } from 'react';
import { InteriorPhoto, HallData } from '../types/koelnmesse';
import { Camera, Image as ImageIcon, Sliders, Trash2, Plus, Sparkles } from 'lucide-react';

interface PhotoAlignerProps {
  halls: HallData[];
  photos: InteriorPhoto[];
  onAddPhoto: (photo: InteriorPhoto) => void;
  onRemovePhoto: (id: string) => void;
  onUpdatePhoto: (photo: InteriorPhoto) => void;
}

export const PhotoAligner: React.FC<PhotoAlignerProps> = ({
  halls,
  photos,
  onAddPhoto,
  onRemovePhoto,
  onUpdatePhoto,
}) => {
  const [selectedHallId, setSelectedHallId] = useState<string>(halls[0]?.id || 'halle-6');
  const [cameraHeight, setCameraHeight] = useState<number>(8);

  const handleImageUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      if (dataUrl) {
        const newPhoto: InteriorPhoto = {
          id: `photo-${Date.now()}`,
          name: file.name,
          dataUrl,
          hallId: selectedHallId,
          timestamp: new Date().toLocaleTimeString(),
          cameraHeight,
          projectionScale: 1.0,
          opacity: 0.85,
          blendMode: 'normal'
        };
        onAddPhoto(newPhoto);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="bg-slate-900/95 backdrop-blur-xl border border-slate-800 rounded-3xl p-5 shadow-2xl text-slate-100 max-w-lg w-full">
      {/* Title */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl">
            <Camera className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-slate-100">Innenraum-Foto Matching</h3>
            <p className="text-xs text-slate-400">gamescom Fotos in 3D Architektur einpassen</p>
          </div>
        </div>
      </div>

      {/* Upload & Hall Selector */}
      <div className="mt-4 space-y-3">
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1">
            Ziel-Halle für Foto
          </label>
          <select 
            value={selectedHallId}
            onChange={(e) => setSelectedHallId(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
          >
            {halls.map((hall) => (
              <option key={hall.id} value={hall.id}>
                {hall.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1 flex justify-between">
            <span>Aufnahmehöhe der Kamera</span>
            <span className="font-mono text-emerald-400">{cameraHeight}m</span>
          </label>
          <input 
            type="range" 
            min="1" 
            max="25" 
            value={cameraHeight}
            onChange={(e) => setCameraHeight(Number(e.target.value))}
            className="w-full accent-emerald-500 bg-slate-950 h-1.5 rounded-lg"
          />
        </div>

        {/* Upload Button */}
        <label className="flex items-center justify-center gap-2 w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs rounded-xl cursor-pointer transition active:scale-95 shadow-lg shadow-emerald-950">
          <Plus className="w-4 h-4" />
          Innenraum-Foto hinzufügen
          <input 
            type="file" 
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                handleImageUpload(e.target.files[0]);
              }
            }}
          />
        </label>
      </div>

      {/* Active Photos List */}
      <div className="mt-4">
        <h4 className="text-xs font-semibold text-slate-400 mb-2">
          Eingepasste Foto-Projektionen ({photos.length})
        </h4>

        {photos.length === 0 ? (
          <p className="text-xs text-slate-500 italic text-center py-4 bg-slate-950/40 rounded-xl border border-slate-800/60">
            Noch keine Innenraum-Fotos hochgeladen.
          </p>
        ) : (
          <div className="space-y-3 max-h-48 overflow-y-auto pr-1 custom-scrollbar">
            {photos.map((photo) => {
              const targetHall = halls.find(h => h.id === photo.hallId);
              return (
                <div key={photo.id} className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 truncate">
                      <ImageIcon className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                      <span className="text-xs font-medium text-slate-200 truncate">{photo.name}</span>
                    </div>

                    <button 
                      onClick={() => onRemovePhoto(photo.id)}
                      className="text-slate-500 hover:text-red-400 transition cursor-pointer p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="text-[11px] text-slate-400 flex justify-between">
                    <span>Halle: <span className="text-emerald-400">{targetHall?.hallNumber || '6'}</span></span>
                    <span>Höhe: <span className="font-mono text-slate-300">{photo.cameraHeight}m</span></span>
                  </div>

                  {/* Transparency Slider */}
                  <div className="flex items-center gap-2 pt-1 border-t border-slate-800/60">
                    <span className="text-[10px] text-slate-500">3D-Deckkraft:</span>
                    <input 
                      type="range" 
                      min="0.1" 
                      max="1" 
                      step="0.05"
                      value={photo.opacity}
                      onChange={(e) => onUpdatePhoto({ ...photo, opacity: Number(e.target.value) })}
                      className="flex-1 accent-emerald-500 bg-slate-900 h-1 rounded-lg"
                    />
                    <span className="text-[10px] font-mono text-slate-400">{Math.round(photo.opacity * 100)}%</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
