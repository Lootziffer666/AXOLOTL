import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { 
  ChevronUp, 
  ChevronDown, 
  ChevronLeft, 
  ChevronRight, 
  RotateCcw, 
  RotateCw, 
  ArrowUp, 
  ArrowDown,
  Navigation
} from 'lucide-react';
import { 
  HallData, 
  StartPoint, 
  SelectedElement, 
  NavigationMode, 
  CityGMLBuilding, 
  InteriorPhoto,
  MaterialPreset
} from '../types/koelnmesse';

interface ThreeCanvasProps {
  halls: HallData[];
  startPoints: StartPoint[];
  selectedStartPoint: StartPoint;
  navMode: NavigationMode;
  selectedElement: SelectedElement | null;
  onSelectElement: (element: SelectedElement | null) => void;
  cityGMLBuildings: CityGMLBuilding[];
  showCityGML: boolean;
  photos: InteriorPhoto[];
  materialPresets: MaterialPreset[];
  customMaterials: Record<string, string>; // elementId/hallId -> presetId
}

export const ThreeCanvas: React.FC<ThreeCanvasProps> = ({
  halls,
  startPoints,
  selectedStartPoint,
  navMode,
  selectedElement,
  onSelectElement,
  cityGMLBuildings,
  showCityGML,
  photos,
  materialPresets,
  customMaterials
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const raycasterRef = useRef<THREE.Raycaster>(new THREE.Raycaster());
  const mouseRef = useRef<THREE.Vector2>(new THREE.Vector2());

  // Camera target interpolation state
  const targetCamPosRef = useRef<THREE.Vector3>(new THREE.Vector3(...selectedStartPoint.position));
  const targetLookAtRef = useRef<THREE.Vector3>(new THREE.Vector3(...selectedStartPoint.target));
  const currentLookAtRef = useRef<THREE.Vector3>(new THREE.Vector3(...selectedStartPoint.target));

  // Store interactive meshes map
  const meshesMapRef = useRef<Map<string, THREE.Mesh>>(new Map());

  // Keyboard & On-Screen Button Navigation State
  const keysPressedRef = useRef<Record<string, boolean>>({});

  // Trigger button press on mouse/touch down
  const handleNavButtonStart = (code: string) => (e: React.SyntheticEvent) => {
    e.stopPropagation();
    keysPressedRef.current[code] = true;
  };

  // Release button press on mouse/touch up
  const handleNavButtonEnd = (code: string) => (e: React.SyntheticEvent) => {
    e.stopPropagation();
    keysPressedRef.current[code] = false;
  };

  // Orbit drag controls state
  const isDraggingRef = useRef(false);
  const previousMousePositionRef = useRef({ x: 0, y: 0 });

  // Update target camera positions when selectedStartPoint changes
  useEffect(() => {
    targetCamPosRef.current.set(...selectedStartPoint.position);
    targetLookAtRef.current.set(...selectedStartPoint.target);
  }, [selectedStartPoint]);

  // Handle keyboard events
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysPressedRef.current[e.code] = true;
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      keysPressedRef.current[e.code] = false;
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Main Three.js Scene Setup & Loop
  useEffect(() => {
    if (!mountRef.current) return;

    const width = mountRef.current.clientWidth;
    const height = mountRef.current.clientHeight;

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color('#0f172a'); // Slate dark blue sky
    scene.fog = new THREE.FogExp2('#0f172a', 0.0015);

    // Camera
    const camera = new THREE.PerspectiveCamera(60, width / height, 0.5, 2000);
    camera.position.set(...selectedStartPoint.position);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    mountRef.current.appendChild(renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight('#ffffff', 0.8);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight('#fff7ed', 1.5);
    dirLight.position.set(200, 300, 150);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 10;
    dirLight.shadow.camera.far = 1000;
    const d = 400;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    scene.add(dirLight);

    const hemiLight = new THREE.HemisphereLight('#60a5fa', '#334155', 0.6);
    hemiLight.position.set(0, 500, 0);
    scene.add(hemiLight);

    // Ground Plane (Messegelände Grounds)
    const groundGeo = new THREE.PlaneGeometry(1200, 1200);
    const groundMat = new THREE.MeshStandardMaterial({ 
      color: '#1e293b', 
      roughness: 0.9, 
      metalness: 0.1 
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = 0;
    ground.receiveShadow = true;
    scene.add(ground);

    // Grid Helper
    const grid = new THREE.GridHelper(1200, 60, '#38bdf8', '#334155');
    grid.position.y = 0.1;
    scene.add(grid);

    // --- Build Koelnmesse Campus 3D Geometry ---
    buildCampusGeometry(scene, halls, materialPresets, customMaterials, meshesMapRef.current);

    // --- Build CityGML NRW LoD2 Layer if enabled ---
    if (showCityGML && cityGMLBuildings.length > 0) {
      buildCityGMLLayer(scene, cityGMLBuildings);
    }

    // --- Build Photo Overlay Quad if photos exist ---
    if (photos.length > 0) {
      buildPhotoOverlays(scene, photos);
    }

    // Window Resize Handler
    const handleResize = () => {
      if (!mountRef.current || !cameraRef.current || !rendererRef.current) return;
      const w = mountRef.current.clientWidth;
      const h = mountRef.current.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    // Animation Loop
    let animationFrameId: number;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      // Camera Lerp
      camera.position.lerp(targetCamPosRef.current, 0.08);
      currentLookAtRef.current.lerp(targetLookAtRef.current, 0.08);
      camera.lookAt(currentLookAtRef.current);

      // Camera Rotation & Turning (via On-Screen buttons or Keys)
      const rotSpeed = 0.02;
      const offset = targetLookAtRef.current.clone().sub(targetCamPosRef.current);

      if (keysPressedRef.current['TurnLeft']) {
        offset.applyAxisAngle(new THREE.Vector3(0, 1, 0), rotSpeed);
      }
      if (keysPressedRef.current['TurnRight']) {
        offset.applyAxisAngle(new THREE.Vector3(0, 1, 0), -rotSpeed);
      }
      if (keysPressedRef.current['LookUp']) {
        const right = new THREE.Vector3().crossVectors(offset, camera.up).normalize();
        offset.applyAxisAngle(right, rotSpeed * 0.8);
      }
      if (keysPressedRef.current['LookDown']) {
        const right = new THREE.Vector3().crossVectors(offset, camera.up).normalize();
        offset.applyAxisAngle(right, -rotSpeed * 0.8);
      }

      targetLookAtRef.current.copy(targetCamPosRef.current).add(offset);

      // Keyboard & On-Screen Controls (Walk / Fly)
      const moveSpeed = navMode === 'fly' ? 1.5 : 0.8;
      const moveVec = new THREE.Vector3();
      const lookDir = new THREE.Vector3();
      camera.getWorldDirection(lookDir);

      if (keysPressedRef.current['KeyW'] || keysPressedRef.current['ArrowUp']) {
        moveVec.addScaledVector(lookDir, moveSpeed);
      }
      if (keysPressedRef.current['KeyS'] || keysPressedRef.current['ArrowDown']) {
        moveVec.addScaledVector(lookDir, -moveSpeed);
      }
      if (keysPressedRef.current['KeyA'] || keysPressedRef.current['ArrowLeft']) {
        const leftVec = new THREE.Vector3().crossVectors(camera.up, lookDir).normalize();
        moveVec.addScaledVector(leftVec, moveSpeed);
      }
      if (keysPressedRef.current['KeyD'] || keysPressedRef.current['ArrowRight']) {
        const rightVec = new THREE.Vector3().crossVectors(lookDir, camera.up).normalize();
        moveVec.addScaledVector(rightVec, moveSpeed);
      }

      // Elevation (Up / Down in Fly or Walk mode)
      if (keysPressedRef.current['KeyE']) {
        targetCamPosRef.current.y += moveSpeed * 0.8;
        targetLookAtRef.current.y += moveSpeed * 0.8;
      }
      if (keysPressedRef.current['KeyQ']) {
        targetCamPosRef.current.y = Math.max(1.8, targetCamPosRef.current.y - moveSpeed * 0.8);
        targetLookAtRef.current.y = Math.max(1.8, targetLookAtRef.current.y - moveSpeed * 0.8);
      }

      if (moveVec.lengthSq() > 0) {
        if (navMode === 'walk') {
          moveVec.y = 0; // Lock elevation for walking
        }
        targetCamPosRef.current.add(moveVec);
        targetLookAtRef.current.add(moveVec);
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [halls, showCityGML, cityGMLBuildings, photos, customMaterials]);

  // Pointer Interaction (Selection & Orbit Drag)
  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    isDraggingRef.current = true;
    previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDraggingRef.current || !cameraRef.current) return;

    const deltaX = e.clientX - previousMousePositionRef.current.x;
    const deltaY = e.clientY - previousMousePositionRef.current.y;

    previousMousePositionRef.current = { x: e.clientX, y: e.clientY };

    // Rotate look target around camera position
    const rotSpeed = 0.005;
    const offset = targetLookAtRef.current.clone().sub(targetCamPosRef.current);

    // Horizontal rotation
    offset.applyAxisAngle(new THREE.Vector3(0, 1, 0), -deltaX * rotSpeed);

    // Vertical rotation
    const right = new THREE.Vector3().crossVectors(offset, new THREE.Vector3(0, 1, 0)).normalize();
    offset.applyAxisAngle(right, -deltaY * rotSpeed);

    targetLookAtRef.current.copy(targetCamPosRef.current).add(offset);
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!mountRef.current || !cameraRef.current || !sceneRef.current) return;

    // ONLY trigger 3D object selection if click landed directly on the 3D WebGL Canvas
    if (e.target !== rendererRef.current?.domElement) {
      return;
    }

    const rect = mountRef.current.getBoundingClientRect();
    mouseRef.current.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    mouseRef.current.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current);
    
    const interactables: THREE.Mesh[] = Array.from(meshesMapRef.current.values());
    const intersects = raycasterRef.current.intersectObjects(interactables, false);

    if (intersects.length > 0) {
      const hit = intersects[0];
      const mesh = hit.object as THREE.Mesh;
      const userData = mesh.userData;

      if (userData && userData.surfaceType) {
        onSelectElement({
          id: userData.id || `mesh-${Date.now()}`,
          name: userData.name || 'Sichtbares Bauteil',
          surfaceType: userData.surfaceType,
          hallId: userData.hallId,
          hallName: userData.hallName,
          color: userData.color || '#3b82f6',
          roughness: userData.roughness || 0.5,
          metalness: userData.metalness || 0.1,
          materialPresetId: customMaterials[userData.id] || userData.materialPresetId || 'mat-wall-white',
          position: [mesh.position.x, mesh.position.y, mesh.position.z]
        });
      }
    } else {
      onSelectElement(null);
    }
  };

  return (
    <div 
      ref={mountRef} 
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onClick={handleClick}
      className="w-full h-full relative cursor-grab active:cursor-grabbing overflow-hidden select-none"
    >
      {/* 3D Viewport Controls & Status Overlay */}
      <div className="absolute top-4 left-4 z-10 flex flex-col gap-2 bg-slate-900/85 backdrop-blur-md p-3 rounded-2xl border border-slate-700/60 shadow-xl text-xs text-slate-300">
        <div className="flex items-center gap-2 font-semibold text-sky-400">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          Koelnmesse 3D Engine Active
        </div>
        <p className="text-[11px] text-slate-400">
          Benutze die <span className="text-sky-300 font-semibold">virtuellen Tasten unten</span> oder Tastatur (W,A,S,D / Pfeiltasten) zum Laufen.
        </p>
      </div>

      {/* On-Screen Virtual Controls (Bottom Overlay) */}
      <div className="absolute bottom-6 right-6 z-20 flex flex-wrap items-end gap-4 pointer-events-auto">
        {/* Movement D-Pad (W, A, S, D) */}
        <div className="bg-slate-900/90 backdrop-blur-xl p-3 rounded-3xl border border-slate-700/80 shadow-2xl flex flex-col items-center gap-1.5 text-slate-200">
          <span className="text-[10px] font-bold uppercase tracking-wider text-sky-400 mb-0.5">Laufen (W,A,S,D)</span>
          
          <button
            onMouseDown={handleNavButtonStart('KeyW')}
            onMouseUp={handleNavButtonEnd('KeyW')}
            onMouseLeave={handleNavButtonEnd('KeyW')}
            onTouchStart={handleNavButtonStart('KeyW')}
            onTouchEnd={handleNavButtonEnd('KeyW')}
            className="p-3 bg-slate-800 hover:bg-sky-500 hover:text-slate-950 active:scale-90 rounded-2xl transition shadow border border-slate-700 flex items-center justify-center text-sky-300 font-bold"
            title="Vorwärts laufen (W)"
          >
            <ChevronUp className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-1.5">
            <button
              onMouseDown={handleNavButtonStart('KeyA')}
              onMouseUp={handleNavButtonEnd('KeyA')}
              onMouseLeave={handleNavButtonEnd('KeyA')}
              onTouchStart={handleNavButtonStart('KeyA')}
              onTouchEnd={handleNavButtonEnd('KeyA')}
              className="p-3 bg-slate-800 hover:bg-sky-500 hover:text-slate-950 active:scale-90 rounded-2xl transition shadow border border-slate-700 flex items-center justify-center text-sky-300 font-bold"
              title="Links laufen (A)"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <button
              onMouseDown={handleNavButtonStart('KeyS')}
              onMouseUp={handleNavButtonEnd('KeyS')}
              onMouseLeave={handleNavButtonEnd('KeyS')}
              onTouchStart={handleNavButtonStart('KeyS')}
              onTouchEnd={handleNavButtonEnd('KeyS')}
              className="p-3 bg-slate-800 hover:bg-sky-500 hover:text-slate-950 active:scale-90 rounded-2xl transition shadow border border-slate-700 flex items-center justify-center text-sky-300 font-bold"
              title="Rückwärts laufen (S)"
            >
              <ChevronDown className="w-5 h-5" />
            </button>

            <button
              onMouseDown={handleNavButtonStart('KeyD')}
              onMouseUp={handleNavButtonEnd('KeyD')}
              onMouseLeave={handleNavButtonEnd('KeyD')}
              onTouchStart={handleNavButtonStart('KeyD')}
              onTouchEnd={handleNavButtonEnd('KeyD')}
              className="p-3 bg-slate-800 hover:bg-sky-500 hover:text-slate-950 active:scale-90 rounded-2xl transition shadow border border-slate-700 flex items-center justify-center text-sky-300 font-bold"
              title="Rechts laufen (D)"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Camera Turn & Pitch Controls */}
        <div className="bg-slate-900/90 backdrop-blur-xl p-3 rounded-3xl border border-slate-700/80 shadow-2xl flex flex-col items-center gap-1.5 text-slate-200">
          <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400 mb-0.5">Drehen / Schauen</span>

          <button
            onMouseDown={handleNavButtonStart('LookUp')}
            onMouseUp={handleNavButtonEnd('LookUp')}
            onMouseLeave={handleNavButtonEnd('LookUp')}
            onTouchStart={handleNavButtonStart('LookUp')}
            onTouchEnd={handleNavButtonEnd('LookUp')}
            className="p-2.5 bg-slate-800 hover:bg-indigo-500 hover:text-white active:scale-90 rounded-2xl transition shadow border border-slate-700 text-indigo-300"
            title="Nach oben schauen"
          >
            <ArrowUp className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-1.5">
            <button
              onMouseDown={handleNavButtonStart('TurnLeft')}
              onMouseUp={handleNavButtonEnd('TurnLeft')}
              onMouseLeave={handleNavButtonEnd('TurnLeft')}
              onTouchStart={handleNavButtonStart('TurnLeft')}
              onTouchEnd={handleNavButtonEnd('TurnLeft')}
              className="p-2.5 bg-slate-800 hover:bg-indigo-500 hover:text-white active:scale-90 rounded-2xl transition shadow border border-slate-700 text-indigo-300"
              title="Nach links drehen"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onMouseDown={handleNavButtonStart('LookDown')}
              onMouseUp={handleNavButtonEnd('LookDown')}
              onMouseLeave={handleNavButtonEnd('LookDown')}
              onTouchStart={handleNavButtonStart('LookDown')}
              onTouchEnd={handleNavButtonEnd('LookDown')}
              className="p-2.5 bg-slate-800 hover:bg-indigo-500 hover:text-white active:scale-90 rounded-2xl transition shadow border border-slate-700 text-indigo-300"
              title="Nach unten schauen"
            >
              <ArrowDown className="w-4 h-4" />
            </button>

            <button
              onMouseDown={handleNavButtonStart('TurnRight')}
              onMouseUp={handleNavButtonEnd('TurnRight')}
              onMouseLeave={handleNavButtonEnd('TurnRight')}
              onTouchStart={handleNavButtonStart('TurnRight')}
              onTouchEnd={handleNavButtonEnd('TurnRight')}
              className="p-2.5 bg-slate-800 hover:bg-indigo-500 hover:text-white active:scale-90 rounded-2xl transition shadow border border-slate-700 text-indigo-300"
              title="Nach rechts drehen"
            >
              <RotateCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Height Controls (Up / Down) */}
        <div className="bg-slate-900/90 backdrop-blur-xl p-3 rounded-3xl border border-slate-700/80 shadow-2xl flex flex-col items-center gap-1.5 text-slate-200">
          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 mb-0.5">Höhe</span>

          <button
            onMouseDown={handleNavButtonStart('KeyE')}
            onMouseUp={handleNavButtonEnd('KeyE')}
            onMouseLeave={handleNavButtonEnd('KeyE')}
            onTouchStart={handleNavButtonStart('KeyE')}
            onTouchEnd={handleNavButtonEnd('KeyE')}
            className="p-2.5 bg-slate-800 hover:bg-emerald-500 hover:text-slate-950 active:scale-90 rounded-2xl transition shadow border border-slate-700 text-emerald-300 font-bold"
            title="Höher (E)"
          >
            +
          </button>

          <button
            onMouseDown={handleNavButtonStart('KeyQ')}
            onMouseUp={handleNavButtonEnd('KeyQ')}
            onMouseLeave={handleNavButtonEnd('KeyQ')}
            onTouchStart={handleNavButtonStart('KeyQ')}
            onTouchEnd={handleNavButtonEnd('KeyQ')}
            className="p-2.5 bg-slate-800 hover:bg-emerald-500 hover:text-slate-950 active:scale-90 rounded-2xl transition shadow border border-slate-700 text-emerald-300 font-bold"
            title="Tiefer (Q)"
          >
            -
          </button>
        </div>
      </div>
    </div>
  );
};

// --- Helper Functions to construct 3D Scene ---

// --- Helper to resolve custom material properties ---
function getMaterialProps(
  id: string,
  defaultColor: string,
  defaultRoughness: number,
  defaultMetalness: number,
  defaultPresetId: string,
  presets: MaterialPreset[],
  customMaterials: Record<string, string>,
  transparent = false,
  opacity = 1.0
) {
  const customMatId = customMaterials[id];
  const preset = customMatId ? presets.find(p => p.id === customMatId) : null;

  const color = preset ? preset.color : defaultColor;
  const roughness = preset ? preset.roughness : defaultRoughness;
  const metalness = preset ? preset.metalness : defaultMetalness;
  const wireframe = preset ? preset.wireframe : false;

  const mat = new THREE.MeshStandardMaterial({
    color,
    roughness,
    metalness,
    wireframe,
    transparent,
    opacity
  });

  return { mat, color, roughness, metalness, materialPresetId: customMatId || defaultPresetId };
}

// --- Helper to generate crisp text textures for signboards ---
function createSignTexture(text: string, bgColor = '#0284c7', textColor = '#ffffff'): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, 512, 128);
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 8;
    ctx.strokeRect(4, 4, 504, 120);

    ctx.fillStyle = textColor;
    ctx.font = 'bold 36px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, 256, 64);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  return texture;
}

function buildCampusGeometry(
  scene: THREE.Scene, 
  halls: HallData[],
  presets: MaterialPreset[],
  customMaterials: Record<string, string>,
  meshesMap: Map<string, THREE.Mesh>
) {
  // 1. Build Central Boulevard (Glass roofed carpet corridor connecting North & South)
  const blvdProps = getMaterialProps('boulevard-floor', '#1d4ed8', 0.8, 0.1, 'mat-carpet-blue', presets, customMaterials);
  const blvdGeo = new THREE.BoxGeometry(32, 0.4, 520);
  const blvdMesh = new THREE.Mesh(blvdGeo, blvdProps.mat);
  blvdMesh.position.set(0, 0.2, 50);
  blvdMesh.receiveShadow = true;
  blvdMesh.userData = {
    id: 'boulevard-floor',
    name: 'Messe-Boulevard Hauptgang (Teppich)',
    surfaceType: 'floor',
    color: blvdProps.color,
    roughness: blvdProps.roughness,
    metalness: blvdProps.metalness,
    materialPresetId: blvdProps.materialPresetId
  };
  scene.add(blvdMesh);
  meshesMap.set('boulevard-floor', blvdMesh);

  // Boulevard Glass Roof Arches
  for (let z = -200; z <= 300; z += 40) {
    const archGeo = new THREE.TorusGeometry(18, 0.8, 8, 24, Math.PI);
    const archMat = new THREE.MeshStandardMaterial({ color: '#38bdf8', metalness: 0.8, roughness: 0.2 });
    const arch = new THREE.Mesh(archGeo, archMat);
    arch.rotation.x = Math.PI / 2;
    arch.position.set(0, 20, z);
    scene.add(arch);
  }

  // 2. Build Nordeingang Entrance Plaza & Architectural Portal
  // Nordeingang Plaza Pavement Ground Tile
  const plazaGeo = new THREE.BoxGeometry(140, 0.3, 90);
  const plazaMat = new THREE.MeshStandardMaterial({ color: '#334155', roughness: 0.9 });
  const plazaMesh = new THREE.Mesh(plazaGeo, plazaMat);
  plazaMesh.position.set(0, 0.15, -245);
  plazaMesh.receiveShadow = true;
  scene.add(plazaMesh);

  // Nordeingang Glass Foyer Pavilion
  const nordProps = getMaterialProps('nordeingang-facade', '#0284c7', 0.2, 0.6, 'mat-glass-facade', presets, customMaterials, true, 0.8);
  const northEntranceGeo = new THREE.BoxGeometry(80, 24, 40);
  const northEntranceMesh = new THREE.Mesh(northEntranceGeo, nordProps.mat);
  northEntranceMesh.position.set(0, 12, -200);
  northEntranceMesh.castShadow = true;
  northEntranceMesh.userData = {
    id: 'nordeingang-facade',
    name: 'Nordeingang Glaskuppel & Foyer',
    surfaceType: 'glass',
    color: nordProps.color,
    roughness: nordProps.roughness,
    metalness: nordProps.metalness,
    materialPresetId: nordProps.materialPresetId
  };
  scene.add(northEntranceMesh);
  meshesMap.set('nordeingang-facade', northEntranceMesh);

  // Nordeingang Entrance Sign Banner ("NORDEINGANG KOELNMESSE")
  const bannerTexture = createSignTexture('NORDEINGANG KOELNMESSE', '#0369a1', '#ffffff');
  const bannerGeo = new THREE.PlaneGeometry(60, 6);
  const bannerMat = new THREE.MeshBasicMaterial({ map: bannerTexture, side: THREE.DoubleSide });
  const bannerMesh = new THREE.Mesh(bannerGeo, bannerMat);
  bannerMesh.position.set(0, 18, -220.2);
  scene.add(bannerMesh);

  // Nordeingang Steel Pillars & Turnstile Doors
  for (let x = -30; x <= 30; x += 12) {
    const pillarGeo = new THREE.CylinderGeometry(0.5, 0.5, 10, 16);
    const pillarMat = new THREE.MeshStandardMaterial({ color: '#e2e8f0', metalness: 0.9, roughness: 0.1 });
    const pillar = new THREE.Mesh(pillarGeo, pillarMat);
    pillar.position.set(x, 5, -220);
    scene.add(pillar);
  }

  // Nordeingang Glass Canopy Arch Roof
  const canopyGeo = new THREE.TorusGeometry(35, 1.2, 8, 32, Math.PI);
  const canopyMat = new THREE.MeshStandardMaterial({ color: '#0ea5e9', metalness: 0.8, roughness: 0.2, transparent: true, opacity: 0.85 });
  const canopy = new THREE.Mesh(canopyGeo, canopyMat);
  canopy.rotation.x = Math.PI / 2;
  canopy.position.set(0, 22, -225);
  scene.add(canopy);

  // 3. Build Südeingang & Osteingang Portals
  const southEntranceGeo = new THREE.BoxGeometry(70, 20, 30);
  const southEntranceMat = new THREE.MeshStandardMaterial({ color: '#0f766e', roughness: 0.3 });
  const southEntranceMesh = new THREE.Mesh(southEntranceGeo, southEntranceMat);
  southEntranceMesh.position.set(0, 10, 330);
  scene.add(southEntranceMesh);

  const eastEntranceGeo = new THREE.BoxGeometry(40, 25, 60);
  const eastEntranceMat = new THREE.MeshStandardMaterial({ color: '#4338ca', roughness: 0.3 });
  const eastEntranceMesh = new THREE.Mesh(eastEntranceGeo, eastEntranceMat);
  eastEntranceMesh.position.set(310, 12.5, 90);
  scene.add(eastEntranceMesh);

  // 4. Build Exhibition Halls 1 to 11
  halls.forEach((hall) => {
    const [posX, posY, posZ] = hall.position;
    const [width, height, depth] = hall.size;

    // Outer Hall Shell with custom material resolution
    const hallProps = getMaterialProps(hall.id, hall.color, 0.6, 0.2, 'mat-wall-white', presets, customMaterials);

    const hallGeo = new THREE.BoxGeometry(width, height, depth);
    const hallMesh = new THREE.Mesh(hallGeo, hallProps.mat);
    hallMesh.position.set(posX, posY, posZ);
    hallMesh.castShadow = true;
    hallMesh.receiveShadow = true;
    hallMesh.userData = {
      id: hall.id,
      name: hall.name,
      surfaceType: 'wall',
      hallId: hall.id,
      hallName: hall.name,
      color: hallProps.color,
      roughness: hallProps.roughness,
      metalness: hallProps.metalness,
      materialPresetId: hallProps.materialPresetId
    };

    scene.add(hallMesh);
    meshesMap.set(hall.id, hallMesh);

    // Multi-Level Floor Plates (for 2-level or 3-level halls like 5.1/5.2, 10.1/10.2, 11)
    if (hall.levels > 1) {
      for (let lvl = 1; lvl < hall.levels; lvl++) {
        const levelId = `${hall.id}-level-${lvl}`;
        const levelProps = getMaterialProps(levelId, '#475569', 0.8, 0.1, 'mat-concrete-dark', presets, customMaterials);

        const floorHeight = (height / hall.levels) * lvl;
        const plateGeo = new THREE.BoxGeometry(width - 4, 0.8, depth - 4);
        const plateMesh = new THREE.Mesh(plateGeo, levelProps.mat);
        plateMesh.position.set(posX, floorHeight, posZ);
        plateMesh.userData = {
          id: levelId,
          name: `${hall.name} Zwischenebene ${lvl}`,
          surfaceType: 'floor',
          hallId: hall.id,
          hallName: hall.name,
          color: levelProps.color,
          roughness: levelProps.roughness,
          metalness: levelProps.metalness,
          materialPresetId: levelProps.materialPresetId
        };
        scene.add(plateMesh);
        meshesMap.set(levelId, plateMesh);
      }
    }

    // Add Hall Banner / Name Signboard with Canvas Text Texture
    const signTexture = createSignTexture(`HALLE ${hall.hallNumber}`, '#0284c7', '#ffffff');
    const signGeo = new THREE.PlaneGeometry(Math.min(width * 0.7, 50), 6);
    const signMat = new THREE.MeshBasicMaterial({ map: signTexture, side: THREE.DoubleSide });
    const signMesh = new THREE.Mesh(signGeo, signMat);
    signMesh.position.set(posX, posY + height / 2 + 4, posZ);
    scene.add(signMesh);
  });
}

function buildCityGMLLayer(scene: THREE.Scene, buildings: CityGMLBuilding[]) {
  buildings.forEach((bldg) => {
    if (bldg.footprint.length < 3) return;

    const shape = new THREE.Shape();
    bldg.footprint.forEach(([x, z], idx) => {
      if (idx === 0) shape.moveTo(x, z);
      else shape.lineTo(x, z);
    });

    const extrudeSettings = {
      steps: 1,
      depth: bldg.height,
      bevelEnabled: true,
      bevelThickness: 1,
      bevelSize: 0.5,
      bevelSegments: 2
    };

    const geom = new THREE.ExtrudeGeometry(shape, extrudeSettings);
    const mat = new THREE.MeshStandardMaterial({ 
      color: '#38bdf8', 
      wireframe: false, 
      transparent: true, 
      opacity: 0.45,
      metalness: 0.5 
    });

    const mesh = new THREE.Mesh(geom, mat);
    mesh.rotation.x = Math.PI / 2; // Extrude upwards
    mesh.position.y = bldg.height;
    scene.add(mesh);
  });
}

function buildPhotoOverlays(scene: THREE.Scene, photos: InteriorPhoto[]) {
  photos.forEach((photo) => {
    const texture = new THREE.TextureLoader().load(photo.dataUrl);
    const geo = new THREE.PlaneGeometry(60, 40);
    const mat = new THREE.MeshBasicMaterial({ 
      map: texture, 
      transparent: true, 
      opacity: photo.opacity || 0.8,
      side: THREE.DoubleSide
    });
    const quad = new THREE.Mesh(geo, mat);

    // Place inside Hall 6 or default photo target
    quad.position.set(-130, photo.cameraHeight || 8, -120);
    scene.add(quad);
  });
}
