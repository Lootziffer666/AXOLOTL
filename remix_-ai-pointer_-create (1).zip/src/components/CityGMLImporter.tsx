import React, { useState } from 'react';
import { CityGMLBuilding } from '../types/koelnmesse';
import { parseCityGMLText } from '../utils/citygmlParser';
import { Building2, Upload, Eye, EyeOff, FileText, CheckCircle2 } from 'lucide-react';

interface CityGMLImporterProps {
  buildings: CityGMLBuilding[];
  onImportBuildings: (newBuildings: CityGMLBuilding[]) => void;
  showCityGML: boolean;
  onToggleCityGML: () => void;
}

export const CityGMLImporter: React.FC<CityGMLImporterProps> = ({
  buildings,
  onImportBuildings,
  showCityGML,
  onToggleCityGML,
}) => {
  const [fileName, setFileName] = useState<string | null>(null);
  const [isHovered, setIsHovered] = useState(false);

  const handleFileUpload = (file: File) => {
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      if (text) {
        const parsed = parseCityGMLText(text);
        if (parsed.length > 0) {
          onImportBuildings(parsed);
        } else {
          alert("Keine gültigen GML Gebäudestrukturen in der Datei gefunden.");
        }
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="bg-slate-900/95 backdrop-blur-xl border border-slate-800 rounded-3xl p-5 shadow-2xl text-slate-100 max-w-lg w-full">
      {/* Title */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-sky-500/20 text-sky-400 rounded-xl">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-slate-100">NRW CityGML (LoD2) Importer</h3>
            <p className="text-xs text-slate-400">Amtliche 3D-Gebäudemodelle Koelnmesse</p>
          </div>
        </div>

        <button
          onClick={onToggleCityGML}
          className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
            showCityGML 
              ? 'bg-sky-500 text-slate-950 font-bold' 
              : 'bg-slate-800 text-slate-400 hover:text-slate-200'
          }`}
        >
          {showCityGML ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
          {showCityGML ? 'LoD2 Aktiv' : 'LoD2 Inaktiv'}
        </button>
      </div>

      {/* File Upload Zone */}
      <div 
        onDragOver={(e) => { e.preventDefault(); setIsHovered(true); }}
        onDragLeave={() => setIsHovered(false)}
        onDrop={(e) => {
          e.preventDefault();
          setIsHovered(false);
          if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            handleFileUpload(e.dataTransfer.files[0]);
          }
        }}
        className={`mt-4 border-2 border-dashed rounded-2xl p-5 text-center transition ${
          isHovered 
            ? 'border-sky-400 bg-sky-950/40' 
            : 'border-slate-800 bg-slate-950/50 hover:border-slate-700'
        }`}
      >
        <Upload className="w-8 h-8 mx-auto text-sky-400 mb-2 animate-bounce" />
        <p className="text-xs font-medium text-slate-200">
          CityGML Datei hochladen (<code className="text-sky-400">.gml</code> / <code className="text-sky-400">.xml</code>)
        </p>
        <p className="text-[11px] text-slate-500 mt-1">
          z.B. <span className="font-mono text-slate-400">LoD2_357_5645_1_NW.gml</span>, <span className="font-mono text-slate-400">LoD2_357_5646_1_NW.gml</span>
        </p>

        <label className="mt-3 inline-block px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs rounded-xl cursor-pointer transition">
          Datei auswählen
          <input 
            type="file" 
            accept=".gml,.xml"
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                handleFileUpload(e.target.files[0]);
              }
            }}
          />
        </label>
      </div>

      {/* Loaded Buildings Stats */}
      <div className="mt-4">
        <div className="flex justify-between items-center text-xs text-slate-400 mb-2">
          <span>Geladene LoD2 Bausteine:</span>
          <span className="font-mono text-sky-400 font-bold">{buildings.length} Gebäude</span>
        </div>

        <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1 custom-scrollbar">
          {buildings.map((bldg) => (
            <div key={bldg.gmlId} className="flex items-center justify-between text-xs p-2 bg-slate-950/80 rounded-xl border border-slate-800">
              <div className="flex items-center gap-2 truncate">
                <FileText className="w-3.5 h-3.5 text-sky-400 flex-shrink-0" />
                <span className="truncate font-mono text-[11px] text-slate-200">{bldg.name}</span>
              </div>
              <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full font-mono">
                {bldg.measuredHeight}m Höhe
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
