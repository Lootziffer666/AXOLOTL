package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.DashboardCustomize
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Room
import com.example.db.AppDatabase
import com.example.db.MemoryEntity
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.RouterViewModel
import android.widget.Toast
import kotlinx.coroutines.launch
import java.net.NetworkInterface

class MainActivity : ComponentActivity() {
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "memwiki-db"
        ).fallbackToDestructiveMigration().build()

        setContent {
            MyApplicationTheme {
                val viewModel: RouterViewModel = viewModel(
                    factory = object : ViewModelProvider.Factory {
                        override fun <T : ViewModel> create(modelClass: Class<T>): T {
                            @Suppress("UNCHECKED_CAST")
                            return RouterViewModel(applicationContext, db) as T
                        }
                    }
                )
                RouterApp(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RouterApp(viewModel: RouterViewModel) {
    var currentTab by remember { mutableStateOf("Übersicht") }
    
    val configState by viewModel.configState.collectAsStateWithLifecycle()
    val isRunning by viewModel.isServerRunning.collectAsStateWithLifecycle(false)
    val memories by viewModel.memories.collectAsStateWithLifecycle(emptyList())

    val isSystemDark = isSystemInDarkTheme()
    val darkTheme = when (configState.themeMode) {
        com.example.models.ThemeMode.LIGHT -> false
        com.example.models.ThemeMode.DARK -> true
        com.example.models.ThemeMode.SYSTEM -> isSystemDark
    }

    MyApplicationTheme(darkTheme = darkTheme) {
        val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
        val context = LocalContext.current
        val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current

        val openUrl by viewModel.openBrowserEvent.collectAsStateWithLifecycle()
        val toastMsg by viewModel.toastEvent.collectAsStateWithLifecycle()
        val pendingProviderId by viewModel.pendingProviderId.collectAsStateWithLifecycle()

        DisposableEffect(lifecycleOwner) {
            val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
                if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                    viewModel.checkClipboardForApiKey(context)
                }
            }
            lifecycleOwner.lifecycle.addObserver(observer)
            onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
        }

        LaunchedEffect(toastMsg) {
            toastMsg?.let { msg ->
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                viewModel.clearToastEvent()
            }
        }

        LaunchedEffect(openUrl) {
            openUrl?.let { url ->
                try {
                    uriHandler.openUri(url)
                } catch (e: Exception) {
                    // ignoring uri errors
                }
                viewModel.clearOpenBrowserEvent()
            }
        }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(androidx.compose.material.icons.Icons.Default.DashboardCustomize, contentDescription = "Logo", modifier = Modifier.padding(end = 8.dp))
                            Text("Bellows", fontWeight = FontWeight.Bold)
                        }
                    },
                    actions = {
                        IconButton(onClick = { /* TODO */ }) {
                            Icon(androidx.compose.material.icons.Icons.Default.Notifications, contentDescription = "Notifications")
                        }
                        IconButton(onClick = { 
                            val nextMode = when (configState.themeMode) {
                                com.example.models.ThemeMode.LIGHT -> com.example.models.ThemeMode.DARK
                                com.example.models.ThemeMode.DARK -> com.example.models.ThemeMode.SYSTEM
                                com.example.models.ThemeMode.SYSTEM -> com.example.models.ThemeMode.LIGHT
                            }
                            viewModel.updateConfig { it.copy(themeMode = nextMode) }
                        }) {
                            Text(
                                text = when (configState.themeMode) {
                                    com.example.models.ThemeMode.LIGHT -> "☀️"
                                    com.example.models.ThemeMode.DARK -> "🌙"
                                    com.example.models.ThemeMode.SYSTEM -> "⚙️"
                                },
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                        titleContentColor = MaterialTheme.colorScheme.onBackground
                    )
                )
            },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.background) {
                NavigationBarItem(
                    selected = currentTab == "Übersicht",
                    onClick = { currentTab = "Übersicht" },
                    icon = { Icon(androidx.compose.material.icons.Icons.Default.Home, contentDescription = "Übersicht") },
                    label = { Text("Übersicht") }
                )
                NavigationBarItem(
                    selected = currentTab == "PWA Apps",
                    onClick = { currentTab = "PWA Apps" },
                    icon = { Icon(androidx.compose.material.icons.Icons.Default.DashboardCustomize, contentDescription = "PWA Apps") },
                    label = { Text("PWA Apps") }
                )
                NavigationBarItem(
                    selected = currentTab == "Routing",
                    onClick = { currentTab = "Routing" },
                    icon = { Icon(androidx.compose.material.icons.Icons.Default.Route, contentDescription = "Routing") },
                    label = { Text("Routing") }
                )
                NavigationBarItem(
                    selected = currentTab == "Provider",
                    onClick = { currentTab = "Provider" },
                    icon = { Icon(androidx.compose.material.icons.Icons.Default.Cloud, contentDescription = "Provider") },
                    label = { Text("Provider") }
                )
                NavigationBarItem(
                    selected = currentTab == "Ereignisse",
                    onClick = { currentTab = "Ereignisse" },
                    icon = { Icon(androidx.compose.material.icons.Icons.Default.Warning, contentDescription = "MemWiki") },
                    label = { Text("MemWiki") }
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Harvester Overlay UI Bar
                if (pendingProviderId != null) {
                    val allProviders = viewModel.defaultProviders + configState.customProviders
                    val pendingProvider = allProviders.find { it.id == pendingProviderId }
                    val providerName = pendingProvider?.name ?: "Provider"

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                        elevation = CardDefaults.cardElevation(6.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    "🎯 Key-Harvester aktiv: $providerName",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    "Kopiere den API-Key im Browser. Er wird automatisch erkannt & gespeichert!",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                )
                            }
                            Spacer(Modifier.width(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Button(
                                    onClick = { viewModel.checkClipboardForApiKey(context) },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Text("📋 Prüfen", style = MaterialTheme.typography.labelSmall)
                                }
                                Button(
                                    onClick = { viewModel.stopWizard() },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                                ) {
                                    Text("⏹️ Stopp", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    when (currentTab) {
                        "Übersicht" -> { ProvidersScreen(viewModel) }
                        "PWA Apps" -> { PwaModulesScreen(viewModel) }
                        "Routing" -> {
                            ServerScreen(
                                configState = configState,
                                isRunning = isRunning,
                                onConfigChange = { viewModel.updateConfig(it) },
                                onToggleServer = { viewModel.toggleServer() }
                            )
                        }
                        "Provider" -> { ProvidersScreen(viewModel) }
                        "Ereignisse" -> {
                            MemWikiScreen(
                                memories = memories,
                                onClear = { viewModel.clearMemWiki() }
                            )
                        }
                        else -> { ProvidersScreen(viewModel) }
                    }
                }
            }
        }
    }
    }
}

@Composable
fun ServerScreen(
    configState: com.example.models.ConfigState,
    isRunning: Boolean,
    onConfigChange: ((com.example.models.ConfigState) -> com.example.models.ConfigState) -> Unit,
    onToggleServer: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = if (isRunning) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (isRunning) "Server is Running" else "Server is Stopped",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Switch(
                            checked = isRunning,
                            onCheckedChange = { onToggleServer() }
                        )
                    }
                    if (isRunning) {
                        Spacer(Modifier.height(8.dp))
                        Text("Connect external tools to:", style = MaterialTheme.typography.bodyMedium)
                        val ip = getLocalIpAddress() ?: "127.0.0.1"
                        Text(
                            text = "http://$ip:${configState.localServerPort}/v1/chat/completions",
                            style = MaterialTheme.typography.bodyLarge,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Local Route Key: ${configState.localApiKey}",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        item {
            Text("Local API Configuration", style = MaterialTheme.typography.titleMedium)
        }

        item {
            OutlinedTextField(
                value = configState.localApiKey,
                onValueChange = { onConfigChange { c -> c.copy(localApiKey = it) } },
                label = { Text("Local Output API Key (Custom Generator)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }
        
        item {
            Text("Configure your provider API keys in the 'Providers' tab. Models starting with 'gpt-' route to OpenAI, 'gemini' to Gemini, etc. (You can configure routing logic).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun ProvidersScreen(viewModel: RouterViewModel) {
    val configState by viewModel.configState.collectAsStateWithLifecycle()
    val allProviders = viewModel.defaultProviders + configState.customProviders
    
    var searchQuery by remember { mutableStateOf("") }
    var sortAscending by remember { mutableStateOf(true) }
    var showAddDialog by remember { mutableStateOf(false) }

    val filteredProviders = remember(allProviders, searchQuery, sortAscending) {
        val filtered = if (searchQuery.isBlank()) {
            allProviders
        } else {
            allProviders.filter { it.name.contains(searchQuery, ignoreCase = true) || it.modelsList.any { m -> m.contains(searchQuery, ignoreCase = true) } }
        }
        if (sortAscending) {
            filtered.sortedBy { it.name.lowercase() }
        } else {
            filtered.sortedByDescending { it.name.lowercase() }
        }
    }
    
    if (showAddDialog) {
        AddCustomProviderDialog(
            onDismiss = { showAddDialog = false },
            onAdd = { provider ->
                viewModel.addCustomProvider(provider)
                showAddDialog = false
            }
        )
    }

    Column(modifier = Modifier.fillMaxSize()) {        
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 160.dp),
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Provider-Übersicht", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Tippe auf einen Provider ohne Key, um die API-Seite zu öffnen & Keys automatisch zu kopieren.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.startAutoWizard() },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("⚡ Auto-Setup Keys", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = { showAddDialog = true }
                        ) {
                            Text("➕ Custom Provider")
                        }
                    }

                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Provider oder Modelle suchen...") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                    )
                }
            }
            
            items(filteredProviders, key = { it.id }) { provider ->
                ProviderAccordion(
                    provider = provider,
                    currentKey = configState.apiKeys[provider.id] ?: "",
                    onKeyChange = { viewModel.updateProviderKey(provider.id, it) },
                    onOpenRegistration = { viewModel.openProviderRegistration(provider.id) }
                )
            }
            
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column {
                    Spacer(Modifier.height(16.dp))
                    PrimaryProviderSection()
                    Spacer(Modifier.height(16.dp))
                    FallbackChainSection()
                    Spacer(Modifier.height(16.dp))
                    SystemHealthSection()
                    Spacer(Modifier.height(16.dp))
                    QuickActionsSection()
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProviderAccordion(
    provider: com.example.models.ProviderInfo,
    currentKey: String,
    onKeyChange: (String) -> Unit,
    onOpenRegistration: () -> Unit
) {
    val hasKey = currentKey.isNotBlank()

    Card(
        modifier = Modifier.fillMaxWidth().aspectRatio(0.80f),
        colors = CardDefaults.cardColors(
            containerColor = if (hasKey) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
        ),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (hasKey) MaterialTheme.colorScheme.primary.copy(alpha = 0.6f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
        ),
        onClick = { onOpenRegistration() }
    ) {
        Column(
            Modifier.padding(12.dp).fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier.size(40.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (hasKey) androidx.compose.material.icons.Icons.Default.CheckCircle else androidx.compose.material.icons.Icons.Default.Cloud, 
                    contentDescription = null,
                    modifier = Modifier.size(28.dp),
                    tint = if (hasKey) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                )
            }
            
            Text(
                text = provider.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                maxLines = 1
            )
            
            Surface(
                color = if (hasKey) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.tertiaryContainer,
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = if (hasKey) "🔑 Key aktiv" else "⚡ Kein Key (Auto-Setup)",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (hasKey) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onTertiaryContainer,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    fontWeight = FontWeight.Bold
                )
            }
            
            Text(
                text = if (provider.modelsList.isNotEmpty()) "${provider.modelsList.size} Modelle available" else "API Connection",
                style = MaterialTheme.typography.bodySmall, 
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                maxLines = 1
            )
        }
    }
}

@Composable
fun AddCustomProviderDialog(onDismiss: () -> Unit, onAdd: (com.example.models.ProviderInfo) -> Unit) {
    var name by remember { mutableStateOf("") }
    var apiUrl by remember { mutableStateOf("https://api.example.com/v1/chat/completions") }
    var models by remember { mutableStateOf("") }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Custom Provider") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Provider Name") }, singleLine = true)
                OutlinedTextField(value = apiUrl, onValueChange = { apiUrl = it }, label = { Text("API URL (OpenAI compatible)") }, singleLine = true)
                OutlinedTextField(value = models, onValueChange = { models = it }, label = { Text("Known Models (comma separated)") })
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val id = "custom_" + java.util.UUID.randomUUID().toString().take(8)
                    val modelList = models.split(",").map { it.trim() }.filter { it.isNotBlank() }
                    onAdd(com.example.models.ProviderInfo(id, name, "", apiUrl, modelList, isCustom = true))
                },
                enabled = name.isNotBlank() && apiUrl.isNotBlank()
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun MemWikiScreen(memories: List<MemoryEntity>, onClear: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(), 
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Persistent MemWiki", style = MaterialTheme.typography.titleLarge)
            IconButton(onClick = onClear) {
                Icon(Icons.Default.Delete, contentDescription = "Clear All Memories")
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "To add memories, send a message to the router containing 'remember that ...'.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(16.dp))

        if (memories.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No memories stored yet.", color = MaterialTheme.colorScheme.outline)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(memories, key = { it.id }) { memory ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(memory.summary, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Stored ${java.util.Date(memory.timestamp)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

fun getLocalIpAddress(): String? {
    try {
        val interfaces = NetworkInterface.getNetworkInterfaces()
        while (interfaces.hasMoreElements()) {
            val iface = interfaces.nextElement()
            if (iface.isLoopback || !iface.isUp) continue
            
            val addresses = iface.inetAddresses
            while (addresses.hasMoreElements()) {
                val addr = addresses.nextElement()
                if (!addr.isLoopbackAddress && addr is java.net.Inet4Address) {
                    return addr.hostAddress
                }
            }
        }
    } catch (e: Exception) {
        // Ignore
}
    return null
}

@Composable
fun PrimaryProviderSection() {
    Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = androidx.compose.ui.Modifier.weight(1f)) {
            Text("Primärer Provider & Fallback-Kette", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Spacer(androidx.compose.ui.Modifier.height(8.dp))
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = androidx.compose.ui.Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(androidx.compose.material.icons.Icons.Default.Cloud, contentDescription = null)
                        Spacer(androidx.compose.ui.Modifier.width(8.dp))
                        Column {
                            Text("OpenAI", fontWeight = FontWeight.Bold)
                            Text("Stabil", color = androidx.compose.ui.graphics.Color(0xFF27AE60), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    Icon(androidx.compose.material.icons.Icons.Default.KeyboardArrowUp, contentDescription = "Arrow")
                }
            }
        }
    }
}

@Composable
fun FallbackChainSection() {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), modifier = androidx.compose.ui.Modifier.fillMaxWidth()) {
        Column(androidx.compose.ui.Modifier.padding(16.dp).fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = androidx.compose.ui.Modifier.fillMaxWidth()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(androidx.compose.material.icons.Icons.Default.Cloud, contentDescription = null)
                    Text("OpenAI", style = MaterialTheme.typography.labelSmall)
                }
                Icon(Icons.Default.KeyboardArrowRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Cloud, contentDescription = null)
                    Text("Anthropic", style = MaterialTheme.typography.labelSmall)
                }
                Icon(Icons.Default.KeyboardArrowRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Cloud, contentDescription = null)
                    Text("Gemini", style = MaterialTheme.typography.labelSmall)
                }
                Icon(Icons.Default.KeyboardArrowRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(androidx.compose.material.icons.Icons.Default.Settings, contentDescription = null)
                    Text("Lokal", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
fun SystemHealthSection() {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), modifier = androidx.compose.ui.Modifier.fillMaxWidth()) {
        Row(androidx.compose.ui.Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(androidx.compose.material.icons.Icons.Default.CheckCircle, contentDescription = null, tint = androidx.compose.ui.graphics.Color.Green, modifier = androidx.compose.ui.Modifier.size(16.dp))
                    Spacer(androidx.compose.ui.Modifier.width(4.dp))
                    Text("Systemzustand", style = MaterialTheme.typography.labelMedium)
                }
                Text("Gesund", fontWeight = FontWeight.Bold)
                Text("Letzter Check: vor 1 Min.", style = MaterialTheme.typography.labelSmall)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("Auslastung (gesamt)", style = MaterialTheme.typography.labelMedium)
                Text("28%", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun QuickActionsSection() {
    Row(androidx.compose.ui.Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton(onClick = {}, modifier = androidx.compose.ui.Modifier.background(MaterialTheme.colorScheme.surfaceVariant, shape = androidx.compose.foundation.shape.CircleShape)) {
                Icon(androidx.compose.material.icons.Icons.Default.Route, contentDescription = null)
            }
            Text("Route Test", style = MaterialTheme.typography.labelSmall)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton(onClick = {}, modifier = androidx.compose.ui.Modifier.background(MaterialTheme.colorScheme.surfaceVariant, shape = androidx.compose.foundation.shape.CircleShape)) {
                Icon(androidx.compose.material.icons.Icons.Default.DashboardCustomize, contentDescription = null)
            }
            Text("Ansichten", style = MaterialTheme.typography.labelSmall)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton(onClick = {}, modifier = androidx.compose.ui.Modifier.background(MaterialTheme.colorScheme.surfaceVariant, shape = androidx.compose.foundation.shape.CircleShape)) {
                Icon(androidx.compose.material.icons.Icons.Default.Key, contentDescription = null)
            }
            Text("API Keys", style = MaterialTheme.typography.labelSmall)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton(onClick = {}, modifier = androidx.compose.ui.Modifier.background(MaterialTheme.colorScheme.surfaceVariant, shape = androidx.compose.foundation.shape.CircleShape)) {
                Icon(Icons.Default.Menu, contentDescription = null)
            }
            Text("Open Logs", style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun PwaModulesScreen(viewModel: RouterViewModel) {
    val modules by viewModel.pwaModules.collectAsStateWithLifecycle(emptyList())
    var activeModule by remember { mutableStateOf<com.example.db.PwaModuleEntity?>(null) }
    var showGenerateDialog by remember { mutableStateOf(false) }
    var editingModule by remember { mutableStateOf<com.example.db.PwaModuleEntity?>(null) }

    if (activeModule != null) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { activeModule = null },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(modifier = Modifier.fillMaxSize()) {
                Column(modifier = Modifier.fillMaxSize()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = activeModule?.title ?: "PWA App",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                        IconButton(onClick = { activeModule = null }) {
                            Text("❌")
                        }
                    }
                    com.example.ui.PwaContainerView(
                        htmlContent = activeModule?.htmlContent ?: "",
                        viewModel = viewModel,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }

    if (showGenerateDialog) {
        var promptText by remember { mutableStateOf("") }
        var isGenerating by remember { mutableStateOf(false) }
        var statusMsg by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { if (!isGenerating) showGenerateDialog = false },
            title = { Text("KI App Generator") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Beschreibe die PWA Micro-App, die Bellows live für dich bauen und speichern soll:")
                    OutlinedTextField(
                        value = promptText,
                        onValueChange = { promptText = it },
                        label = { Text("App Idee (z.B. AI Task Planner, Color Palette Generator)") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        enabled = !isGenerating
                    )
                    Text("Schnell-Vorlagen:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        SuggestionChip(
                            onClick = { promptText = "Interaktiver Soundboard & Synth Audio Generator mit WebAudio API" },
                            label = { Text("🎵 Synth", style = MaterialTheme.typography.labelSmall) }
                        )
                        SuggestionChip(
                            onClick = { promptText = "Farbschema & Palette Generator mit Copy to Clipboard" },
                            label = { Text("🎨 Colors", style = MaterialTheme.typography.labelSmall) }
                        )
                        SuggestionChip(
                            onClick = { promptText = "Interaktives Multiple-Choice Quiz mit AI Auswertung" },
                            label = { Text("🎮 Quiz", style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                    if (isGenerating) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Bellows LLM baut deine App...", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    if (statusMsg.isNotBlank()) {
                        Text(statusMsg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isGenerating = true
                        statusMsg = "Anfrage wird verarbeitet..."
                        viewModel.generatePwaModule(promptText) { success, msg ->
                            isGenerating = false
                            statusMsg = msg
                            if (success) {
                                showGenerateDialog = false
                            }
                        }
                    },
                    enabled = promptText.isNotBlank() && !isGenerating
                ) {
                    Text("Generieren")
                }
            },
            dismissButton = {
                TextButton(onClick = { showGenerateDialog = false }, enabled = !isGenerating) {
                    Text("Abbrechen")
                }
            }
        )
    }

    if (editingModule != null) {
        var codeText by remember { mutableStateOf(editingModule?.htmlContent ?: "") }
        var titleText by remember { mutableStateOf(editingModule?.title ?: "") }

        AlertDialog(
            onDismissRequest = { editingModule = null },
            title = { Text("PWA Code Editor") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = titleText,
                        onValueChange = { titleText = it },
                        label = { Text("Titel") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = codeText,
                        onValueChange = { codeText = it },
                        label = { Text("HTML/JS/CSS Code") },
                        modifier = Modifier.fillMaxWidth().height(300.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace)
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.savePwaModule(
                        title = titleText,
                        description = editingModule?.description ?: "",
                        htmlContent = codeText,
                        category = editingModule?.category ?: "Custom",
                        id = editingModule?.id
                    )
                    editingModule = null
                }) {
                    Text("Speichern")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingModule = null }) { Text("Abbrechen") }
            }
        )
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Dynamische PWA Module", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Self-expanding live apps without recompiling", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Button(onClick = { showGenerateDialog = true }) {
                Text("➕ KI App")
            }
        }

        Spacer(Modifier.height(16.dp))

        if (modules.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Keine PWA Apps vorhanden. Generiere deine erste KI App!", color = MaterialTheme.colorScheme.outline)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(modules, key = { it.id }) { mod ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(mod.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp)
                                ) {
                                    Text(mod.category, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                                }
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(mod.description, style = MaterialTheme.typography.bodyMedium, maxLines = 2)
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { activeModule = mod }) {
                                    Text("▶️ Starten")
                                }
                                OutlinedButton(onClick = { editingModule = mod }) {
                                    Text("✏️ Code")
                                }
                                IconButton(onClick = { viewModel.deletePwaModule(mod.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Löschen")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}