package com.example.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement

@Serializable
data class OpenAiChatRequest(
    val model: String,
    val messages: List<ChatMessage>,
    val temperature: Float? = null,
    val stream: Boolean? = false,
    @SerialName("max_tokens") val maxTokens: Int? = null
)

@Serializable
data class ChatMessage(
    val role: String,
    val content: String
)

@Serializable
data class OpenAiChatResponse(
    val id: String,
    val `object`: String = "chat.completion",
    val created: Long,
    val model: String,
    val choices: List<Choice>,
    val usage: Usage? = null
)

@Serializable
data class Choice(
    val index: Int,
    val message: ChatMessage,
    @SerialName("finish_reason") val finishReason: String? = null
)

@Serializable
data class Usage(
    @SerialName("prompt_tokens") val promptTokens: Int,
    @SerialName("completion_tokens") val completionTokens: Int,
    @SerialName("total_tokens") val totalTokens: Int
)

@Serializable
data class ProviderInfo(
    val id: String,
    val name: String,
    val registrationUrl: String,
    val apiUrl: String,
    val modelsList: List<String>,
    val capabilities: List<String> = emptyList(),
    val isCustom: Boolean = false
)

@Serializable
enum class ThemeMode { LIGHT, DARK, SYSTEM }

@Serializable
data class ConfigState(
    val themeMode: ThemeMode = ThemeMode.LIGHT,
    val customProviders: List<ProviderInfo> = emptyList(),
    val apiKeys: Map<String, String> = emptyMap(),
    val geminiApiKey: String = "",
    val openaiApiKey: String = "",
    val anthropicApiKey: String = "",
    val localServerPort: Int = 8080,
    val isRunning: Boolean = false,
    val localApiKey: String = "sk-local-router-1234"
)
