package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = DsSecondary,
    onPrimary = Color.White,
    primaryContainer = DsPrimaryDark,
    onPrimaryContainer = Color.White,
    secondary = DsSecondary,
    onSecondary = Color.White,
    background = DsBackgroundDark,
    onBackground = DsTextDark,
    surface = DsCardDark,
    onSurface = DsTextDark,
    surfaceVariant = DsCardDark,
    onSurfaceVariant = DsTextMutedDark,
    outline = DsBorderDark,
    error = DsError,
    onError = Color.White
  )

private val LightColorScheme =
  lightColorScheme(
    primary = DsPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE8F0F5),
    onPrimaryContainer = DsPrimary,
    secondary = DsSecondary,
    onSecondary = Color.White,
    background = DsBackground,
    onBackground = DsText,
    surface = DsCard,
    onSurface = DsText,
    surfaceVariant = DsCard,
    onSurfaceVariant = DsTextMuted,
    outline = DsBorder,
    error = DsError,
    onError = Color.White
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
