package com.example.ui

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewModelScope
import com.example.models.ChatMessage
import com.example.models.OpenAiChatRequest
import com.example.server.ExternalApiRouter
import com.example.viewmodel.RouterViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BellowsBridge(
    private val context: Context,
    private val webView: WebView,
    private val viewModel: RouterViewModel
) {
    private val handler = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun toast(message: String) {
        handler.post {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }

    @JavascriptInterface
    fun chat(prompt: String, model: String, callbackName: String) {
        viewModel.chatDirect(prompt, model) { result ->
            handler.post {
                val quotedResult = org.json.JSONObject.quote(result)
                webView.evaluateJavascript("if (window['$callbackName']) { window['$callbackName']($quotedResult); }", null)
            }
        }
    }

    @JavascriptInterface
    fun saveMemory(summary: String, jsonPayload: String) {
        viewModel.viewModelScope.launch {
            viewModel.db.memoryDao().insertMemory(
                com.example.db.MemoryEntity(
                    id = java.util.UUID.randomUUID().toString(),
                    summary = summary,
                    jsonPayload = jsonPayload,
                    timestamp = System.currentTimeMillis()
                )
            )
            handler.post {
                Toast.makeText(context, "Saved to MemWiki: $summary", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @JavascriptInterface
    fun notify(message: String) {
        toast(message)
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PwaContainerView(
    htmlContent: String,
    viewModel: RouterViewModel,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()

    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = { ctx ->
            WebView(ctx).apply {
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    loadWithOverviewMode = true
                    useWideViewPort = true
                    allowFileAccess = true
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                }
                
                webViewClient = WebViewClient()
                
                val bridge = BellowsBridge(ctx, this, viewModel)
                addJavascriptInterface(bridge, "bellows")

                loadDataWithBaseURL("https://bellows.local/", htmlContent, "text/html", "UTF-8", null)
            }
        },
        update = { webView ->
            webView.loadDataWithBaseURL("https://bellows.local/", htmlContent, "text/html", "UTF-8", null)
        }
    )
}
