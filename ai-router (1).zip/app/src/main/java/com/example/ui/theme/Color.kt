package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DsPrimary = Color(0xFF0C3C5A)     // Dark Blue
val DsPrimaryDark = Color(0xFF08273A)
val DsSecondary = Color(0xFFF8994A)   // Orange
val DsSuccess = Color(0xFF27AE60)
val DsInfo = Color(0xFF2F80ED)
val DsWarning = Color(0xFFE2B93B)
val DsError = Color(0xFFEB5757)

val DsBackground = Color(0xFFF0F0F0) // Surface
val DsBackgroundDark = Color(0xFF141414)
val DsCard = Color(0xFFFFFFFF)
val DsCardDark = Color(0xFF202020)

val DsText = Color(0xFF1A1A1A)
val DsTextDark = Color(0xFFE0E0E0)
val DsTextMuted = Color(0xFF666666)
val DsTextMutedDark = Color(0xFFAAAAAA)
val DsBorder = Color(0xFFE0E0E0)
val DsBorderDark = Color(0xFF333333)
