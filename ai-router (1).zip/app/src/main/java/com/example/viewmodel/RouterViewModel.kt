package com.example.viewmodel

import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.db.AppDatabase
import com.example.db.MemoryEntity
import com.example.models.ConfigState
import com.example.models.ProviderInfo
import com.example.server.ExternalApiRouter
import com.example.server.LocalRouterServer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import java.util.UUID

class RouterViewModel(
    private val context: Context,
    val db: AppDatabase
) : ViewModel() {

    val defaultProviders = listOf(
        ProviderInfo("cohere", "Cohere", "https://dashboard.cohere.com/api-keys", "https://api.cohere.ai/v1/chat/completions", listOf("Command A (111B)", "Command R+", "Command R", "Command R7B", "Embed 4"), listOf("Reasoning", "Long Context")),
        ProviderInfo("gemini", "Google Gemini", "https://aistudio.google.com/app/apikey", "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", listOf("Gemini 2.5 Flash", "Gemini 2.5 Flash-Lite"), listOf("Reasoning", "Vision", "Long Context", "Fast")),
        ProviderInfo("mistral", "Mistral AI", "https://console.mistral.ai/api-keys/", "https://api.mistral.ai/v1/chat/completions", listOf("Mistral Small 4", "Mistral Medium 3", "Mistral Large 3", "Mistral Nemo (12B)", "Codestral"), listOf("Coding", "Fast")),
        ProviderInfo("zai", "Z.AI", "https://z.ai", "https://api.z.ai/v1/chat/completions", listOf("GLM-4.7-Flash", "GLM-4.5-Flash", "GLM-4.6V-Flash"), listOf("Vision")),
        ProviderInfo("cerebras", "Cerebras", "https://cloud.cerebras.ai/", "https://api.cerebras.ai/v1/chat/completions", listOf("llama3.1-8b", "gpt-oss-120b", "qwen-3-235b", "zai-glm-4.7"), listOf("Fast", "Cheap")),
        ProviderInfo("github", "GitHub Models", "https://github.com/settings/tokens", "https://models.inference.ai.azure.com/chat/completions", listOf("gpt-4.1", "gpt-4.1-mini", "gpt-4o", "o3-mini", "o4-mini"), listOf("Coding", "Tool Calling", "Reasoning")),
        ProviderInfo("groq", "Groq", "https://console.groq.com/keys", "https://api.groq.com/openai/v1/chat/completions", listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant", "llama-4-scout", "llama-4-maverick", "kimi-k2"), listOf("Super Fast")),
        ProviderInfo("huggingface", "Hugging Face", "https://huggingface.co/settings/tokens", "https://api-inference.huggingface.co/v1/chat/completions", listOf("Meta-Llama-3.1-8B-Instruct", "Mistral-7B-Instruct-v0.3", "Mixtral-8x7B", "Phi-3.5-mini", "Qwen2.5-7B"), listOf("Open Source")),
        ProviderInfo("kilocode", "Kilo Code", "https://kilocode.com/", "https://api.kilocode.com/v1/chat/completions", listOf("dola-seed-2.0-pro:free", "grok-code-fast-1:free", "nemotron-3-super:free", "trinity-large-thinking:free", "openrouter/free"), listOf("Coding")),
        ProviderInfo("llm7", "LLM7.io", "https://llm7.io/", "https://api.llm7.io/v1/chat/completions", listOf("deepseek-r1-0528", "deepseek-v3-0324", "gemini-2.5-flash-lite", "gpt-4o-mini", "mistral-small-3.1-24b"), listOf("Reasoning", "Cheap")),
        ProviderInfo("nvidia", "NVIDIA NIM", "https://build.nvidia.com/", "https://integrate.api.nvidia.com/v1/chat/completions", listOf("deepseek-ai/deepseek-r1", "nvidia/llama-3.1-nemotron", "nvidia/nemotron-3-super", "meta/llama-3.1-405b", "qwen/qwen2.5-72b"), listOf("Vision", "Reasoning")),
        ProviderInfo("ollamacloud", "Ollama Cloud", "https://ollama.com/", "https://api.ollama.com/v1/chat/completions", listOf("llama3.1:cloud", "deepseek-r1:cloud", "qwen2.5:cloud", "gemma2:cloud", "mistral:cloud"), listOf("Open Source", "Cheap")),
        ProviderInfo("openrouter", "OpenRouter", "https://openrouter.ai/keys", "https://openrouter.ai/api/v1/chat/completions", listOf("deepseek/deepseek-r1-0528:free", "deepseek/deepseek-chat-v3-0324:free", "qwen/qwen3.6-plus:free", "meta-llama/llama-4-scout:free", "openai/gpt-oss-120b:free"), listOf("All Models")),
        ProviderInfo("siliconflow", "SiliconFlow", "https://cloud.siliconflow.cn/account/ak", "https://api.siliconflow.cn/v1/chat/completions", listOf("Qwen/Qwen3-8B", "DeepSeek-R1-0528-Qwen3-8B", "DeepSeek-R1-Distill-Qwen-7B", "glm-4-9b-chat", "GLM-4.1V-9B-Thinking"), listOf("Chinese & English")),
        ProviderInfo("ollama", "Ollama (Local)", "http://127.0.0.1:11434", "http://127.0.0.1:11434/v1/chat/completions", listOf("llama3.2", "qwen2.5", "mistral", "phi3"), listOf("Local", "Private", "Open Source")),
        ProviderInfo("lmstudio", "LM Studio (Local)", "http://127.0.0.1:1234", "http://127.0.0.1:1234/v1/chat/completions", listOf("Any loaded model"), listOf("Local", "Private", "GUI")),
        ProviderInfo("opencode", "Opencode (Local)", "http://127.0.0.1:8000", "http://127.0.0.1:8000/v1/chat/completions", listOf("opencode-base"), listOf("Local", "Private", "Coding")),
        ProviderInfo("aiedge", "AI Edge Gallery (Local)", "http://localhost:8080", "http://localhost:8080/v1/chat/completions", listOf("gemma2", "phi3"), listOf("Local", "On-Device")),
        ProviderInfo("anythingllm", "AnythingLLM (Local)", "http://localhost:3001", "http://localhost:3001/api/v1/openai/chat/completions", listOf("workspace-model"), listOf("Local", "RAG", "Memory"))
    )

    private val prefs = context.getSharedPreferences("router_prefs", Context.MODE_PRIVATE)

    private val _configState = MutableStateFlow(loadConfig())
    val configState = _configState.asStateFlow()

    private val _pendingProviderId = MutableStateFlow<String?>(null)
    val pendingProviderId = _pendingProviderId.asStateFlow()

    private val _openBrowserEvent = MutableStateFlow<String?>(null)
    val openBrowserEvent = _openBrowserEvent.asStateFlow()

    private val localServer = LocalRouterServer(db)
    
    private val router = ExternalApiRouter(
        getAppConfig = { _configState.value },
        getProviders = { defaultProviders + _configState.value.customProviders }
    )

    val isServerRunning = localServer.isRunning
    val memories = db.memoryDao().getAllMemoriesFlow()
    val pwaModules = db.pwaModuleDao().getAllPwaModulesFlow()

    init {
        // Pre-seed default PWA modules if empty
        viewModelScope.launch {
            if (db.pwaModuleDao().getPwaModuleById("default-md-editor") == null) {
                seedDefaultPwaModules()
            }
        }
    }

    private suspend fun seedDefaultPwaModules() {
        val mdEditor = com.example.db.PwaModuleEntity(
            id = "default-md-editor",
            title = "AI Markdown Studio",
            description = "Live Markdown editor with instant preview and AI assistant integration",
            category = "Productivity",
            updatedAt = System.currentTimeMillis(),
            htmlContent = """
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <title>AI Markdown Studio</title>
                    <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
                    <style>
                        body { font-family: system-ui, sans-serif; margin: 0; padding: 12px; background: #121212; color: #e0e0e0; }
                        h2 { margin-top: 0; color: #f8994a; }
                        .container { display: flex; flex-direction: column; gap: 10px; height: 90vh; }
                        textarea { width: 100%; height: 35vh; background: #1e1e1e; color: #fff; border: 1px solid #333; border-radius: 8px; padding: 10px; font-family: monospace; box-sizing: border-box; }
                        .preview { flex: 1; background: #1e1e1e; border: 1px solid #333; border-radius: 8px; padding: 12px; overflow-y: auto; }
                        .controls { display: flex; gap: 8px; }
                        button { background: #f8994a; color: #fff; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: bold; }
                        button:hover { background: #e08030; }
                    </style>
                </head>
                <body>
                    <h2>📝 AI Markdown Studio</h2>
                    <div class="container">
                        <textarea id="editor" placeholder="Write markdown here..."># Bellows Live PWA Module\n\nThis app runs **100% locally** inside the Bellows Android Container!\n\n- Realtime preview\n- Connected to Bellows LLM Gateway\n- Self-contained & dynamic</textarea>
                        <div class="controls">
                            <button onclick="updatePreview()">Render Preview</button>
                            <button onclick="aiSummarize()">AI Polish & Summarize</button>
                        </div>
                        <div id="preview" class="preview"></div>
                    </div>
                    <script>
                        function updatePreview() {
                            const raw = document.getElementById('editor').value;
                            document.getElementById('preview').innerHTML = marked.parse(raw);
                        }
                        updatePreview();
                        document.getElementById('editor').addEventListener('input', updatePreview);

                        async function aiSummarize() {
                            const text = document.getElementById('editor').value;
                            if (!window.bellows) { alert('Bellows Bridge connecting...'); return; }
                            window.bellows.toast('Connecting to Bellows LLM...');
                            window.bellows.chat("Improve and polish this markdown text:\n\n" + text, "gemini-2.5-flash", "handleAiResponse");
                        }
                        window.handleAiResponse = function(resp) {
                            if (resp) {
                                document.getElementById('editor').value = resp;
                                updatePreview();
                            }
                        };
                    </script>
                </body>
                </html>
            """.trimIndent()
        )

        val kanban = com.example.db.PwaModuleEntity(
            id = "default-kanban",
            title = "AI Agile Kanban Board",
            description = "Interactive Taskboard with Todo, In Progress, and Done columns + Local Memory sync",
            category = "Management",
            updatedAt = System.currentTimeMillis(),
            htmlContent = """
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <title>AI Kanban Board</title>
                    <style>
                        body { font-family: system-ui, sans-serif; background: #0c1017; color: #e6edf3; margin: 0; padding: 16px; }
                        h2 { color: #f8994a; margin-top: 0; }
                        .board { display: flex; gap: 12px; overflow-x: auto; }
                        .col { flex: 1; min-width: 220px; background: #161b22; border-radius: 8px; padding: 12px; border: 1px solid #30363d; }
                        .col h3 { font-size: 14px; color: #8b949e; text-transform: uppercase; margin: 0 0 12px 0; border-bottom: 1px solid #30363d; padding-bottom: 6px; }
                        .card { background: #21262d; border-radius: 6px; padding: 10px; margin-bottom: 8px; border: 1px solid #30363d; cursor: pointer; }
                        .card:hover { border-color: #f8994a; }
                        .btn { background: #238636; color: white; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-weight: bold; margin-bottom: 12px; }
                        .btn-sync { background: #0c3c5a; border: 1px solid #1f6beb; }
                    </style>
                </head>
                <body>
                    <h2>📋 AI Agile Kanban Board</h2>
                    <button class="btn" onclick="addTask()">+ Add Task</button>
                    <button class="btn btn-sync" onclick="saveToMemWiki()">💾 Sync to MemWiki</button>
                    <div class="board">
                        <div class="col" id="col-todo">
                            <h3>To Do</h3>
                            <div class="card" onclick="moveCard(this, 'col-progress')">🚀 Setup Bellows Server Router</div>
                            <div class="card" onclick="moveCard(this, 'col-progress')">⚡ Build PWA Micro-Apps</div>
                        </div>
                        <div class="col" id="col-progress">
                            <h3>In Progress</h3>
                            <div class="card" onclick="moveCard(this, 'col-done')">🔧 Room DB Integration</div>
                        </div>
                        <div class="col" id="col-done">
                            <h3>Done</h3>
                            <div class="card">✅ Ktor HTTP Router Gateway</div>
                        </div>
                    </div>
                    <script>
                        function addTask() {
                            const text = prompt('Task Title:');
                            if (!text) return;
                            const card = document.createElement('div');
                            card.className = 'card';
                            card.innerText = '📌 ' + text;
                            card.onclick = function() { moveCard(card, 'col-progress'); };
                            document.getElementById('col-todo').appendChild(card);
                        }
                        function moveCard(card, targetId) {
                            document.getElementById(targetId).appendChild(card);
                        }
                        function saveToMemWiki() {
                            if (window.bellows) {
                                window.bellows.saveMemory('Kanban Board Snapshot', JSON.stringify({ timestamp: Date.now(), status: 'Saved' }));
                            }
                        }
                    </script>
                </body>
                </html>
            """.trimIndent()
        )

        db.pwaModuleDao().insertPwaModule(mdEditor)
        db.pwaModuleDao().insertPwaModule(kanban)
    }

    fun savePwaModule(title: String, description: String, htmlContent: String, category: String, id: String? = null) {
        viewModelScope.launch {
            val moduleId = id ?: "pwa-${UUID.randomUUID()}"
            val module = com.example.db.PwaModuleEntity(
                id = moduleId,
                title = title,
                description = description,
                htmlContent = htmlContent,
                category = category,
                updatedAt = System.currentTimeMillis()
            )
            db.pwaModuleDao().insertPwaModule(module)
        }
    }

    fun deletePwaModule(id: String) {
        viewModelScope.launch {
            db.pwaModuleDao().deletePwaModule(id)
        }
    }

    fun chatDirect(prompt: String, model: String = "gemini-2.5-flash", onResult: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val req = com.example.models.OpenAiChatRequest(
                    model = if (model.isBlank()) "gemini-2.5-flash" else model,
                    messages = listOf(com.example.models.ChatMessage(role = "user", content = prompt))
                )
                val response = router.routeRequest(req)
                val answer = response.choices.firstOrNull()?.message?.content ?: "No response"
                onResult(answer)
            } catch (e: Exception) {
                onResult("Error: ${e.localizedMessage}")
            }
        }
    }

    fun generatePwaModule(prompt: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            try {
                val sysMsg = com.example.models.ChatMessage(
                    role = "system",
                    content = "You are an expert PWA & Web App Architect. The user wants an interactive single-file HTML/CSS/JS application. Output ONLY valid, single-file raw HTML inside a markdown codeblock ```html ... ```. Include embedded CSS <style> and JavaScript <script>. You can optionally call window.bellows.chat(prompt, model, callback) or window.bellows.saveMemory(summary, payload) if appropriate."
                )
                val userMsg = com.example.models.ChatMessage(role = "user", content = prompt)
                val req = com.example.models.OpenAiChatRequest(
                    model = "gemini-2.5-flash",
                    messages = listOf(sysMsg, userMsg)
                )
                val response = router.routeRequest(req)
                val rawAnswer = response.choices.firstOrNull()?.message?.content ?: ""
                val htmlCode = if (rawAnswer.contains("```html")) {
                    rawAnswer.substringAfter("```html").substringBefore("```").trim()
                } else if (rawAnswer.contains("```")) {
                    rawAnswer.substringAfter("```").substringBefore("```").trim()
                } else {
                    rawAnswer.trim()
                }

                if (htmlCode.startsWith("<") && htmlCode.contains("</html>")) {
                    val titleSnippet = prompt.take(30).capitalize()
                    savePwaModule(
                        title = "App: $titleSnippet",
                        description = prompt,
                        htmlContent = htmlCode,
                        category = "Generated"
                    )
                    onResult(true, "App successfully created and saved!")
                } else {
                    onResult(false, "Failed to parse HTML code block from LLM response.")
                }
            } catch (e: Exception) {
                onResult(false, "Error generating PWA module: ${e.localizedMessage}")
            }
        }
    }

    private fun loadConfig(): ConfigState {
        val customProvidersStr = prefs.getString("customProviders", "[]") ?: "[]"
        val customProviders = try {
            kotlinx.serialization.json.Json.decodeFromString<List<ProviderInfo>>(customProvidersStr)
        } catch (e: Exception) { emptyList() }
        
        val keys = mutableMapOf<String, String>()
        val allProviders = defaultProviders + customProviders
        allProviders.forEach { p ->
            prefs.getString("provider_${p.id}", null)?.let {
                keys[p.id] = it
            }
        }
        return ConfigState(
            themeMode = com.example.models.ThemeMode.valueOf(prefs.getString("themeMode", com.example.models.ThemeMode.LIGHT.name) ?: com.example.models.ThemeMode.LIGHT.name),
            customProviders = customProviders,
            apiKeys = keys,
            geminiApiKey = prefs.getString("geminiApiKey", "") ?: "",
            openaiApiKey = prefs.getString("openaiApiKey", "") ?: "",
            anthropicApiKey = prefs.getString("anthropicApiKey", "") ?: "",
            localServerPort = prefs.getInt("localServerPort", 8080),
            localApiKey = prefs.getString("localApiKey", "sk-local-${UUID.randomUUID()}") ?: "",
            isRunning = false
        )
    }

    fun updateConfig(update: (ConfigState) -> ConfigState) {
        val newState = update(_configState.value)
        _configState.value = newState
        prefs.edit().apply {
            putString("themeMode", newState.themeMode.name)
            val customStr = kotlinx.serialization.json.Json.encodeToString(newState.customProviders)
            putString("customProviders", customStr)
            putString("geminiApiKey", newState.geminiApiKey)
            putString("openaiApiKey", newState.openaiApiKey)
            putString("anthropicApiKey", newState.anthropicApiKey)
            putInt("localServerPort", newState.localServerPort)
            putString("localApiKey", newState.localApiKey)
            // Save provider keys
            newState.apiKeys.forEach { (k, v) -> putString("provider_$k", v) }
            apply()
        }
    }

    fun addCustomProvider(provider: ProviderInfo) {
        updateConfig { it.copy(customProviders = it.customProviders + provider) }
    }

    fun updateProviderKey(providerId: String, key: String) {
        val currentKeys = _configState.value.apiKeys.toMutableMap()
        currentKeys[providerId] = key
        updateConfig { it.copy(apiKeys = currentKeys) }
    }

    fun toggleServer() {
        if (localServer.isRunning.value) {
            localServer.stopServer()
        } else {
            val currentConfig = _configState.value
            localServer.startServer(
                port = currentConfig.localServerPort,
                localApiKey = currentConfig.localApiKey,
                onRoute = { request ->
                    val lastUserMessage = request.messages.lastOrNull { it.role == "user" }?.content ?: ""
                    if (lastUserMessage.contains("remember that", ignoreCase = true)) {
                        saveToMemWiki(lastUserMessage)
                    }

                    val allMemories = db.memoryDao().getAllMemories()
                    val memoryContext = if (allMemories.isNotEmpty()) {
                        allMemories.joinToString(separator = "\n") { "- ${it.summary}" }
                    } else null

                    router.routeRequest(request, memoryContext)
                }
            )
        }
    }
    
    private suspend fun saveToMemWiki(content: String) {
        val snippet = content.substringAfter("remember that", content).trim()
        val mem = MemoryEntity(
            id = UUID.randomUUID().toString(),
            summary = snippet.take(100),
            jsonPayload = "{\"original\": \"$content\"}",
            timestamp = System.currentTimeMillis()
        )
        db.memoryDao().insertMemory(mem)
    }

    fun clearMemWiki() {
        viewModelScope.launch {
            db.memoryDao().clearAll()
        }
    }

    private val _toastEvent = MutableStateFlow<String?>(null)
    val toastEvent = _toastEvent.asStateFlow()

    fun clearToastEvent() {
        _toastEvent.value = null
    }

    fun stopWizard() {
        _pendingProviderId.value = null
        _toastEvent.value = "⏹️ Key-Wizard gestoppt. Alle bisherigen Key-Eingaben bleiben gespeichert!"
    }

    fun startAutoWizard(startProviderId: String? = null) {
        val keys = _configState.value.apiKeys
        val allProviders = defaultProviders + _configState.value.customProviders
        val target = if (startProviderId != null) {
            allProviders.find { it.id == startProviderId }
        } else {
            allProviders.firstOrNull { keys[it.id].isNullOrBlank() }
        }

        if (target != null) {
            _pendingProviderId.value = target.id
            _openBrowserEvent.value = target.registrationUrl
            _toastEvent.value = "🎯 Key-Wizard gestartet: Registrierungsseite für ${target.name} geöffnet!"
        } else {
            _toastEvent.value = "🎉 Alle Provider besitzen bereits einen eingerichteten Key!"
        }
    }

    fun openProviderRegistration(providerId: String) {
        val allProviders = defaultProviders + _configState.value.customProviders
        val provider = allProviders.find { it.id == providerId } ?: return
        val currentKey = _configState.value.apiKeys[providerId] ?: ""
        
        if (currentKey.isBlank()) {
            startAutoWizard(providerId)
        } else {
            _pendingProviderId.value = providerId
            _openBrowserEvent.value = provider.registrationUrl
        }
    }

    fun clearOpenBrowserEvent() {
        _openBrowserEvent.value = null
    }

    fun checkClipboardForApiKey(context: Context) {
        val pendingId = _pendingProviderId.value ?: return
        val allProviders = defaultProviders + _configState.value.customProviders
        val currentProvider = allProviders.find { it.id == pendingId } ?: return

        val clipboardManager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        if (clipboardManager.hasPrimaryClip()) {
            val rawClip = clipboardManager.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
            val cleanKey = rawClip.replace("Bearer ", "").trim().trim('"').trim('\'')
            val existingKey = _configState.value.apiKeys[pendingId] ?: ""

            if (cleanKey.isNotBlank() && cleanKey.length >= 8 && !cleanKey.contains(" ") && cleanKey != existingKey) {
                // Save the key immediately (Zero data loss)
                updateProviderKey(pendingId, cleanKey)
                _toastEvent.value = "✅ Key für ${currentProvider.name} automatisch erkannt & gespeichert!"

                // Move to next provider missing a key
                moveToNextMissingKeyProvider()
            }
        }
    }

    private fun moveToNextMissingKeyProvider() {
        val keys = _configState.value.apiKeys
        val allProviders = defaultProviders + _configState.value.customProviders
        val nextProvider = allProviders.firstOrNull { keys[it.id].isNullOrBlank() }
        if (nextProvider != null) {
            _pendingProviderId.value = nextProvider.id
            _openBrowserEvent.value = nextProvider.registrationUrl
        } else {
            _pendingProviderId.value = null
            _toastEvent.value = "🎉 Hervorragend! Alle Provider-Schlüssel wurden erfolgreich konfiguriert."
        }
    }

    override fun onCleared() {
        super.onCleared()
        localServer.stopServer()
    }
}
