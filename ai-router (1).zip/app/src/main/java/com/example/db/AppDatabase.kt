package com.example.db

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "memory")
data class MemoryEntity(
    @PrimaryKey
    val id: String,
    val summary: String,
    val jsonPayload: String, // Full JSON context
    val timestamp: Long
)

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memory ORDER BY timestamp DESC")
    fun getAllMemoriesFlow(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memory ORDER BY timestamp DESC")
    suspend fun getAllMemories(): List<MemoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: MemoryEntity)

    @Query("DELETE FROM memory WHERE id = :id")
    suspend fun deleteMemory(id: String)
    
    @Query("DELETE FROM memory")
    suspend fun clearAll()
}

@Entity(tableName = "pwa_modules")
data class PwaModuleEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val description: String,
    val htmlContent: String,
    val category: String,
    val updatedAt: Long
)

@Dao
interface PwaModuleDao {
    @Query("SELECT * FROM pwa_modules ORDER BY updatedAt DESC")
    fun getAllPwaModulesFlow(): Flow<List<PwaModuleEntity>>

    @Query("SELECT * FROM pwa_modules WHERE id = :id")
    suspend fun getPwaModuleById(id: String): PwaModuleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPwaModule(module: PwaModuleEntity)

    @Query("DELETE FROM pwa_modules WHERE id = :id")
    suspend fun deletePwaModule(id: String)
}

@Database(entities = [MemoryEntity::class, PwaModuleEntity::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun memoryDao(): MemoryDao
    abstract fun pwaModuleDao(): PwaModuleDao
}

