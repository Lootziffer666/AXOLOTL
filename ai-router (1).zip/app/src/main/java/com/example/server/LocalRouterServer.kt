package com.example.server

import android.util.Log
import com.example.db.AppDatabase
import com.example.models.ChatMessage
import com.example.models.OpenAiChatRequest
import com.example.models.OpenAiChatResponse
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.cio.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.server.plugins.cors.routing.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.json.Json
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LocalRouterServer(private val db: AppDatabase) {

    private var server: ApplicationEngine? = null
    private val _isRunning = MutableStateFlow(false)
    val isRunning = _isRunning.asStateFlow()

    fun startServer(port: Int, localApiKey: String, onRoute: suspend (OpenAiChatRequest) -> OpenAiChatResponse) {
        if (_isRunning.value) return

        server = embeddedServer(CIO, port = port) {
            install(ContentNegotiation) {
                json(Json {
                    ignoreUnknownKeys = true
                    prettyPrint = true
                    isLenient = true
                })
            }
            install(CORS) {
                anyHost()
                allowHeader("Authorization")
                allowHeader("Content-Type")
            }

            routing {
                post("/v1/chat/completions") {
                    try {
                        val authHeader = call.request.header("Authorization")
                        if (authHeader != "Bearer $localApiKey") {
                            call.respond(io.ktor.http.HttpStatusCode.Unauthorized, "Invalid Local API Key")
                            return@post
                        }

                        val request = call.receive<OpenAiChatRequest>()
                        
                        // Execute mapping/routing logic defined externally
                        val response = onRoute(request)
                        
                        call.respond(io.ktor.http.HttpStatusCode.OK, response)
                    } catch (e: Exception) {
                        Log.e("LocalRouterServer", "Error handling request", e)
                        call.respond(io.ktor.http.HttpStatusCode.InternalServerError, e.message ?: "Unknown error")
                    }
                }
                
                get("/health") {
                    call.respondText("OK")
                }
            }
        }.start(wait = false)
        
        _isRunning.value = true
        Log.d("LocalRouterServer", "Server started on port $port")
    }

    fun stopServer() {
        server?.stop(1000, 2000)
        server = null
        _isRunning.value = false
        Log.d("LocalRouterServer", "Server stopped")
    }
}
