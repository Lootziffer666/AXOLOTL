package com.example.server

import android.util.Log
import com.example.models.*
import io.ktor.client.*
import io.ktor.client.engine.okhttp.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.json.Json
import java.util.concurrent.ConcurrentHashMap

class ExternalApiRouter(
    private val getAppConfig: () -> ConfigState,
    private val getProviders: () -> List<ProviderInfo>
) {
    private val cache = ConcurrentHashMap<String, OpenAiChatResponse>()

    private val client = HttpClient(OkHttp) {
        install(ContentNegotiation) {
            json(Json {
                ignoreUnknownKeys = true
                isLenient = true
            })
        }
    }

    suspend fun routeRequest(request: OpenAiChatRequest, injectedMemory: String? = null): OpenAiChatResponse {
        val config = getAppConfig()
        val providers = getProviders()
        
        val finalMessages = request.messages.toMutableList()
        if (!injectedMemory.isNullOrBlank()) {
            finalMessages.add(0, ChatMessage(role = "system", content = "MemWiki Context:\n$injectedMemory\n\nUse this context if relevant."))
        }
        
        val modifiedRequest = request.copy(messages = finalMessages)

        // Simple cache lookup for non-streaming queries
        val cacheKey = "${modifiedRequest.model}:${modifiedRequest.messages.lastOrNull()?.content}"
        cache[cacheKey]?.let {
            Log.d("ExternalApiRouter", "Serving cached response for model ${modifiedRequest.model}")
            return it
        }

        // Primary provider selection
        val primaryProvider = providers.find { p -> p.modelsList.any { it.equals(modifiedRequest.model, ignoreCase = true) || modifiedRequest.model.contains(it, ignoreCase = true) } }
            ?: providers.find { modifiedRequest.model.contains(it.id, ignoreCase = true) }

        val candidates = mutableListOf<Pair<String, String>>() // Pair(apiKey, url)

        if (primaryProvider != null) {
            val key = config.apiKeys[primaryProvider.id] ?: ""
            if (key.isNotBlank()) candidates.add(Pair(key, primaryProvider.apiUrl))
        }

        // Add Fallback Providers (LiteLLM style resilience)
        config.apiKeys["gemini"]?.takeIf { it.isNotBlank() }?.let {
            candidates.add(Pair(it, "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"))
        }
        config.apiKeys["github"]?.takeIf { it.isNotBlank() }?.let {
            candidates.add(Pair(it, "https://models.inference.ai.azure.com/chat/completions"))
        }

        var lastException: Exception? = null
        for ((apiKey, url) in candidates.distinctBy { it.second }) {
            try {
                Log.d("ExternalApiRouter", "Attempting route to $url")
                val response = routeToOpenAICompatible(modifiedRequest, apiKey, url)
                cache[cacheKey] = response
                return response
            } catch (e: Exception) {
                Log.w("ExternalApiRouter", "Provider at $url failed: ${e.message}. Trying fallback...")
                lastException = e
            }
        }

        throw lastException ?: IllegalArgumentException("All provider routes failed for model: ${modifiedRequest.model}")
    }

    private suspend fun routeToOpenAICompatible(request: OpenAiChatRequest, apiKey: String, url: String): OpenAiChatResponse {
        if (apiKey.isBlank()) throw IllegalArgumentException("API key for $url is missing")

        val response: HttpResponse = client.post(url) {
            header("Authorization", "Bearer $apiKey")
            contentType(ContentType.Application.Json)
            setBody(request)
        }
        
        if (!response.status.isSuccess()) {
             throw RuntimeException("API Error (${response.status}): ${response.bodyAsText()}")
        }
        
        val jsonString = response.bodyAsText()
        val json = Json { ignoreUnknownKeys = true }
        return json.decodeFromString(jsonString)
    }
}

