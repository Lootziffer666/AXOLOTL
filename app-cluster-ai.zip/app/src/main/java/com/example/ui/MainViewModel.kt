package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.AppEntity
import com.example.data.AppRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class MainUiState(
    val selectedCluster: String? = null,
    val searchQuery: String = "",
    val isInitializingDb: Boolean = false,
    val isAiAnalyzing: Boolean = false,
    val aiProgressCurrent: Int = 0,
    val aiProgressTotal: Int = 0,
    val aiStatusMessage: String = "",
    val selectedAppForDetail: AppEntity? = null,
    val currentTab: Int = 0, // 0: Cluster View, 1: Design Collector, 2: Batch Uninstall / Shizuku
    val showTermuxDialog: Boolean = false,
    val infoNotice: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AppRepository

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    init {
        val dao = AppDatabase.getDatabase(application).appDao()
        repository = AppRepository(application, dao)

        // Ensure database creation and scan on app start
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isInitializingDb = true)
            repository.initializeAndScanDatabase()
            _uiState.value = _uiState.value.copy(isInitializingDb = false)
        }
    }

    val allApps = repository.allApps.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allClusters = repository.allClusters.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val designApps = repository.designApps.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val markedForUninstallApps = repository.markedForUninstallApps.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val filteredApps = combine(allApps, uiState) { apps, state ->
        apps.filter { app ->
            val matchesCluster = state.selectedCluster == null || app.categoryCluster == state.selectedCluster
            val matchesSearch = state.searchQuery.isBlank() ||
                    app.appName.contains(state.searchQuery, ignoreCase = true) ||
                    app.packageName.contains(state.searchQuery, ignoreCase = true) ||
                    app.aiSummary.contains(state.searchQuery, ignoreCase = true)
            matchesCluster && matchesSearch
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun setSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun setSelectedCluster(cluster: String?) {
        _uiState.value = _uiState.value.copy(selectedCluster = cluster)
    }

    fun setCurrentTab(tab: Int) {
        _uiState.value = _uiState.value.copy(currentTab = tab)
    }

    fun selectAppForDetail(app: AppEntity?) {
        _uiState.value = _uiState.value.copy(selectedAppForDetail = app)
    }

    fun toggleDesignCollectorStatus(app: AppEntity) {
        viewModelScope.launch {
            val updated = app.copy(isDesignCollector = !app.isDesignCollector)
            repository.updateApp(updated)
            if (_uiState.value.selectedAppForDetail?.packageName == app.packageName) {
                _uiState.value = _uiState.value.copy(selectedAppForDetail = updated)
            }
        }
    }

    fun toggleMarkForUninstall(app: AppEntity) {
        viewModelScope.launch {
            val updated = app.copy(markedForUninstall = !app.markedForUninstall)
            repository.updateApp(updated)
            if (_uiState.value.selectedAppForDetail?.packageName == app.packageName) {
                _uiState.value = _uiState.value.copy(selectedAppForDetail = updated)
            }
        }
    }

    fun markAppAsInspectedAndQueueUninstall(app: AppEntity, queueUninstall: Boolean) {
        viewModelScope.launch {
            val updated = app.copy(
                isInspected = true,
                markedForUninstall = queueUninstall
            )
            repository.updateApp(updated)
            if (_uiState.value.selectedAppForDetail?.packageName == app.packageName) {
                _uiState.value = _uiState.value.copy(selectedAppForDetail = updated)
            }
        }
    }

    fun runRescanInstalledApps() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isInitializingDb = true, infoNotice = "Scanne installierte Anwendungen...")
            repository.initializeAndScanDatabase(forceRescan = true)
            _uiState.value = _uiState.value.copy(isInitializingDb = false, infoNotice = "Datenbank erfolgreich aktualisiert!")
        }
    }

    fun runAiClustering() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isAiAnalyzing = true,
                aiStatusMessage = "Starte Gemini LLM Analyse & Clustering..."
            )

            val resultMsg = repository.runAiClusteringForUnprocessedApps { current, total ->
                _uiState.value = _uiState.value.copy(
                    aiProgressCurrent = current,
                    aiProgressTotal = total,
                    aiStatusMessage = "Analysiere $current von $total Apps..."
                )
            }

            _uiState.value = _uiState.value.copy(
                isAiAnalyzing = false,
                aiStatusMessage = "",
                infoNotice = resultMsg
            )
        }
    }

    fun dismissNotice() {
        _uiState.value = _uiState.value.copy(infoNotice = null)
    }
}
