package com.example.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.example.data.api.AppAnalysisResult
import com.example.data.api.BatchAnalysisResponse
import com.example.data.api.Content
import com.example.data.api.GeminiApiClient
import com.example.data.api.GenerateContentRequest
import com.example.data.api.GenerationConfig
import com.example.data.api.Part
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class AppRepository(
    private val context: Context,
    private val appDao: AppDao
) {
    val allApps: Flow<List<AppEntity>> = appDao.getAllApps()
    val allClusters: Flow<List<String>> = appDao.getAllClusters()
    val designApps: Flow<List<AppEntity>> = appDao.getDesignApps()
    val markedForUninstallApps: Flow<List<AppEntity>> = appDao.getMarkedForUninstallApps()

    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()

    suspend fun getAppsByCluster(cluster: String): Flow<List<AppEntity>> {
        return appDao.getAppsByCluster(cluster)
    }

    /**
     * First Launch Database Initialization & Indexing
     * Guarantees database creation and scans all installed packages.
     */
    suspend fun initializeAndScanDatabase(forceRescan: Boolean = false) = withContext(Dispatchers.IO) {
        val existingCount = appDao.getAppCount()
        if (existingCount > 0 && !forceRescan) {
            return@withContext
        }

        val pm = context.packageManager
        val installedAppsList = mutableListOf<AppEntity>()

        // 1. Scan actual installed launcher applications
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val launcherApps = pm.queryIntentActivities(mainIntent, 0)

        for (resolveInfo in launcherApps) {
            val pkg = resolveInfo.activityInfo.packageName
            val label = resolveInfo.loadLabel(pm).toString()
            val isSys = (resolveInfo.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0

            // Skip self
            if (pkg == context.packageName) continue

            installedAppsList.add(
                AppEntity(
                    packageName = pkg,
                    appName = label,
                    categoryCluster = detectInitialCategory(label, pkg),
                    aiSummary = generateFallbackSummary(label, pkg),
                    isSystemApp = isSys
                )
            )
        }

        // 2. Ensure initial seed data if fewer than 15 apps found (e.g. clean emulator setup or strict permission sandbox)
        if (installedAppsList.size < 15) {
            installedAppsList.addAll(getSampleInstalledAppsSeed())
        }

        appDao.insertApps(installedAppsList.distinctBy { it.packageName })
    }

    private fun detectInitialCategory(name: String, pkg: String): String {
        val lower = (name + pkg).lowercase()
        return when {
            lower.contains("social") || lower.contains("chat") || lower.contains("whatsapp") || lower.contains("telegram") || lower.contains("instagram") -> "Soziale Medien & Kommunikation"
            lower.contains("photo") || lower.contains("camera") || lower.contains("design") || lower.contains("figma") || lower.contains("canvas") || lower.contains("gallery") -> "Design & Fotografie"
            lower.contains("tool") || lower.contains("calculator") || lower.contains("clock") || lower.contains("setting") || lower.contains("file") -> "System & Werkzeuge"
            lower.contains("music") || lower.contains("video") || lower.contains("spotify") || lower.contains("youtube") || lower.contains("player") -> "Medien & Unterhaltung"
            lower.contains("bank") || lower.contains("pay") || lower.contains("wallet") || lower.contains("crypto") -> "Finanzen & Shopping"
            lower.contains("game") || lower.contains("play") -> "Spiele"
            else -> "Produktivität & Utility"
        }
    }

    private fun generateFallbackSummary(name: String, pkg: String): String {
        return "$name ($pkg) ist auf Ihrem Gerät installiert. Klicken Sie auf 'KI Analyse', um detaillierte Einsichten zu Funktion und Zweck zu erhalten."
    }

    /**
     * Batch Analyze Apps using Gemini AI
     */
    suspend fun runAiClusteringForUnprocessedApps(onProgress: (Int, Int) -> Unit = { _, _ -> }): String = withContext(Dispatchers.IO) {
        val apiKey = GeminiApiClient.getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "Hinweis: Kein gültiger GEMINI_API_KEY im Secrets-Panel / .env gesetzt. Bitte Schlüssel in AI Studio Secrets eintragen."
        }

        val unprocessed = appDao.getUnprocessedApps()
        if (unprocessed.isEmpty()) {
            return@withContext "Alle installierten Apps wurden bereits von der KI analysiert und geordnet!"
        }

        val batchSize = 10
        val batches = unprocessed.chunked(batchSize)
        var processedCount = 0

        for ((index, batch) in batches.withIndex()) {
            onProgress(processedCount, unprocessed.size)

            val appPromptList = batch.joinToString("\n") { app ->
                "- Name: ${app.appName}, Package: ${app.packageName}, IstSystem: ${app.isSystemApp}"
            }

            val prompt = """
                Du bist ein Experten-Assistent für Android-App-Clustering und App-Audits.
                Analysiere folgende Liste von installierten Android Apps und gruppiere sie in präzise Cluster (z.B. "Design & Inspiration", "Produktivität & Workflows", "Medien & Streaming", "System & Utilities", "Spiele & Entertainment", "Finanzen & Krypto").
                
                Gib für jede App Folgendes an:
                1. cluster: Name des passenden Clusters.
                2. summary: Kurze Erklärung (1-2 Sätze auf Deutsch), was die App macht.
                3. rationale: Warum der Nutzer diese App wahrscheinlich installiert hat (z.B. "Häufig für UI-Inspiration, Prototyping oder Tägliche Arbeit genutzt").

                Antworte AUSSCHLIESSLICH als gültiges JSON in folgendem Format:
                {
                  "apps": [
                    {
                      "packageName": "com.example.app",
                      "cluster": "Design & Inspiration",
                      "summary": "Grafikdesign und Vektorillustrator...",
                      "rationale": "Möglicherweise zur Inspiration für Benutzeroberflächen installiert."
                    }
                  ]
                }

                Hier die App-Liste:
                $appPromptList
            """.trimIndent()

            try {
                val request = GenerateContentRequest(
                    contents = listOf(Content(parts = listOf(Part(text = prompt)))),
                    generationConfig = GenerationConfig(
                        temperature = 0.2f,
                        responseMimeType = "application/json"
                    )
                )

                val response = GeminiApiClient.service.generateContent(apiKey, request)
                val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: ""

                if (jsonText.isNotBlank()) {
                    val adapter = moshi.adapter(BatchAnalysisResponse::class.java)
                    val parsed = adapter.fromJson(jsonText)
                    parsed?.apps?.forEach { res ->
                        val existing = appDao.getAppByPackage(res.packageName)
                        if (existing != null) {
                            appDao.updateApp(
                                existing.copy(
                                    categoryCluster = res.cluster,
                                    aiSummary = res.summary,
                                    rationaleWhyInstalled = res.rationale
                                )
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                // Ignore single batch errors and continue
            }

            processedCount += batch.size
        }

        onProgress(unprocessed.size, unprocessed.size)
        return@withContext "${unprocessed.size} Apps erfolgreich von Gemini AI analysiert und kategorisiert!"
    }

    suspend fun updateApp(app: AppEntity) = withContext(Dispatchers.IO) {
        appDao.updateApp(app)
    }

    suspend fun deleteApp(packageName: String) = withContext(Dispatchers.IO) {
        appDao.deleteAppByPackage(packageName)
    }

    private fun getSampleInstalledAppsSeed(): List<AppEntity> {
        return listOf(
            AppEntity("com.figma.mirror", "Figma", "Design & Inspiration", "UI/UX Design Prototyping Tool für Vektor-Interfaces.", "Für UI-Inspiration & Mobile Review installiert.", false, isDesignCollector = true),
            AppEntity("org.readera", "ReadEra", "Produktivität & Dokumente", "E-Book & PDF Reader mit werbefreier Ansicht.", "Zum Lesen von Fachbüchern und Skripten.", false),
            AppEntity("com.dribbble.app", "Dribbble", "Design & Inspiration", "Showcase Plattform für Designer & Illustratoren.", "Design-Inspiration & UI Trends.", false, isDesignCollector = true),
            AppEntity("me.everything.badger", "Behance", "Design & Inspiration", "Adobe Portfolio Plattform für kreative Arbeiten.", "Inspiration für mobile App-Designs.", false, isDesignCollector = true),
            AppEntity("com.termux", "Termux", "System & Entwickler", "Android Terminal Emulator und Linux Umgebungs-App.", "Für Command Line Tools & ADB Skripte.", false),
            AppEntity("moe.shizuku.privileged.api", "Shizuku", "System & Entwickler", "System-Service für adb-Rechte ohne Root.", "Für Batch-Installationen und erweiterte Systemverwaltung.", false),
            AppEntity("com.spotify.music", "Spotify", "Medien & Streaming", "Musik- und Podcast-Streamingdienst.", "Tägliche Musikwiedergabe.", false),
            AppEntity("com.duolingo", "Duolingo", "Sprachen & Bildung", "Interaktiver Sprachlern-Trainer mit Gamification.", "Sprachtraining im Alltag.", false),
            AppEntity("com.notion.id", "Notion", "Produktivität & Notizen", "All-in-One Workspace für Notizen und Wissensdatenbank.", "Projektplanung und Notizverwaltung.", false),
            AppEntity("com.todoist", "Todoist", "Produktivität & Notizen", "Aufgabenplaner und To-Do-Listen Manager.", "Aufgabenverwaltung.", false),
            AppEntity("com.pinterest", "Pinterest", "Design & Inspiration", "Visuelle Suchmaschine für Moodboards und Deko-Ideen.", "Visual Design Boarding.", false, isDesignCollector = true),
            AppEntity("com.github.android", "GitHub", "System & Entwickler", "Mobile Client für Repositories und Code Reviews.", "Source Code Management.", false),
            AppEntity("com.vlcforandroid.vlcdirectpro", "VLC", "Medien & Streaming", "Open-Source Media Player für alle Formate.", "Medienwiedergabe.", false),
            AppEntity("com.reddit.frontpage", "Reddit", "Soziale Medien", "Diskussionsforen und Community-Plattform.", "Technologie & Design News.", false),
            AppEntity("com.pocket.app", "Pocket", "Produktivität & Artikel", "Artikel-Speicher-App für spätere Offline-Lektüre.", "Bookmark Management.", false)
        )
    }
}
