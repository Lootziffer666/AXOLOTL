package com.example.data

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PackageChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        val data = intent.data ?: return
        val packageName = data.schemeSpecificPart ?: return

        val db = AppDatabase.getDatabase(context)
        val dao = db.appDao()

        CoroutineScope(Dispatchers.IO).launch {
            if (action == Intent.ACTION_PACKAGE_ADDED) {
                val pm = context.packageManager
                try {
                    val appInfo = pm.getApplicationInfo(packageName, 0)
                    val label = pm.getApplicationLabel(appInfo).toString()
                    val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0

                    val newApp = AppEntity(
                        packageName = packageName,
                        appName = label,
                        categoryCluster = "Neu Installiert",
                        aiSummary = "Kürzlich installiert. Ausstehende KI-Analyse...",
                        isSystemApp = isSystem
                    )
                    dao.insertApp(newApp)
                } catch (e: PackageManager.NameNotFoundException) {
                    // Package not found
                }
            } else if (action == Intent.ACTION_PACKAGE_REMOVED) {
                dao.deleteAppByPackage(packageName)
            }
        }
    }
}
