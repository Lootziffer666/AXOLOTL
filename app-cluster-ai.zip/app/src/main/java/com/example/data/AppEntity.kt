package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "installed_apps")
data class AppEntity(
    @PrimaryKey val packageName: String,
    val appName: String,
    val categoryCluster: String = "Unkategorisiert",
    val aiSummary: String = "Keine KI-Analyse vorhanden.",
    val rationaleWhyInstalled: String = "",
    val isSystemApp: Boolean = false,
    val installedTimestamp: Long = System.currentTimeMillis(),
    val isDesignCollector: Boolean = false,
    val isInspected: Boolean = false,
    val screenshotPathsJson: String = "[]",
    val markedForUninstall: Boolean = false
)
