package com.example.data.api

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    val temperature: Float? = 0.4f,
    val responseMimeType: String? = null
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    val candidates: List<Candidate>? = null
)

@JsonClass(generateAdapter = true)
data class Candidate(
    val content: Content? = null
)

// Data structure for parsed JSON output from Gemini for app clustering
@JsonClass(generateAdapter = true)
data class AppAnalysisResult(
    @Json(name = "packageName") val packageName: String,
    @Json(name = "cluster") val cluster: String,
    @Json(name = "summary") val summary: String,
    @Json(name = "rationale") val rationale: String
)

@JsonClass(generateAdapter = true)
data class BatchAnalysisResponse(
    @Json(name = "apps") val apps: List<AppAnalysisResult>
)
