package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM installed_apps ORDER BY appName ASC")
    fun getAllApps(): Flow<List<AppEntity>>

    @Query("SELECT * FROM installed_apps WHERE categoryCluster = :cluster ORDER BY appName ASC")
    fun getAppsByCluster(cluster: String): Flow<List<AppEntity>>

    @Query("SELECT * FROM installed_apps WHERE isDesignCollector = 1 ORDER BY appName ASC")
    fun getDesignApps(): Flow<List<AppEntity>>

    @Query("SELECT * FROM installed_apps WHERE markedForUninstall = 1 ORDER BY appName ASC")
    fun getMarkedForUninstallApps(): Flow<List<AppEntity>>

    @Query("SELECT DISTINCT categoryCluster FROM installed_apps WHERE categoryCluster != '' ORDER BY categoryCluster ASC")
    fun getAllClusters(): Flow<List<String>>

    @Query("SELECT * FROM installed_apps WHERE categoryCluster = 'Unkategorisiert' OR aiSummary LIKE 'Keine KI%'")
    suspend fun getUnprocessedApps(): List<AppEntity>

    @Query("SELECT * FROM installed_apps WHERE packageName = :packageName LIMIT 1")
    suspend fun getAppByPackage(packageName: String): AppEntity?

    @Query("SELECT COUNT(*) FROM installed_apps")
    suspend fun getAppCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApps(apps: List<AppEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApp(app: AppEntity)

    @Update
    suspend fun updateApp(app: AppEntity)

    @Query("DELETE FROM installed_apps WHERE packageName = :packageName")
    suspend fun deleteAppByPackage(packageName: String)

    @Query("DELETE FROM installed_apps")
    suspend fun deleteAll()
}
