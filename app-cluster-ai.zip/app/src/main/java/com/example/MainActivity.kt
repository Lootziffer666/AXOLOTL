package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.components.AppClusterScreen
import com.example.ui.components.AppDetailDialog
import com.example.ui.components.BatchUninstallScreen
import com.example.ui.components.DesignInspectorScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                val clusters by viewModel.allClusters.collectAsStateWithLifecycle()
                val filteredApps by viewModel.filteredApps.collectAsStateWithLifecycle()
                val designApps by viewModel.designApps.collectAsStateWithLifecycle()
                val markedApps by viewModel.markedForUninstallApps.collectAsStateWithLifecycle()

                val snackbarHostState = remember { SnackbarHostState() }

                LaunchedEffect(uiState.infoNotice) {
                    uiState.infoNotice?.let { notice ->
                        snackbarHostState.showSnackbar(notice)
                        viewModel.dismissNotice()
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    topBar = {
                        TopAppBar(
                            title = {
                                Text(
                                    text = "App Cluster AI",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleLarge
                                )
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            modifier = Modifier.testTag("bottom_navigation_bar")
                        ) {
                            NavigationBarItem(
                                selected = uiState.currentTab == 0,
                                onClick = { viewModel.setCurrentTab(0) },
                                icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "Clusters") },
                                label = { Text("App Cluster") },
                                modifier = Modifier.testTag("nav_tab_clusters")
                            )
                            NavigationBarItem(
                                selected = uiState.currentTab == 1,
                                onClick = { viewModel.setCurrentTab(1) },
                                icon = { Icon(Icons.Default.Palette, contentDescription = "Design") },
                                label = { Text("Design Review") },
                                modifier = Modifier.testTag("nav_tab_design")
                            )
                            NavigationBarItem(
                                selected = uiState.currentTab == 2,
                                onClick = { viewModel.setCurrentTab(2) },
                                icon = { Icon(Icons.Default.Delete, contentDescription = "Batch") },
                                label = { Text("Batch Uninstall") },
                                modifier = Modifier.testTag("nav_tab_batch")
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (uiState.currentTab) {
                            0 -> AppClusterScreen(
                                uiState = uiState,
                                clusters = clusters,
                                apps = filteredApps,
                                onSearchQueryChange = viewModel::setSearchQuery,
                                onClusterSelect = viewModel::setSelectedCluster,
                                onAppClick = viewModel::selectAppForDetail,
                                onRunAiClustering = viewModel::runAiClustering,
                                onRescanApps = viewModel::runRescanInstalledApps
                            )
                            1 -> DesignInspectorScreen(
                                designApps = designApps,
                                onAppClick = viewModel::selectAppForDetail,
                                onMarkInspected = viewModel::markAppAsInspectedAndQueueUninstall
                            )
                            2 -> BatchUninstallScreen(
                                markedApps = markedApps,
                                onRemoveFromQueue = viewModel::toggleMarkForUninstall
                            )
                        }

                        uiState.selectedAppForDetail?.let { selectedApp ->
                            AppDetailDialog(
                                app = selectedApp,
                                onDismiss = { viewModel.selectAppForDetail(null) },
                                onToggleDesignCollector = viewModel::toggleDesignCollectorStatus,
                                onToggleMarkUninstall = viewModel::toggleMarkForUninstall
                            )
                        }
                    }
                }
            }
        }
    }
}
