package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build

object ShizukuTermuxHelper {

    /**
     * Launch standard Android uninstall prompt for a package
     */
    fun createUninstallIntent(packageName: String): Intent {
        val uri = Uri.fromParts("package", packageName, null)
        return Intent(Intent.ACTION_DELETE, uri).apply {
            putExtra(Intent.EXTRA_RETURN_RESULT, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    /**
     * Generate Shizuku / Termux batch uninstall shell command string
     * Users can copy this directly into Termux or run via Shizuku ADB environment
     */
    fun generateBatchUninstallCommand(packageNames: List<String>): String {
        if (packageNames.isEmpty()) return "# Keine Apps zum Deinstallieren ausgewählt"
        val sb = StringBuilder("# Termux / Shizuku ADB Batch Uninstall Script\n")
        sb.append("# Führen Sie diese Befehle in Termux oder via Shizuku shell aus:\n\n")
        for (pkg in packageNames) {
            sb.append("pm uninstall -k --user 0 $pkg\n")
        }
        return sb.toString()
    }

    /**
     * Generate Shizuku / Termux batch install shell command
     */
    fun generateBatchInstallCommand(apkPaths: List<String>): String {
        if (apkPaths.isEmpty()) return "# Keine APKs zum Installieren angegeben"
        val sb = StringBuilder("# Termux / Shizuku ADB Batch Install Script\n\n")
        for (path in apkPaths) {
            sb.append("pm install -r \"$path\"\n")
        }
        return sb.toString()
    }

    /**
     * Launch Termux App if installed
     */
    fun launchTermux(context: Context): Boolean {
        val pm = context.packageManager
        val intent = pm.getLaunchIntentForPackage("com.termux")
        return if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } else {
            false
        }
    }

    /**
     * Launch Shizuku App if installed
     */
    fun launchShizuku(context: Context): Boolean {
        val pm = context.packageManager
        val intent = pm.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        return if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } else {
            false
        }
    }
}
