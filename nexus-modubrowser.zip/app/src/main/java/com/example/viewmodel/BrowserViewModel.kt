package com.example.viewmodel

import android.webkit.WebView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.models.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class BrowserViewModel : ViewModel() {

    private val _tabs = MutableStateFlow<List<WebTab>>(
        listOf(
            WebTab(
                url = "https://chatgpt.com",
                title = "ChatGPT",
                isLlmTab = true,
                llmType = LlmType.CHATGPT
            ),
            WebTab(
                url = "https://notebooklm.google.com",
                title = "NotebookLM Workspace",
                isLlmTab = false
            ),
            WebTab(
                url = "https://github.com",
                title = "GitHub Developer Hub",
                isLlmTab = false
            )
        )
    )
    val tabs: StateFlow<List<WebTab>> = _tabs.asStateFlow()

    private val _activeTabId = MutableStateFlow(_tabs.value.first().id)
    val activeTabId: StateFlow<String> = _activeTabId.asStateFlow()

    // Active WebView instances map
    val webViewMap = mutableMapOf<String, WebView>()

    // Extension Modules (Zero RAM footprint when disabled or inactive)
    private val _modules = MutableStateFlow<List<ExtensionModule>>(
        listOf(
            ExtensionModule(
                id = "llm_radar",
                name = "LLM Radar & Auto-Reply",
                description = "Detects generation start/end on ChatGPT, Gemini, Claude, Kimi, Qwen, Grok, OpenRouter. Displays minigames and triggers auto-replies.",
                category = ModuleCategory.LLM_RADAR,
                uiHook = NativeUiHook.FLOATING_RADAR,
                isEnabled = true
            ),
            ExtensionModule(
                id = "notebook_lm_suite",
                name = "NotebookLM Workspace Sync",
                description = "Adds selected/all tabs to NotebookLM, downloads all sources, extracts code blocks.",
                category = ModuleCategory.NOTEBOOK_LM,
                uiHook = NativeUiHook.TOOLBAR_EMBEDDED,
                isEnabled = true
            ),
            ExtensionModule(
                id = "virtual_drive_clipboard",
                name = "Virtual Drive Clipboard",
                description = "Custom clipboard file manager drive accessible directly in file managers as a storage drive.",
                category = ModuleCategory.VIRTUAL_DRIVE,
                uiHook = NativeUiHook.NATIVE_DRAWER,
                isEnabled = true
            ),
            ExtensionModule(
                id = "github_lfs_sync",
                name = "GitHub Directory & LFS Exporter",
                description = "Download single files without full git clone, share folders to GitHub with LFS support.",
                category = ModuleCategory.GITHUB_LFS,
                uiHook = NativeUiHook.TOOLBAR_EMBEDDED,
                isEnabled = true
            ),
            ExtensionModule(
                id = "mcp_server_host",
                name = "Local MCP Server",
                description = "Runs local Model Context Protocol SSE server on localhost for external agents.",
                category = ModuleCategory.MCP_SERVER,
                uiHook = NativeUiHook.TOOLBAR_EMBEDDED,
                isEnabled = true
            )
        )
    )
    val modules: StateFlow<List<ExtensionModule>> = _modules.asStateFlow()

    // Virtual Drive Clipboard items
    private val _virtualDriveItems = MutableStateFlow<List<VirtualDriveItem>>(
        listOf(
            VirtualDriveItem(
                filename = "code_snippet_kotlin.kt",
                content = "fun helloModuBrowser() = println(\"Modular Zero-RAM Browser active!\")",
                mimeType = "text/x-kotlin",
                folder = "Code Snippets",
                isFavorite = true
            ),
            VirtualDriveItem(
                filename = "notebookLM_source_summary.txt",
                content = "Summary of research papers attached from open tabs.",
                mimeType = "text/plain",
                folder = "Main Clipboard",
                isFavorite = false
            )
        )
    )
    val virtualDriveItems: StateFlow<List<VirtualDriveItem>> = _virtualDriveItems.asStateFlow()

    // LLM Radar & Auto-reply state
    private val _activeLlmState = MutableStateFlow(LlmState.IDLE)
    val activeLlmState: StateFlow<LlmState> = _activeLlmState.asStateFlow()

    private val _activeLlmType = MutableStateFlow(LlmType.CHATGPT)
    val activeLlmType: StateFlow<LlmType> = _activeLlmType.asStateFlow()

    private val _entertainmentType = MutableStateFlow(EntertainmentType.ARCADE_PADDLE)
    val entertainmentType: StateFlow<EntertainmentType> = _entertainmentType.asStateFlow()

    private val _autoReplyCountdown = MutableStateFlow<Int?>(null)
    val autoReplyCountdown: StateFlow<Int?> = _autoReplyCountdown.asStateFlow()

    var autoReplyText = "Vielen Dank! Das ist genau das, was ich brauche. Bitte erstelle eine Zusammenfassung."
    var autoReplyDelaySeconds = 3

    private var countdownJob: Job? = null

    // MCP Server
    private val _isMcpServerRunning = MutableStateFlow(true)
    val isMcpServerRunning: StateFlow<Boolean> = _isMcpServerRunning.asStateFlow()

    private val _mcpTools = MutableStateFlow(
        listOf(
            McpTool("get_open_tabs", "Returns list of open browser tabs with titles & URLs", "{}"),
            McpTool("read_active_web_content", "Extracts readable text from currently active web tab", "{}"),
            McpTool("extract_code_blocks", "Extracts code blocks from active LLM tab", "{}"),
            McpTool("write_virtual_drive", "Creates new file in Virtual Drive Clipboard", "{\"filename\":\"str\", \"content\":\"str\"}")
        )
    )
    val mcpTools: StateFlow<List<McpTool>> = _mcpTools.asStateFlow()

    // Tab Management
    fun selectTab(id: String) {
        _activeTabId.value = id
    }

    fun addNewTab(url: String = "https://google.com") {
        val newTab = WebTab(url = url, title = "New Tab")
        _tabs.value = _tabs.value + newTab
        _activeTabId.value = newTab.id
    }

    fun closeTab(id: String) {
        if (_tabs.value.size <= 1) return
        val updated = _tabs.value.filter { it.id != id }
        _tabs.value = updated
        if (_activeTabId.value == id) {
            _activeTabId.value = updated.last().id
        }
        webViewMap.remove(id)
    }

    fun updateTabUrlAndTitle(id: String, url: String, title: String) {
        _tabs.value = _tabs.value.map {
            if (it.id == id) {
                val isLlm = LlmType.values().any { type -> type.hostPattern.isNotEmpty() && url.contains(type.hostPattern) }
                val llmType = LlmType.values().firstOrNull { type -> type.hostPattern.isNotEmpty() && url.contains(type.hostPattern) } ?: LlmType.NONE
                it.copy(url = url, title = title, isLlmTab = isLlm, llmType = llmType)
            } else it
        }
    }

    // LLM Radar Triggering
    fun handleLlmStateChange(llmType: LlmType, newState: LlmState) {
        _activeLlmType.value = llmType
        _activeLlmState.value = newState

        if (newState == LlmState.COMPLETED) {
            startAutoReplyCountdown()
        } else if (newState == LlmState.THINKING) {
            cancelAutoReplyCountdown()
        }
    }

    fun setEntertainmentType(type: EntertainmentType) {
        _entertainmentType.value = type
    }

    fun dismissLlmOverlay() {
        _activeLlmState.value = LlmState.IDLE
        cancelAutoReplyCountdown()
    }

    private fun startAutoReplyCountdown() {
        countdownJob?.cancel()
        countdownJob = viewModelScope.launch {
            _autoReplyCountdown.value = autoReplyDelaySeconds
            while ((_autoReplyCountdown.value ?: 0) > 0) {
                delay(1000)
                _autoReplyCountdown.value = (_autoReplyCountdown.value ?: 1) - 1
            }
            sendAutoReplyNow()
        }
    }

    fun cancelAutoReplyCountdown() {
        countdownJob?.cancel()
        _autoReplyCountdown.value = null
    }

    fun sendAutoReplyNow() {
        cancelAutoReplyCountdown()
        val activeId = _activeTabId.value
        val webView = webViewMap[activeId]
        val safeText = autoReplyText.replace("'", "\\'")
        webView?.evaluateJavascript("window.moduPerformAutoReply('$safeText');", null)
        _activeLlmState.value = LlmState.IDLE
    }

    // Virtual Drive
    fun addVirtualDriveItem(filename: String, content: String, folder: String) {
        val newItem = VirtualDriveItem(
            filename = filename,
            content = content,
            folder = folder
        )
        _virtualDriveItems.value = listOf(newItem) + _virtualDriveItems.value
    }

    fun toggleVirtualDriveFavorite(id: String) {
        _virtualDriveItems.value = _virtualDriveItems.value.map {
            if (it.id == id) it.copy(isFavorite = !it.isFavorite) else it
        }
    }

    fun deleteVirtualDriveItem(id: String) {
        _virtualDriveItems.value = _virtualDriveItems.value.filter { it.id != id }
    }

    // Module Toggling
    fun toggleModule(id: String) {
        _modules.value = _modules.value.map {
            if (it.id == id) it.copy(isEnabled = !it.isEnabled) else it
        }
    }

    // MCP Server
    fun setMcpServerRunning(running: Boolean) {
        _isMcpServerRunning.value = running
    }

    // Link List Generation
    fun generateFormattedLinkList(): String {
        return _tabs.value.joinToString("\n") { "- [${it.title}](${it.url})" }
    }
}
