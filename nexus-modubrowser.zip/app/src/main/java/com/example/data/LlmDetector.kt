package com.example.data

object LlmDetector {

    const val JS_BRIDGE_NAME = "ModuBridge"

    val INJECTION_SCRIPT = """
        (function() {
            if (window.__moduBridgeInjected) return;
            window.__moduBridgeInjected = true;

            console.log("ModuBrowser LLM Radar Bridge Initialized");

            let currentLlmType = "NONE";
            const host = window.location.hostname;

            if (host.includes("chatgpt.com") || host.includes("openai.com")) currentLlmType = "CHATGPT";
            else if (host.includes("gemini.google.com")) currentLlmType = "GEMINI";
            else if (host.includes("claude.ai")) currentLlmType = "CLAUDE";
            else if (host.includes("kimi.moonshot.cn") || host.includes("kimi.com")) currentLlmType = "KIMI";
            else if (host.includes("qwen") || host.includes("aliyun")) currentLlmType = "QWEN";
            else if (host.includes("grok.com") || host.includes("x.ai")) currentLlmType = "GROK";
            else if (host.includes("openrouter.ai")) currentLlmType = "OPENROUTER";
            else currentLlmType = "CUSTOM";

            let lastState = "IDLE";

            function checkThinking() {
                let isThinking = false;

                if (currentLlmType === "CHATGPT") {
                    isThinking = !!document.querySelector('button[data-testid="stop-button"]') ||
                                 !!document.querySelector('.result-streaming') ||
                                 !!document.querySelector('button[aria-label="Stop generating"]');
                } else if (currentLlmType === "CLAUDE") {
                    isThinking = !!document.querySelector('button[aria-label*="Stop"]') ||
                                 !!document.querySelector('.streaming') ||
                                 !!document.querySelector('[data-is-streaming="true"]');
                } else if (currentLlmType === "GEMINI") {
                    isThinking = !!document.querySelector('.mat-mdc-progress-spinner') ||
                                 !!document.querySelector('button[aria-label*="Stop"]') ||
                                 !!document.querySelector('.sparkle-anim');
                } else {
                    // Fallback heuristics for Kimi, Qwen, Grok, OpenRouter
                    isThinking = !!document.querySelector('.stop-button') ||
                                 !!document.querySelector('[data-state="generating"]') ||
                                 !!document.querySelector('.streaming') ||
                                 !!document.querySelector('button.stop') ||
                                 !!document.querySelector('.loading-spinner');
                }

                const newState = isThinking ? "THINKING" : "IDLE";
                if (newState !== lastState) {
                    // If transitioning from THINKING to IDLE, it means COMPLETED
                    const reportedState = (lastState === "THINKING" && newState === "IDLE") ? "COMPLETED" : newState;
                    lastState = newState;
                    if (window.ModuBridge && window.ModuBridge.onLlmStateChange) {
                        window.ModuBridge.onLlmStateChange(currentLlmType, reportedState);
                    }
                }
            }

            setInterval(checkThinking, 600);

            // Helper function for Auto-Reply injection
            window.moduPerformAutoReply = function(text) {
                let inputEl = document.querySelector('#prompt-textarea') || 
                              document.querySelector('textarea') || 
                              document.querySelector('[contenteditable="true"]');
                if (!inputEl) return false;

                if (inputEl.tagName === 'TEXTAREA' || inputEl.tagName === 'INPUT') {
                    inputEl.value = text;
                    inputEl.dispatchEvent(new Event('input', { bubbles: true }));
                } else {
                    inputEl.innerText = text;
                    inputEl.dispatchEvent(new Event('input', { bubbles: true }));
                }

                setTimeout(() => {
                    let sendBtn = document.querySelector('button[data-testid="send-button"]') || 
                                  document.querySelector('button[aria-label*="Send"]') || 
                                  document.querySelector('button[type="submit"]') ||
                                  document.querySelector('.send-button');
                    if (sendBtn) sendBtn.click();
                }, 400);

                return true;
            };

            // Extract code blocks from current page
            window.moduExtractCode = function() {
                const codeElements = document.querySelectorAll('pre code, pre');
                const results = [];
                codeElements.forEach((el, index) => {
                    const text = el.innerText.trim();
                    if (text && text.length > 5) {
                        results.push(text);
                    }
                });
                return JSON.stringify(results);
            };

            // Full chat self-scroll capture
            window.moduFullChatExport = function() {
                window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
                const mainContainer = document.querySelector('main') || document.body;
                return mainContainer.innerText;
            };

        })();
    """.trimIndent()
}
