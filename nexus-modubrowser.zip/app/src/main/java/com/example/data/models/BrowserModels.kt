package com.example.data.models

import java.util.UUID

enum class LlmType(val displayName: String, val hostPattern: String) {
    CHATGPT("ChatGPT", "chatgpt.com"),
    GEMINI("Gemini", "gemini.google.com"),
    CLAUDE("Claude", "claude.ai"),
    KIMI("Kimi", "kimi.moonshot.cn"),
    QWEN("Qwen", "chat.qwen.ai"),
    GROK("Grok", "grok.com"),
    OPENROUTER("OpenRouter", "openrouter.ai"),
    CUSTOM("Custom LLM", ""),
    NONE("Standard Web Page", "")
}

enum class LlmState {
    IDLE,
    THINKING,
    COMPLETED
}

enum class EntertainmentType(val label: String, val description: String) {
    ARCADE_PADDLE("Arcade Breakout", "Interactive retro paddle bounce game"),
    DIGITAL_RAIN("Matrix Digital Rain", "Cyberpunk cascading character stream"),
    ZEN_BREATHING("Zen Canvas", "Calming pulsating focus animation"),
    SNAKE_MINI("Retro Snake", "Classic mini snake arcade challenge")
}

data class WebTab(
    val id: String = UUID.randomUUID().toString(),
    val url: String = "https://chatgpt.com",
    val title: String = "New Tab",
    val faviconUrl: String? = null,
    val isLoading: Boolean = false,
    val progress: Int = 0,
    val isLlmTab: Boolean = false,
    val llmType: LlmType = LlmType.NONE,
    val llmState: LlmState = LlmState.IDLE,
    val autoReplyEnabled: Boolean = false,
    val autoReplyText: String = "Danke! Bitte erstelle als Nächstes die Zusammenfassung in Stichpunkten.",
    val autoReplyDelaySeconds: Int = 3,
    val capturedChat: String = "",
    val extractedCodeBlocks: List<String> = emptyList()
)

enum class ModuleCategory(val label: String) {
    LLM_RADAR("LLM Radar & Auto-Reply"),
    NOTEBOOK_LM("NotebookLM Tools"),
    GITHUB_LFS("GitHub & Directory Sync"),
    VIRTUAL_DRIVE("Virtual Drive Clipboard"),
    MCP_SERVER("Local MCP Server"),
    LINK_MANAGER("Link Lists & Favs"),
    CODE_EXTRACTOR("Code & Content Exporter")
}

enum class NativeUiHook {
    TOOLBAR_EMBEDDED,
    NATIVE_DRAWER,
    FLOATING_RADAR,
    CONTEXT_MENU
}

data class ExtensionModule(
    val id: String,
    val name: String,
    val description: String,
    val category: ModuleCategory,
    val uiHook: NativeUiHook,
    val isEnabled: Boolean = true,
    val ramConsumptionMb: Int = 0 // On-demand load: strictly 0 RAM when inactive
)

data class VirtualDriveItem(
    val id: String = UUID.randomUUID().toString(),
    val filename: String,
    val content: String,
    val mimeType: String = "text/plain",
    val folder: String = "Main Clipboard",
    val isFavorite: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class BookmarkItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val url: String,
    val folderName: String = "General",
    val isFavorite: Boolean = false
)

data class McpTool(
    val name: String,
    val description: String,
    val inputSchema: String,
    val isEnabled: Boolean = true
)
