package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBackground = Color(0xFF0F172A)
val CyberSurface = Color(0xFF1E293B)
val CyberSurfaceVariant = Color(0xFF334155)
val CyberPrimary = Color(0xFF38BDF8)
val CyberSecondary = Color(0xFF818CF8)
val CyberAccent = Color(0xFF34D399)
val CyberWarning = Color(0xFFFBBF24)
val CyberError = Color(0xFFF87171)

val CyberTextPrimary = Color(0xFFF8FAFC)
val CyberTextSecondary = Color(0xFF94A3B8)
val CyberBorder = Color(0xFF475569)
