package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.models.WebTab
import com.example.ui.theme.CyberAccent
import com.example.ui.theme.CyberPrimary

@Composable
fun GitHubSyncDialog(
    tabs: List<WebTab>,
    onDownloadSingleFile: (repoUrl: String, filePath: String) -> Unit,
    onShareToGithubLfs: (repoName: String, dirPath: String, enableLfs: Boolean) -> Unit,
    onCreateLinkList: () -> String,
    onDismiss: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Single File Download, 1: Share Directory & LFS, 2: Link List
    var repoUrl by remember { mutableStateOf("https://github.com/torvalds/linux") }
    var filePath by remember { mutableStateOf("README") }
    var targetRepo by remember { mutableStateOf("user/modu-browser-workspace") }
    var targetDir by remember { mutableStateOf("src/browser_exports") }
    var enableLfs by remember { mutableStateOf(true) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    val clipboardManager = LocalClipboardManager.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CloudSync, contentDescription = null, tint = CyberPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("GitHub & Link List Suite")
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                TabRow(selectedTabIndex = selectedTab) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("File Download") }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("LFS Export") }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("Link List") }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                when (selectedTab) {
                    0 -> {
                        Text(
                            text = "Download individual files directly from any GitHub repo without cloning the entire repository.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.LightGray
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = repoUrl,
                            onValueChange = { repoUrl = it },
                            label = { Text("GitHub Repository URL") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = filePath,
                            onValueChange = { filePath = it },
                            label = { Text("File Path in Repo (e.g. src/main.rs)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                onDownloadSingleFile(repoUrl, filePath)
                                statusMessage = "File '$filePath' fetched successfully!"
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary)
                        ) {
                            Icon(Icons.Default.Download, null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Download Single File")
                        }
                    }

                    1 -> {
                        Text(
                            text = "Push current tab state and attachments into specified GitHub directory with Git LFS support for large assets.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.LightGray
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = targetRepo,
                            onValueChange = { targetRepo = it },
                            label = { Text("Target Repo (owner/repo)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = targetDir,
                            onValueChange = { targetDir = it },
                            label = { Text("Subdirectory Path") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(
                                checked = enableLfs,
                                onCheckedChange = { enableLfs = it }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Enable Git LFS for binary assets")
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                onShareToGithubLfs(targetRepo, targetDir, enableLfs)
                                statusMessage = "Exported to $targetRepo/$targetDir (LFS: $enableLfs)"
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberAccent)
                        ) {
                            Icon(Icons.Default.CloudUpload, null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share to GitHub Directory")
                        }
                    }

                    2 -> {
                        val generatedList = onCreateLinkList()
                        Text(
                            text = "Generate formatted link list from open tabs:",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.LightGray
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.Black),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                        ) {
                            Box(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = generatedList,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyberAccent
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(generatedList))
                                statusMessage = "Link list copied to Clipboard!"
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.ContentCopy, null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Copy Link List to Clipboard")
                        }
                    }
                }

                statusMessage?.let { msg ->
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "✓ $msg",
                        color = CyberAccent,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
