package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.models.ExtensionModule
import com.example.data.models.NativeUiHook
import com.example.ui.theme.CyberAccent
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSurface

@Composable
fun NativeModulePanel(
    modules: List<ExtensionModule>,
    onToggleModule: (id: String) -> Unit,
    onExecuteModuleAction: (module: ExtensionModule) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Extension, contentDescription = null, tint = CyberAccent)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Native Extension Modules")
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Surface(
                    color = CyberPrimary.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Memory, contentDescription = null, tint = CyberPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Zero RAM Architecture: Modules run as pure functional native hooks without persistent background memory allocation.",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(modules) { module ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Surface(
                                            shape = CircleShape,
                                            color = CyberAccent.copy(alpha = 0.2f)
                                        ) {
                                            Icon(
                                                imageVector = when (module.uiHook) {
                                                    NativeUiHook.TOOLBAR_EMBEDDED -> Icons.Default.ViewHeadline
                                                    NativeUiHook.NATIVE_DRAWER -> Icons.Default.Storage
                                                    NativeUiHook.FLOATING_RADAR -> Icons.Default.Radar
                                                    NativeUiHook.CONTEXT_MENU -> Icons.Default.MenuOpen
                                                },
                                                contentDescription = null,
                                                tint = CyberAccent,
                                                modifier = Modifier
                                                    .padding(6.dp)
                                                    .size(18.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = module.name,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                            Text(
                                                text = "${module.category.label} • Native ${module.uiHook.name}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = CyberPrimary
                                            )
                                        }
                                    }

                                    Switch(
                                        checked = module.isEnabled,
                                        onCheckedChange = { onToggleModule(module.id) }
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = module.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.LightGray
                                )

                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "RAM Usage: 0 MB (On-Demand)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CyberAccent
                                    )

                                    if (module.isEnabled) {
                                        Button(
                                            onClick = { onExecuteModuleAction(module) },
                                            modifier = Modifier.height(32.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary)
                                        ) {
                                            Text("Run Module Action", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done")
            }
        }
    )
}
