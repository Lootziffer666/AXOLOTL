package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.EntertainmentType
import com.example.data.models.LlmType
import com.example.ui.theme.CyberAccent
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSecondary
import com.example.ui.theme.CyberWarning
import kotlinx.coroutines.delay

@Composable
fun LlmEntertainmentOverlay(
    isThinking: Boolean,
    isCompleted: Boolean,
    llmType: LlmType,
    entertainmentType: EntertainmentType,
    autoReplyCountdownSeconds: Int?,
    autoReplyText: String,
    onCancelAutoReply: () -> Unit,
    onSendAutoReplyNow: () -> Unit,
    onDismissOverlay: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = isThinking || isCompleted,
        enter = fadeIn(),
        exit = fadeOut(),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CyberBackground.copy(alpha = 0.92f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp, bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = if (isThinking) CyberWarning.copy(alpha = 0.2f) else CyberAccent.copy(alpha = 0.2f),
                            border = ButtonDefaults.outlinedButtonBorder
                        ) {
                            Icon(
                                imageVector = if (isThinking) Icons.Default.HourglassTop else Icons.Default.CheckCircle,
                                contentDescription = "Status",
                                tint = if (isThinking) CyberWarning else CyberAccent,
                                modifier = Modifier
                                    .padding(8.dp)
                                    .size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "${llmType.displayName} is ${if (isThinking) "generating answer..." else "finished!"}",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isThinking) "Radar Active • Minigame Arcade" else "Ready for response",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.LightGray
                            )
                        }
                    }

                    IconButton(onClick = onDismissOverlay) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Overlay",
                            tint = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (isCompleted) {
                    // LLM Finished Card with Auto-reply prompt
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AutoMode,
                                    contentDescription = null,
                                    tint = CyberAccent
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Auto-Reply Configured",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "\"$autoReplyText\"",
                                style = MaterialTheme.typography.bodyMedium,
                                color = CyberPrimary
                            )
                            Spacer(modifier = Modifier.height(16.dp))

                            if (autoReplyCountdownSeconds != null && autoReplyCountdownSeconds > 0) {
                                LinearProgressIndicator(
                                    progress = { autoReplyCountdownSeconds / 5f },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(CircleShape),
                                    color = CyberAccent,
                                    trackColor = Color.DarkGray
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "Sending automatically in $autoReplyCountdownSeconds seconds...",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = CyberWarning
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                OutlinedButton(onClick = onCancelAutoReply) {
                                    Text("Cancel Auto-Reply")
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Button(
                                    onClick = onSendAutoReplyNow,
                                    colors = ButtonDefaults.buttonColors(containerColor = CyberAccent)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Send,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Send Now")
                                }
                            }
                        }
                    }
                } else {
                    // Entertainment Interactive Minigame / Animation Canvas
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFF030712))
                    ) {
                        when (entertainmentType) {
                            EntertainmentType.ARCADE_PADDLE -> BreakoutMinigame()
                            EntertainmentType.DIGITAL_RAIN -> MatrixDigitalRainCanvas()
                            EntertainmentType.ZEN_BREATHING -> ZenPulsatingCanvas()
                            EntertainmentType.SNAKE_MINI -> MiniSnakeGame()
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bottom bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Zero RAM overhead when closed",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray
                    )

                    Button(
                        onClick = onDismissOverlay,
                        colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary)
                    ) {
                        Icon(imageVector = Icons.Default.Visibility, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("View Page Stream")
                    }
                }
            }
        }
    }
}

@Composable
fun BreakoutMinigame() {
    var paddleX by remember { mutableStateOf(180f) }
    var ballX by remember { mutableStateOf(200f) }
    var ballY by remember { mutableStateOf(300f) }
    var ballVx by remember { mutableStateOf(8f) }
    var ballVy by remember { mutableStateOf(-10f) }
    var score by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(16)
            ballX += ballVx
            ballY += ballVy

            // Wall collisions
            if (ballX <= 15f || ballX >= 360f) ballVx = -ballVx
            if (ballY <= 15f) ballVy = -ballVy

            // Paddle collision
            if (ballY >= 480f && ballY <= 500f && ballX >= paddleX - 50f && ballX <= paddleX + 50f) {
                ballVy = -Math.abs(ballVy)
                score += 10
            }

            // Bottom reset
            if (ballY > 550f) {
                ballX = 200f
                ballY = 300f
                ballVy = -10f
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    paddleX = (paddleX + dragAmount.x).coerceIn(50f, 330f)
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            // Draw Score
            // Draw Bricks
            val brickColors = listOf(CyberPrimary, CyberSecondary, CyberAccent, CyberWarning)
            for (row in 0..3) {
                for (col in 0..5) {
                    drawRect(
                        color = brickColors[row % brickColors.size],
                        topLeft = Offset(col * 60f + 10f, row * 25f + 40f),
                        size = Size(54f, 20f)
                    )
                }
            }

            // Draw Paddle
            drawRoundRect(
                color = CyberPrimary,
                topLeft = Offset(paddleX - 45f, 500f),
                size = Size(90f, 16f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
            )

            // Draw Ball
            drawCircle(
                color = CyberAccent,
                radius = 10f,
                center = Offset(ballX, ballY)
            )
        }

        Text(
            text = "SCORE: $score • Slide finger to control paddle",
            color = Color.White.copy(alpha = 0.8f),
            fontSize = 12.sp,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(10.dp)
        )
    }
}

@Composable
fun MatrixDigitalRainCanvas() {
    var tick by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(100)
            tick++
        }
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height
        val columns = 16
        val colWidth = width / columns

        for (i in 0 until columns) {
            val offset = (tick * (i % 5 + 3) * 15) % height.toInt()
            drawCircle(
                color = CyberAccent.copy(alpha = 0.8f),
                radius = 6f,
                center = Offset(i * colWidth + colWidth / 2, offset.toFloat())
            )
            drawRect(
                color = CyberAccent.copy(alpha = 0.2f),
                topLeft = Offset(i * colWidth + colWidth / 2 - 2f, (offset - 80).coerceAtLeast(0).toFloat()),
                size = Size(4f, 80f)
            )
        }
    }
}

@Composable
fun ZenPulsatingCanvas() {
    var phase by remember { mutableStateOf(0f) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(30)
            phase = (phase + 0.05f) % (2 * Math.PI.toFloat())
        }
    }

    val radiusScale = 0.8f + 0.2f * Math.sin(phase.toDouble()).toFloat()

    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.size(240.dp)) {
            drawCircle(
                color = CyberSecondary.copy(alpha = 0.3f * radiusScale),
                radius = size.width / 2 * radiusScale
            )
            drawCircle(
                color = CyberPrimary.copy(alpha = 0.6f * radiusScale),
                radius = size.width / 3 * radiusScale
            )
        }

        Text(
            text = "Focusing & Breathing",
            color = Color.White,
            fontWeight = FontWeight.Medium,
            fontSize = 14.sp
        )
    }
}

@Composable
fun MiniSnakeGame() {
    var headX by remember { mutableStateOf(10) }
    var headY by remember { mutableStateOf(10) }
    var dirX by remember { mutableStateOf(1) }
    var dirY by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(200)
            headX = (headX + dirX + 20) % 20
            headY = (headY + dirY + 20) % 20
        }
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .padding(12.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cellSize = size.width / 20
                drawRect(
                    color = CyberAccent,
                    topLeft = Offset(headX * cellSize, headY * cellSize),
                    size = Size(cellSize - 2f, cellSize - 2f)
                )
            }
        }

        Row(
            modifier = Modifier.padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            IconButton(onClick = { dirX = -1; dirY = 0 }) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            IconButton(onClick = { dirX = 0; dirY = -1 }) { Icon(Icons.Default.ArrowUpward, null, tint = Color.White) }
            IconButton(onClick = { dirX = 0; dirY = 1 }) { Icon(Icons.Default.ArrowDownward, null, tint = Color.White) }
            IconButton(onClick = { dirX = 1; dirY = 0 }) { Icon(Icons.Default.ArrowForward, null, tint = Color.White) }
        }
    }
}
