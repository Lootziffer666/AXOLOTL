package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.models.VirtualDriveItem
import com.example.ui.theme.CyberAccent
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberWarning

@Composable
fun VirtualDriveClipboardDialog(
    items: List<VirtualDriveItem>,
    onAddItem: (title: String, content: String, folder: String) -> Unit,
    onToggleFavorite: (id: String) -> Unit,
    onDeleteItem: (id: String) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedFolder by remember { mutableStateOf("All") }
    var showAddDialog by remember { mutableStateOf(false) }
    var newTitle by remember { mutableStateOf("") }
    var newContent by remember { mutableStateOf("") }
    var newFolder by remember { mutableStateOf("Main Clipboard") }
    val clipboardManager = LocalClipboardManager.current

    val folders = listOf("All", "Favorites", "Main Clipboard", "Code Snippets", "LLM Chats", "Web Links")
    val filteredItems = when (selectedFolder) {
        "All" -> items
        "Favorites" -> items.filter { it.isFavorite }
        else -> items.filter { it.folder == selectedFolder }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Storage, contentDescription = null, tint = CyberAccent)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Virtual Drive Clipboard")
                }
                IconButton(onClick = { showAddDialog = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Add Item", tint = CyberPrimary)
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Virtual Drive Provider Active (content://com.aistudio.modubrowser/drive). Accessible directly in File Managers as a virtual drive storage stream.",
                    style = MaterialTheme.typography.bodySmall,
                    color = CyberAccent
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Folder scroll bar
                ScrollableTabRow(
                    selectedTabIndex = folders.indexOf(selectedFolder).coerceAtLeast(0),
                    edgePadding = 0.dp
                ) {
                    folders.forEach { folder ->
                        Tab(
                            selected = selectedFolder == folder,
                            onClick = { selectedFolder = folder },
                            text = { Text(folder) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (filteredItems.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No clipboard items in '$selectedFolder'",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.Gray
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredItems) { item ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(12.dp)
                                        .fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (item.mimeType.contains("code")) Icons.Default.Code else Icons.Default.InsertDriveFile,
                                        contentDescription = null,
                                        tint = CyberPrimary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = item.filename,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                        Text(
                                            text = item.content,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.LightGray,
                                            maxLines = 2
                                        )
                                        Text(
                                            text = "${item.folder} • ${item.content.length} chars",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.Gray
                                        )
                                    }

                                    IconButton(onClick = { onToggleFavorite(item.id) }) {
                                        Icon(
                                            imageVector = if (item.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                            contentDescription = "Favorite",
                                            tint = if (item.isFavorite) CyberWarning else Color.Gray
                                        )
                                    }

                                    IconButton(onClick = {
                                        clipboardManager.setText(AnnotatedString(item.content))
                                    }) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = CyberAccent)
                                    }

                                    IconButton(onClick = { onDeleteItem(item.id) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.LightGray)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close Drive Viewer")
            }
        }
    )

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("New Drive Clipboard File") },
            text = {
                Column {
                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        label = { Text("Filename (e.g. prompt_notes.txt)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newContent,
                        onValueChange = { newContent = it },
                        label = { Text("File Content / Clipboard text") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newFolder,
                        onValueChange = { newFolder = it },
                        label = { Text("Virtual Folder") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newTitle.isNotBlank()) {
                            onAddItem(newTitle, newContent, newFolder)
                            showAddDialog = false
                            newTitle = ""
                            newContent = ""
                        }
                    }
                ) {
                    Text("Create Virtual File")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
