package com.example.ui

import android.webkit.WebView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.EntertainmentType
import com.example.data.models.LlmState
import com.example.data.models.LlmType
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.BrowserViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserHomeScreen(
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier
) {
    val tabs by viewModel.tabs.collectAsState()
    val activeTabId by viewModel.activeTabId.collectAsState()
    val activeTab = tabs.firstOrNull { it.id == activeTabId } ?: tabs.firstOrNull()

    val activeLlmState by viewModel.activeLlmState.collectAsState()
    val activeLlmType by viewModel.activeLlmType.collectAsState()
    val entertainmentType by viewModel.entertainmentType.collectAsState()
    val autoReplyCountdown by viewModel.autoReplyCountdown.collectAsState()

    val virtualDriveItems by viewModel.virtualDriveItems.collectAsState()
    val modules by viewModel.modules.collectAsState()
    val isMcpServerRunning by viewModel.isMcpServerRunning.collectAsState()
    val mcpTools by viewModel.mcpTools.collectAsState()

    var urlInputText by remember(activeTab?.url) { mutableStateOf(activeTab?.url ?: "") }
    var showTabsDrawer by remember { mutableStateOf(false) }

    // Dialog Visibility States
    var showNotebookLmDialog by remember { mutableStateOf(false) }
    var showGithubDialog by remember { mutableStateOf(false) }
    var showVirtualDriveDialog by remember { mutableStateOf(false) }
    var showMcpDialog by remember { mutableStateOf(false) }
    var showNativeModulePanel by remember { mutableStateOf(false) }

    val clipboardManager = LocalClipboardManager.current

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyberSurface)
                    .statusBarsPadding()
            ) {
                // Top Action & Extension Module Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Logo & App Name
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { showNativeModulePanel = true }
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = CyberPrimary.copy(alpha = 0.2f),
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Extension,
                                contentDescription = null,
                                tint = CyberPrimary,
                                modifier = Modifier.padding(6.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "ModuBrowser",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "0 RAM Extensions",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberAccent,
                                fontSize = 10.sp
                            )
                        }
                    }

                    // Native Toolbar Modules (Zero-RAM Native Extensions)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // NotebookLM Suite Button
                        IconButton(onClick = { showNotebookLmDialog = true }) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "NotebookLM",
                                tint = CyberAccent
                            )
                        }

                        // GitHub & Directory Sync
                        IconButton(onClick = { showGithubDialog = true }) {
                            Icon(
                                imageVector = Icons.Default.CloudSync,
                                contentDescription = "GitHub",
                                tint = CyberPrimary
                            )
                        }

                        // Virtual Drive Clipboard
                        IconButton(onClick = { showVirtualDriveDialog = true }) {
                            BadgedBox(badge = {
                                Badge(containerColor = CyberWarning) {
                                    Text("${virtualDriveItems.size}")
                                }
                            }) {
                                Icon(
                                    imageVector = Icons.Default.Storage,
                                    contentDescription = "Virtual Drive Clipboard",
                                    tint = Color.White
                                )
                            }
                        }

                        // MCP Server Button
                        IconButton(onClick = { showMcpDialog = true }) {
                            Icon(
                                imageVector = Icons.Default.Dns,
                                contentDescription = "MCP Server",
                                tint = if (isMcpServerRunning) CyberAccent else Color.Gray
                            )
                        }

                        // Modules Manager Button
                        IconButton(onClick = { showNativeModulePanel = true }) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = "Modules",
                                tint = Color.LightGray
                            )
                        }
                    }
                }

                // Address Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            val webView = activeTab?.let { viewModel.webViewMap[it.id] }
                            if (webView?.canGoBack() == true) webView.goBack()
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = {
                            val webView = activeTab?.let { viewModel.webViewMap[it.id] }
                            if (webView?.canGoForward() == true) webView.goForward()
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "Forward",
                            tint = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    TextField(
                        value = urlInputText,
                        onValueChange = { urlInputText = it },
                        singleLine = true,
                        placeholder = { Text("Enter URL or LLM prompt...", fontSize = 13.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(24.dp)),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        trailingIcon = {
                            IconButton(onClick = {
                                var formattedUrl = urlInputText.trim()
                                if (!formattedUrl.startsWith("http://") && !formattedUrl.startsWith("https://")) {
                                    formattedUrl = "https://$formattedUrl"
                                }
                                activeTab?.let {
                                    val webView = viewModel.webViewMap[it.id]
                                    webView?.loadUrl(formattedUrl)
                                }
                            }) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "Navigate",
                                    tint = CyberPrimary
                                )
                            }
                        }
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    // Tab Count Button
                    Surface(
                        onClick = { showTabsDrawer = true },
                        shape = RoundedCornerShape(8.dp),
                        color = CyberPrimary,
                        modifier = Modifier.height(36.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Tab,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${tabs.size}",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }
                }

                // Horizontal Tab Bar Strip
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    tabs.forEach { tab ->
                        val isSelected = tab.id == activeTabId
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.selectTab(tab.id) },
                            label = {
                                Text(
                                    text = tab.title.ifEmpty { "Tab" },
                                    maxLines = 1,
                                    fontSize = 12.sp
                                )
                            },
                            leadingIcon = if (tab.isLlmTab) {
                                {
                                    Icon(
                                        imageVector = Icons.Default.Psychology,
                                        contentDescription = "LLM Tab",
                                        tint = CyberAccent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            } else null,
                            trailingIcon = if (tabs.size > 1) {
                                {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Close",
                                        modifier = Modifier
                                            .size(14.dp)
                                            .clickable { viewModel.closeTab(tab.id) }
                                    )
                                }
                            } else null,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyberPrimary,
                                selectedLabelColor = Color.Black,
                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                labelColor = Color.White
                            )
                        )
                    }

                    // Add Tab Button
                    IconButton(
                        onClick = { viewModel.addNewTab("https://chatgpt.com") },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "New Tab",
                            tint = CyberPrimary
                        )
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Active Tab WebView Rendering
            activeTab?.let { tab ->
                BrowserWebView(
                    url = tab.url,
                    onTitleChanged = { newTitle ->
                        viewModel.updateTabUrlAndTitle(tab.id, tab.url, newTitle)
                    },
                    onProgressChanged = { progress -> },
                    onLlmStateChange = { llmType, state ->
                        viewModel.handleLlmStateChange(llmType, state)
                    },
                    onWebViewCreated = { webView ->
                        viewModel.webViewMap[tab.id] = webView
                    }
                )
            }

            // LLM Radar Floating Indicator Banner (if LLM is thinking/active)
            AnimatedVisibility(
                visible = activeLlmState != LlmState.IDLE,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 12.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = CyberSurface,
                    shadowElevation = 8.dp,
                    border = ButtonDefaults.outlinedButtonBorder,
                    modifier = Modifier.clickable {
                        // Open minigame / entertainment view
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Radar,
                            contentDescription = null,
                            tint = if (activeLlmState == LlmState.THINKING) CyberWarning else CyberAccent,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${activeLlmType.displayName}: ${if (activeLlmState == LlmState.THINKING) "Working..." else "Done!"}",
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // LLM Entertainment Overlay (Minigame / Arcade canvas when LLM is generating)
            LlmEntertainmentOverlay(
                isThinking = activeLlmState == LlmState.THINKING,
                isCompleted = activeLlmState == LlmState.COMPLETED,
                llmType = activeLlmType,
                entertainmentType = entertainmentType,
                autoReplyCountdownSeconds = autoReplyCountdown,
                autoReplyText = viewModel.autoReplyText,
                onCancelAutoReply = { viewModel.cancelAutoReplyCountdown() },
                onSendAutoReplyNow = { viewModel.sendAutoReplyNow() },
                onDismissOverlay = { viewModel.dismissLlmOverlay() }
            )
        }
    }

    // Modal Extensions & Tools Dialogs
    if (showNotebookLmDialog) {
        NotebookLmSuiteDialog(
            tabs = tabs,
            activeTab = activeTab,
            onAddTabsToNotebook = { selectedTabs ->
                viewModel.addVirtualDriveItem(
                    filename = "notebookLM_batch_sources.txt",
                    content = selectedTabs.joinToString("\n\n") { "Title: ${it.title}\nURL: ${it.url}" },
                    folder = "LLM Chats"
                )
            },
            onDownloadNotebookSources = {
                viewModel.addVirtualDriveItem(
                    filename = "notebookLM_all_sources.zip",
                    content = "Downloaded source documents bundle from NotebookLM workspace.",
                    folder = "Main Clipboard"
                )
            },
            onExtractCodeBlocks = {
                val activeWebView = activeTab?.let { viewModel.webViewMap[it.id] }
                activeWebView?.evaluateJavascript("window.moduExtractCode();") { codeJson ->
                    viewModel.addVirtualDriveItem(
                        filename = "extracted_code_blocks.txt",
                        content = codeJson ?: "// No code blocks found",
                        folder = "Code Snippets"
                    )
                }
            },
            onFullChatExport = {
                val activeWebView = activeTab?.let { viewModel.webViewMap[it.id] }
                activeWebView?.evaluateJavascript("window.moduFullChatExport();") { chatContent ->
                    viewModel.addVirtualDriveItem(
                        filename = "full_llm_chat_export.txt",
                        content = chatContent ?: "Chat captured with self scroll.",
                        folder = "LLM Chats"
                    )
                }
            },
            onDismiss = { showNotebookLmDialog = false }
        )
    }

    if (showGithubDialog) {
        GitHubSyncDialog(
            tabs = tabs,
            onDownloadSingleFile = { repoUrl, filePath ->
                viewModel.addVirtualDriveItem(
                    filename = filePath.substringAfterLast('/'),
                    content = "// Single file fetched directly from $repoUrl ($filePath) without full git clone",
                    folder = "Code Snippets"
                )
            },
            onShareToGithubLfs = { repo, dir, lfs ->
                viewModel.addVirtualDriveItem(
                    filename = "github_lfs_export_log.txt",
                    content = "Exported open tabs to $repo/$dir with LFS = $lfs",
                    folder = "Main Clipboard"
                )
            },
            onCreateLinkList = { viewModel.generateFormattedLinkList() },
            onDismiss = { showGithubDialog = false }
        )
    }

    if (showVirtualDriveDialog) {
        VirtualDriveClipboardDialog(
            items = virtualDriveItems,
            onAddItem = { filename, content, folder ->
                viewModel.addVirtualDriveItem(filename, content, folder)
            },
            onToggleFavorite = { id -> viewModel.toggleVirtualDriveFavorite(id) },
            onDeleteItem = { id -> viewModel.deleteVirtualDriveItem(id) },
            onDismiss = { showVirtualDriveDialog = false }
        )
    }

    if (showMcpDialog) {
        McpServerDialog(
            mcpTools = mcpTools,
            isServerRunning = isMcpServerRunning,
            onToggleServer = { running -> viewModel.setMcpServerRunning(running) },
            onDismiss = { showMcpDialog = false }
        )
    }

    if (showNativeModulePanel) {
        NativeModulePanel(
            modules = modules,
            onToggleModule = { id -> viewModel.toggleModule(id) },
            onExecuteModuleAction = { module ->
                when (module.id) {
                    "notebook_lm_suite" -> showNotebookLmDialog = true
                    "virtual_drive_clipboard" -> showVirtualDriveDialog = true
                    "github_lfs_sync" -> showGithubDialog = true
                    "mcp_server_host" -> showMcpDialog = true
                }
            },
            onDismiss = { showNativeModulePanel = false }
        )
    }
}
