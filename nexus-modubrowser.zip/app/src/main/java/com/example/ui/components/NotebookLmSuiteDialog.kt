package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.models.WebTab
import com.example.ui.theme.CyberAccent
import com.example.ui.theme.CyberPrimary

@Composable
fun NotebookLmSuiteDialog(
    tabs: List<WebTab>,
    activeTab: WebTab?,
    onAddTabsToNotebook: (List<WebTab>) -> Unit,
    onDownloadNotebookSources: () -> Unit,
    onExtractCodeBlocks: () -> Unit,
    onFullChatExport: () -> Unit,
    onDismiss: () -> Unit
) {
    var selectedTabIds by remember { mutableStateOf(tabs.map { it.id }.toSet()) }
    val clipboardManager = LocalClipboardManager.current
    var showSuccessMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = CyberAccent
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("NotebookLM & Chat Extractor")
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Seamlessly sync current web tabs with NotebookLM notebooks or extract structured code & chat history.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.LightGray
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            onDownloadNotebookSources()
                            showSuccessMessage = "Downloaded NotebookLM sources bundle!"
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Download, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Download Sources", style = MaterialTheme.typography.labelSmall)
                    }

                    OutlinedButton(
                        onClick = {
                            onExtractCodeBlocks()
                            showSuccessMessage = "Extracted all code blocks to Clipboard!"
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Code, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Extract Code", style = MaterialTheme.typography.labelSmall)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = {
                        onFullChatExport()
                        showSuccessMessage = "Full chat captured (with self-scroll)!"
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary)
                ) {
                    Icon(Icons.Default.ReceiptLong, null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Export Full Chat (Self-Scroll)")
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider()
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Select Tabs to Sync to NotebookLM:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                ) {
                    items(tabs) { tab ->
                        val isSelected = selectedTabIds.contains(tab.id)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isSelected,
                                onCheckedChange = { checked ->
                                    selectedTabIds = if (checked) {
                                        selectedTabIds + tab.id
                                    } else {
                                        selectedTabIds - tab.id
                                    }
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = tab.title.ifEmpty { tab.url },
                                    style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 1
                                )
                                Text(
                                    text = tab.url,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.Gray,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                showSuccessMessage?.let { msg ->
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "✓ $msg",
                        color = CyberAccent,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val selectedTabs = tabs.filter { selectedTabIds.contains(it.id) }
                    onAddTabsToNotebook(selectedTabs)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = CyberAccent)
            ) {
                Text("Add Selected (${selectedTabIds.size}) to NotebookLM")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
