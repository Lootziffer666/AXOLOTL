package com.example.ui.components

import android.graphics.Bitmap
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.LlmDetector
import com.example.data.models.LlmState
import com.example.data.models.LlmType

@Composable
fun BrowserWebView(
    url: String,
    onTitleChanged: (String) -> Unit,
    onProgressChanged: (Int) -> Unit,
    onLlmStateChange: (LlmType, LlmState) -> Unit,
    onWebViewCreated: (WebView) -> Unit,
    modifier: Modifier = Modifier
) {
    AndroidView(
        factory = { context ->
            WebView(context).apply {
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                    userAgentString = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
                }

                addJavascriptInterface(object {
                    @JavascriptInterface
                    fun onLlmStateChange(typeStr: String, stateStr: String) {
                        val type = try { LlmType.valueOf(typeStr) } catch (e: Exception) { LlmType.CUSTOM }
                        val state = when (stateStr) {
                            "THINKING" -> LlmState.THINKING
                            "COMPLETED" -> LlmState.COMPLETED
                            else -> LlmState.IDLE
                        }
                        onLlmStateChange(type, state)
                    }
                }, LlmDetector.JS_BRIDGE_NAME)

                webChromeClient = object : WebChromeClient() {
                    override fun onProgressChanged(view: WebView?, newProgress: Int) {
                        onProgressChanged(newProgress)
                    }

                    override fun onReceivedTitle(view: WebView?, title: String?) {
                        title?.let { onTitleChanged(it) }
                    }
                }

                webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                        super.onPageStarted(view, url, favicon)
                        onProgressChanged(10)
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        onProgressChanged(100)
                        view?.title?.let { onTitleChanged(it) }
                        // Inject LLM Radar Detector JavaScript
                        view?.evaluateJavascript(LlmDetector.INJECTION_SCRIPT, null)
                    }
                }

                loadUrl(url)
                onWebViewCreated(this)
            }
        },
        update = { webView ->
            if (webView.url != url && !url.isBlank() && webView.url == null) {
                webView.loadUrl(url)
            }
        },
        modifier = modifier.fillMaxSize()
    )
}
