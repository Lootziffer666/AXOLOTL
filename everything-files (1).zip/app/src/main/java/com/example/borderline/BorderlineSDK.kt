package com.example.borderline

import android.content.Context
import android.content.Intent
import android.net.Uri

object BorderlineSDK {

    // 1. Spezielles Borderline-Menü öffnen (0: Dock, 1: Snippets, 2: Clipboard+, 3: Actions)
    fun openMenu(context: Context, menuIndex: Int = 0) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("borderline://open?menu=$menuIndex")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // 2. Text/Prompt direkt in das Snippet-Kapsel-System von Borderline speichern
    fun addSnippet(context: Context, title: String, content: String, category: String = "Prompt") {
        val uri = Uri.Builder()
            .scheme("borderline")
            .authority("add-snippet")
            .appendQueryParameter("title", title)
            .appendQueryParameter("content", content)
            .appendQueryParameter("category", category)
            .build()
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // 3. Text direkt an die Borderline Appendix-Sammelliste anhängen
    fun appendToAppendix(context: Context, text: String) {
        val uri = Uri.Builder()
            .scheme("borderline")
            .authority("appendix")
            .appendQueryParameter("text", text)
            .build()
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
