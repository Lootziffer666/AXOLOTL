package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Dock
import androidx.compose.material.icons.filled.IntegrationInstructions
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderColor
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.PurpleContainer
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardElevated
import com.example.ui.theme.TextMain
import com.example.ui.theme.TextMuted

@Composable
fun BorderlineSection(
    onOpenMenu: (menuIndex: Int) -> Unit,
    onAddCustomSnippet: (title: String, content: String) -> Unit,
    onAppendAppendix: (text: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var snippetTitle by remember { mutableStateOf("File Index Export") }
    var snippetContent by remember { mutableStateOf("Everything Index report: 42 files scanned, 0 dupes pending.") }
    var appendixText by remember { mutableStateOf("Consolidation log appended to productivity workspace.") }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(SurfaceCardElevated)
            .border(1.dp, BorderColor, RoundedCornerShape(24.dp))
            .padding(16.dp)
            .testTag("borderline_section")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.IntegrationInstructions,
                contentDescription = "SDK",
                tint = PurplePrimary,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "BORDERLINE SDK INTEGRATION",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = PurplePrimary,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Inter-app communication protocol for Productivity ecosystem",
                    fontSize = 10.sp,
                    color = TextMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Menu buttons (0: Dock, 1: Snippets, 2: Clipboard+, 3: Actions)
        Text(text = "Trigger Borderline Menus", fontSize = 11.sp, color = TextMuted)
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { onOpenMenu(0) },
                colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard, contentColor = TextMain),
                modifier = Modifier
                    .weight(1f)
                    .testTag("open_borderline_dock"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.Dock, contentDescription = "Dock", modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Dock", fontSize = 11.sp)
            }

            Button(
                onClick = { onOpenMenu(1) },
                colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard, contentColor = TextMain),
                modifier = Modifier
                    .weight(1f)
                    .testTag("open_borderline_snippets"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.Send, contentDescription = "Snippets", modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Snippets", fontSize = 11.sp)
            }

            Button(
                onClick = { onOpenMenu(2) },
                colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard, contentColor = TextMain),
                modifier = Modifier
                    .weight(1f)
                    .testTag("open_borderline_clipboard"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.ContentPaste, contentDescription = "Clipboard", modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Clipboard+", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Snippet Dispatcher Form
        Text(text = "Dispatch Snippet Capsule", fontSize = 11.sp, color = TextMuted)
        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
            value = snippetTitle,
            onValueChange = { snippetTitle = it },
            label = { Text("Title", fontSize = 11.sp) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PurplePrimary,
                unfocusedBorderColor = BorderColor,
                focusedLabelColor = PurplePrimary,
                unfocusedLabelColor = TextMuted
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("snippet_title_input"),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
            value = snippetContent,
            onValueChange = { snippetContent = it },
            label = { Text("Snippet Content", fontSize = 11.sp) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PurplePrimary,
                unfocusedBorderColor = BorderColor,
                focusedLabelColor = PurplePrimary,
                unfocusedLabelColor = TextMuted
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("snippet_content_input"),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = { onAddCustomSnippet(snippetTitle, snippetContent) },
            colors = ButtonDefaults.buttonColors(containerColor = PurpleContainer, contentColor = PurplePrimary),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("dispatch_snippet_button"),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(imageVector = Icons.Default.Send, contentDescription = "Send", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "Dispatch to Borderline Snippets", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Appendix Log Form
        Text(text = "Append to Borderline Appendix", fontSize = 11.sp, color = TextMuted)
        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
            value = appendixText,
            onValueChange = { appendixText = it },
            label = { Text("Appendix Entry", fontSize = 11.sp) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PurplePrimary,
                unfocusedBorderColor = BorderColor,
                focusedLabelColor = PurplePrimary,
                unfocusedLabelColor = TextMuted
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("appendix_text_input"),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = { onAppendAppendix(appendixText) },
            colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard, contentColor = PurplePrimary),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("dispatch_appendix_button"),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(imageVector = Icons.Default.NoteAdd, contentDescription = "Appendix", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "Append to Borderline Appendix", fontSize = 12.sp)
        }
    }
}
