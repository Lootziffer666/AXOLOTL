package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DrawerBackground
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.TextMain
import com.example.ui.theme.TextMuted

@Composable
fun AppNavigationDrawerContent(
    selectedCategory: FileCategory?,
    showHiddenFiles: Boolean,
    rootExplorerActive: Boolean,
    onSelectCategory: (FileCategory?) -> Unit,
    onToggleShowHidden: (Boolean) -> Unit,
    onToggleRootExplorer: (Boolean) -> Unit,
    onOpenTool: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var isWerkzeugeExpanded by remember { mutableStateOf(true) }
    var isTypExpanded by remember { mutableStateOf(true) }
    var isFavoritenExpanded by remember { mutableStateOf(true) }

    ModalDrawerSheet(
        drawerContainerColor = DrawerBackground,
        drawerContentColor = TextMain,
        modifier = modifier
            .width(300.dp)
            .fillMaxHeight()
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .padding(vertical = 16.dp, horizontal = 16.dp)
                .verticalScroll(rememberScrollState())
                .testTag("app_navigation_drawer")
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(PurplePrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderSpecial,
                        contentDescription = "Logo",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Everything Manager",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMain
                    )
                    Text(
                        text = "Local Storage & Index",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }

            HorizontalDivider(color = Color(0xFF2C2C2E))
            Spacer(modifier = Modifier.height(12.dp))

            // Section: Favoriten
            DrawerSectionHeader(
                title = "Favoriten",
                icon = Icons.Default.Star,
                isExpanded = isFavoritenExpanded,
                onToggle = { isFavoritenExpanded = !isFavoritenExpanded }
            )

            if (isFavoritenExpanded) {
                DrawerTreeItem(title = "Download", onClick = { onOpenTool("Download") })
                DrawerTreeItem(title = "DCIM / Kamera", onClick = { onOpenTool("DCIM") })
                DrawerTreeItem(title = "Dokumente", onClick = { onOpenTool("Dokumente") })
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section: Werkzeuge (Tools)
            DrawerSectionHeader(
                title = "Werkzeuge",
                icon = Icons.Default.Build,
                isExpanded = isWerkzeugeExpanded,
                onToggle = { isWerkzeugeExpanded = !isWerkzeugeExpanded }
            )

            if (isWerkzeugeExpanded) {
                DrawerTreeItem(title = "Neue Dateien", onClick = { onOpenTool("Neue Dateien") })
                DrawerTreeItem(title = "Reiniger (Cleaner)", onClick = { onOpenTool("Reiniger") })
                DrawerTreeItem(title = "Papierkorb (Trash)", onClick = { onOpenTool("Papierkorb") })
                DrawerTreeItem(title = "Super Downloader", onClick = { onOpenTool("Super Downloader") })
                DrawerTreeItem(title = "Analysieren", onClick = { onOpenTool("Analysieren") })
                DrawerTreeItem(title = "Super-Texteditor", onClick = { onOpenTool("Super-Texteditor") })
                DrawerTreeItem(title = "Secure Vault", onClick = { onOpenTool("Secure Vault") })
                DrawerTreeItem(title = "Remote / LAN (FTP)", onClick = { onOpenTool("Remote / LAN") })

                // Root-Explorer switch line
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp, horizontal = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF2196F3))
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Root-Explorer",
                            fontSize = 12.sp,
                            color = TextMain
                        )
                    }
                    Switch(
                        checked = rootExplorerActive,
                        onCheckedChange = onToggleRootExplorer,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = PurplePrimary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section: Typ / Kategorien
            DrawerSectionHeader(
                title = "Typ",
                icon = Icons.Default.Folder,
                isExpanded = isTypExpanded,
                onToggle = { isTypExpanded = !isTypExpanded }
            )

            if (isTypExpanded) {
                FileCategory.values().forEach { category ->
                    val isSelected = selectedCategory == category
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) Color(0xFF2C2C2E) else Color.Transparent)
                            .clickable {
                                if (isSelected) onSelectCategory(null)
                                else onSelectCategory(category)
                            }
                            .padding(vertical = 6.dp, horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(category.color)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = category.label,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) category.color else TextMain
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = Color(0xFF2C2C2E))
            Spacer(modifier = Modifier.height(12.dp))

            // Hidden files toggle row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleShowHidden(!showHiddenFiles) }
                    .padding(vertical = 8.dp, horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (showHiddenFiles) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                        contentDescription = "Hidden",
                        tint = PurplePrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Versteckte Dateien anzeigen",
                        fontSize = 12.sp,
                        color = TextMain
                    )
                }
                Switch(
                    checked = showHiddenFiles,
                    onCheckedChange = onToggleShowHidden,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = PurplePrimary
                    )
                )
            }
        }
    }
}

@Composable
private fun DrawerSectionHeader(
    title: String,
    icon: ImageVector,
    isExpanded: Boolean,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggle() }
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = PurplePrimary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextMain
            )
        }
        Icon(
            imageVector = if (isExpanded) Icons.Default.ExpandMore else Icons.Default.ChevronRight,
            contentDescription = "Expand",
            tint = TextMuted,
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun DrawerTreeItem(
    title: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(vertical = 6.dp, horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(Color(0xFF2196F3))
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = title,
            fontSize = 12.sp,
            color = TextMain
        )
    }
}
