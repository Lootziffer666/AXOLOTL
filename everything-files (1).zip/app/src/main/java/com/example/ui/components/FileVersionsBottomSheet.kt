package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FileItem
import com.example.model.FileVersion
import com.example.ui.theme.BorderColor
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.PurpleContainer
import com.example.ui.theme.PurpleLightContainer
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardElevated
import com.example.ui.theme.TextMain
import com.example.ui.theme.TextMuted
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileVersionsBottomSheet(
    file: FileItem,
    onDismiss: () -> Unit,
    onToggleProtection: (fileId: String, currentProtection: Boolean) -> Unit,
    onToggleVersionProtection: (versionId: String, currentProtection: Boolean) -> Unit,
    onSwitchVersion: (fileId: String, versionNumber: Int) -> Unit,
    onSendToBorderlineSnippet: (file: FileItem) -> Unit,
    onSendToBorderlineAppendix: (file: FileItem) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceCardElevated,
        contentColor = TextMain,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .testTag("file_versions_sheet")
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "Versions",
                        tint = PurplePrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = file.canonicalName,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextMain
                        )
                        Text(
                            text = "Shadow Volume Versions (${file.versions.size} snapshots)",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                }

                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main Protection Banner & Constraint note
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(DarkBackground)
                    .border(1.dp, BorderColor, RoundedCornerShape(14.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (file.isProtected) "Protected File (Locked)" else "Auto-Purge Eligible (+10d rule)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (file.isProtected) PurplePrimary else TextMuted
                    )
                    Text(
                        text = "Max 10 versions for files <5MB • Older versions archived",
                        fontSize = 10.sp,
                        color = TextMuted.copy(alpha = 0.8f)
                    )
                }

                Button(
                    onClick = { onToggleProtection(file.id, file.isProtected) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (file.isProtected) PurpleContainer else SurfaceCard,
                        contentColor = PurplePrimary
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("toggle_protection_button")
                ) {
                    Icon(
                        imageVector = if (file.isProtected) Icons.Default.Lock else Icons.Default.LockOpen,
                        contentDescription = "Lock",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (file.isProtected) "Locked" else "Protect",
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "VERSION TIMELINE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = PurplePrimary,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Timeline List of Versions
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(file.versions.ifEmpty {
                    listOf(
                        FileVersion(
                            versionId = file.id + "_v1",
                            fileId = file.id,
                            versionNumber = file.activeVersionNumber,
                            filePath = file.currentPath,
                            sizeBytes = file.sizeBytes,
                            contentHash = file.contentHash,
                            timestamp = file.lastModified,
                            isProtected = file.isProtected,
                            note = "Primary Version"
                        )
                    )
                }) { ver ->
                    val isActive = ver.versionNumber == file.activeVersionNumber
                    VersionTimelineItem(
                        version = ver,
                        isActive = isActive,
                        onSelect = { onSwitchVersion(file.id, ver.versionNumber) },
                        onToggleVersionProtection = { onToggleVersionProtection(ver.versionId, ver.isProtected) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Borderline Integration Action Buttons
            Text(
                text = "BORDERLINE SYSTEM ACTIONS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = PurplePrimary,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { onSendToBorderlineSnippet(file) },
                    colors = ButtonDefaults.buttonColors(containerColor = PurpleContainer, contentColor = PurplePrimary),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("borderline_snippet_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.Send, contentDescription = "Snippet", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "+ Snippet", fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = { onSendToBorderlineAppendix(file) },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMain),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("borderline_appendix_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.NoteAdd, contentDescription = "Appendix", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "+ Appendix", fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun VersionTimelineItem(
    version: FileVersion,
    isActive: Boolean,
    onSelect: () -> Unit,
    onToggleVersionProtection: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (isActive) PurpleContainer.copy(alpha = 0.4f) else DarkBackground)
            .border(
                1.dp,
                if (isActive) PurplePrimary else BorderColor,
                RoundedCornerShape(14.dp)
            )
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(if (isActive) PurplePrimary else SurfaceCard),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "v${version.versionNumber}",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (isActive) PurpleContainer else TextMain
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (isActive) "Active Primary" else "Shadow Volume",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isActive) PurplePrimary else TextMain
                )
                if (isActive) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Active",
                        tint = PurplePrimary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Text(
                text = "${formatDate(version.timestamp)} • ${formatSize(version.sizeBytes)}",
                fontSize = 10.sp,
                color = TextMuted
            )
        }

        IconButton(onClick = onToggleVersionProtection, modifier = Modifier.size(32.dp)) {
            Icon(
                imageVector = if (version.isProtected) Icons.Default.Lock else Icons.Default.LockOpen,
                contentDescription = "Lock version",
                tint = if (version.isProtected) PurplePrimary else TextMuted,
                modifier = Modifier.size(16.dp)
            )
        }

        if (!isActive) {
            Spacer(modifier = Modifier.width(4.dp))
            Button(
                onClick = onSelect,
                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary, contentColor = PurpleContainer),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .height(32.dp)
                    .testTag("switch_version_${version.versionNumber}")
            ) {
                Text(text = "Restore", fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

private fun formatDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
    return sdf.format(Date(timestamp))
}

private fun formatSize(bytes: Long): String {
    return when {
        bytes >= 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
        bytes >= 1024 -> "%.1f KB".format(bytes / 1024.0)
        else -> "$bytes B"
    }
}
