package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF1C1B1F)
val SurfaceCard = Color(0xFF2B2930)
val SurfaceCardElevated = Color(0xFF312E37)
val BottomNavBackground = Color(0xFF211F26)
val PurplePrimary = Color(0xFFD0BCFF)
val PurpleContainer = Color(0xFF381E72)
val PurpleLightContainer = Color(0xFFEADDFF)
val TextMain = Color(0xFFE6E1E5)
val TextMuted = Color(0xFF938F99)
val BorderColor = Color(0xFF49454F)
val TealAccent = Color(0xFF52D7BF)
val GreenSync = Color(0xFF4CAF50)
val DrawerBackground = Color(0xFF25232A)
val BottomSheetBackground = Color(0xFF25232A)
