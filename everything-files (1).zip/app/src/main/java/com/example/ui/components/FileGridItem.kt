package com.example.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FileItem
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMain
import com.example.ui.theme.TextMuted

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileGridItem(
    file: FileItem,
    viewMode: ViewMode,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val iconSize = when (viewMode) {
        ViewMode.TINY -> 32.dp
        ViewMode.COMPACT -> 40.dp
        ViewMode.MEDIUM -> 48.dp
        ViewMode.LARGE -> 56.dp
        else -> 48.dp
    }

    val fontSize = when (viewMode) {
        ViewMode.TINY -> 10.sp
        ViewMode.COMPACT -> 11.sp
        else -> 12.sp
    }

    val isFolder = file.extension.isEmpty() || file.extension.lowercase() == "folder"
    val iconColor = if (isFolder) Color(0xFF1976D2) else when (file.extension.lowercase()) {
        "jpg", "jpeg", "png", "gif" -> Color(0xFFFFC107)
        "mp4", "mkv", "avi" -> Color(0xFF00BCD4)
        "mp3", "wav", "flac" -> Color(0xFFAB47BC)
        "apk" -> Color(0xFF66BB6A)
        "pdf", "doc", "docx", "txt" -> Color(0xFFFF7043)
        else -> PurplePrimary
    }

    val iconVector = if (isFolder) Icons.Default.Folder else when (file.extension.lowercase()) {
        "jpg", "jpeg", "png", "gif" -> Icons.Default.Image
        "mp4", "mkv", "avi" -> Icons.Default.Videocam
        "mp3", "wav", "flac" -> Icons.Default.AudioFile
        "apk" -> Icons.Default.Android
        "pdf", "doc", "docx", "txt" -> Icons.Default.Description
        else -> Icons.Default.InsertDriveFile
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(SurfaceCard)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(10.dp)
            .testTag("file_grid_item_${file.id}")
    ) {
        Box(
            modifier = Modifier
                .size(iconSize + 12.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(iconColor.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = iconVector,
                contentDescription = file.canonicalName,
                tint = iconColor,
                modifier = Modifier.size(iconSize)
            )

            if (file.isProtected) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(2.dp)
                        .size(12.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFFFF9800)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Protected",
                        tint = Color.White,
                        modifier = Modifier.size(8.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = file.canonicalName,
            fontSize = fontSize,
            fontWeight = FontWeight.Medium,
            color = TextMain,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}
