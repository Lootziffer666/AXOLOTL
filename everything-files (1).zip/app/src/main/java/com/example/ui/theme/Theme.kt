package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val ElegantDarkColorScheme = darkColorScheme(
    primary = PurplePrimary,
    onPrimary = PurpleContainer,
    primaryContainer = PurpleContainer,
    onPrimaryContainer = PurplePrimary,
    secondary = TealAccent,
    background = DarkBackground,
    onBackground = TextMain,
    surface = SurfaceCard,
    onSurface = TextMain,
    surfaceVariant = SurfaceCardElevated,
    onSurfaceVariant = TextMuted,
    outline = BorderColor
)

@Composable
fun EverythingFilesTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = ElegantDarkColorScheme,
        typography = Typography,
        content = content
    )
}
