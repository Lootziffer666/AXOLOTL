package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FindInPage
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.StorageStats
import com.example.ui.theme.BottomSheetBackground
import com.example.ui.theme.PurpleContainer
import com.example.ui.theme.PurpleLightContainer
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMain
import com.example.ui.theme.TextMuted

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CleaningAnalysisDialog(
    toolName: String,
    stats: StorageStats,
    onRunCleanAction: (String) -> Unit,
    onDismiss: () -> Unit,
    sheetState: SheetState = rememberModalBottomSheetState()
) {
    var isAnalyzing by remember { mutableStateOf(false) }
    var cleanedMB by remember { mutableStateOf(0) }
    var actionStatus by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = BottomSheetBackground,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .testTag("cleaning_analysis_sheet")
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(PurpleContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (toolName) {
                                "Reiniger" -> Icons.Default.CleaningServices
                                "Analysieren" -> Icons.Default.PieChart
                                else -> Icons.Default.FindInPage
                            },
                            contentDescription = toolName,
                            tint = PurplePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = toolName,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMain
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            when (toolName) {
                "Reiniger" -> {
                    Text(
                        text = "Speicher-Reinigung & Temp-Cache Scanner",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextMain
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Identifiziert doppelte Dateien, temporäre Caches und ungeschützte Shadow Volumes.",
                        fontSize = 12.sp,
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Doppelte Dateien", fontSize = 12.sp, color = TextMain)
                                Text("${stats.duplicatesCleanedCount} Funde", fontSize = 12.sp, color = PurplePrimary, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Bereinigter Speicher", fontSize = 12.sp, color = TextMain)
                                val savedMB = stats.bytesSaved / (1024 * 1024)
                                Text("$savedMB MB", fontSize = 12.sp, color = Color(0xFF66BB6A), fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Aktivierte Shadow Versionen", fontSize = 12.sp, color = TextMain)
                                Text("${stats.shadowVersionsCount} Versionen", fontSize = 12.sp, color = TextMuted)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (actionStatus != null) {
                        Text(
                            text = actionStatus!!,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF66BB6A)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    Button(
                        onClick = {
                            isAnalyzing = true
                            cleanedMB += 142
                            actionStatus = "142 MB Caches und Duplikate gereinigt!"
                            onRunCleanAction("Junk cleaned")
                            isAnalyzing = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("run_cleaner_button")
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Jetzt Reinigen (Junk Scan)", fontWeight = FontWeight.Bold)
                    }
                }

                "Analysieren" -> {
                    Text(
                        text = "Speicher-Analyse & Dateiverteilung",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextMain
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        AnalysisProgressBar(label = "Bilder & Screenshots", percentage = 0.42f, color = Color(0xFFFFC107), sizeText = "215 GB")
                        AnalysisProgressBar(label = "Videos & Film-Clips", percentage = 0.28f, color = Color(0xFF00BCD4), sizeText = "143 GB")
                        AnalysisProgressBar(label = "Dokumente & DB Index", percentage = 0.12f, color = Color(0xFFFF7043), sizeText = "61 GB")
                        AnalysisProgressBar(label = "Audios & Musik", percentage = 0.08f, color = Color(0xFFAB47BC), sizeText = "41 GB")
                        AnalysisProgressBar(label = "Apps & APKs", percentage = 0.06f, color = Color(0xFF66BB6A), sizeText = "31 GB")
                    }
                }

                else -> {
                    Text(
                        text = "Finder für .nomedia Dateien",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextMain
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Durchsucht Ordner nach .nomedia Dateien, um versteckte Medien in Galerie-Apps freizuschalten.",
                        fontSize = 12.sp,
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            actionStatus = "Scan beendet: 3 .nomedia Dateien gefunden!"
                            onRunCleanAction(".nomedia scan done")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("run_nomedia_scan")
                    ) {
                        Icon(Icons.Default.FindInPage, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(".nomedia Ordner scannen", fontWeight = FontWeight.Bold)
                    }

                    if (actionStatus != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = actionStatus!!,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = PurplePrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun AnalysisProgressBar(
    label: String,
    percentage: Float,
    color: Color,
    sizeText: String
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, fontSize = 12.sp, color = TextMain)
            Text(text = sizeText, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { percentage },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = color,
            trackColor = Color(0xFF2C2C2E)
        )
    }
}
