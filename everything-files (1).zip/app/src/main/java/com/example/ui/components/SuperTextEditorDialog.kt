package com.example.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FindInPage
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BottomSheetBackground
import com.example.ui.theme.PurpleContainer
import com.example.ui.theme.PurpleLightContainer
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMain
import com.example.ui.theme.TextMuted

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable
fun SuperTextEditorDialog(
    initialText: String = """
        Everything Index Kernel Version 4.2.1
        Date: 2026-08-05
        
        System Log Output:
        - Storage Indexer initialized in 14ms.
        - Indexed 5,120 files across local partitions.
        - Shadow Volumes Active: 12 recovery snapshots present.
        - Fast Search Engine ready for instant queries.
        
        Notes & Annotations:
        - Remember to flush stale cache entries before running cleanups.
        - Super-Texteditor supports live word selection and excerpt extraction.
        - Long press any word to start selection, tap another word to finish excerpt.
    """.trimIndent(),
    onExportText: (String, List<String>) -> Unit,
    onDismiss: () -> Unit,
    sheetState: SheetState = rememberModalBottomSheetState()
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectionModeActive by remember { mutableStateOf(false) }
    var startWordIndex by remember { mutableStateOf<Int?>(null) }
    val excerpts = remember { mutableStateListOf<String>() }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    val words = remember(initialText) {
        initialText.split(Regex("\\s+")).filter { it.isNotBlank() }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = BottomSheetBackground,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .testTag("super_text_editor_sheet")
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(PurpleContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.EditNote,
                            contentDescription = "Editor",
                            tint = PurplePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Super-Texteditor",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextMain
                        )
                        Text(
                            text = "Auszug-Auswahl & Live Search",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                }

                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar inside Editor
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Im Text suchen...", fontSize = 12.sp, color = TextMuted) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = TextMuted) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PurplePrimary,
                    unfocusedBorderColor = Color(0xFF2C2C2E),
                    focusedContainerColor = SurfaceCard,
                    unfocusedContainerColor = SurfaceCard
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Selection Mode Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (selectionModeActive) PurpleLightContainer else Color(0xFF2C2C2E))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Highlight,
                        contentDescription = "Highlight",
                        tint = if (selectionModeActive) PurplePrimary else TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (selectionModeActive) "Auswahlmodus Aktiv (Long Press -> End-Wort)" else "Auswahlmodus Inaktiv",
                        fontSize = 12.sp,
                        fontWeight = if (selectionModeActive) FontWeight.Bold else FontWeight.Medium,
                        color = if (selectionModeActive) TextMain else TextMuted
                    )
                }

                Button(
                    onClick = {
                        selectionModeActive = !selectionModeActive
                        startWordIndex = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectionModeActive) PurplePrimary else Color(0xFF3A3A3C)
                    )
                ) {
                    Text(if (selectionModeActive) "Beenden" else "Auszug-Modus", fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Text interactive flow layout
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(SurfaceCard)
                    .padding(12.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    words.forEachIndexed { index, word ->
                        val isStart = startWordIndex == index
                        val isMatchedSearch = searchQuery.isNotBlank() && word.lowercase().contains(searchQuery.lowercase().trim())

                        val wordBg = when {
                            isStart -> PurplePrimary
                            isMatchedSearch -> Color(0xFFFFC107).copy(alpha = 0.4f)
                            else -> Color.Transparent
                        }

                        val textColor = when {
                            isStart -> Color.White
                            isMatchedSearch -> Color.White
                            else -> TextMain
                        }

                        Text(
                            text = word,
                            fontSize = 13.sp,
                            color = textColor,
                            fontWeight = if (isStart || isMatchedSearch) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(wordBg)
                                .padding(horizontal = 3.dp, vertical = 2.dp)
                                .combinedClickable(
                                    onClick = {
                                        if (selectionModeActive) {
                                            if (startWordIndex == null) {
                                                startWordIndex = index
                                            } else {
                                                val start = minOf(startWordIndex!!, index)
                                                val end = maxOf(startWordIndex!!, index)
                                                val snippet = words.subList(start, end + 1).joinToString(" ")
                                                excerpts.add(snippet)
                                                startWordIndex = null
                                                statusMessage = "Auszug hinzugefügt (${excerpts.size})"
                                            }
                                        }
                                    },
                                    onLongClick = {
                                        if (selectionModeActive) {
                                            startWordIndex = index
                                            statusMessage = "Start-Wort gewählt. Klicke Ziel-Wort."
                                        }
                                    }
                                )
                        )
                    }
                }
            }

            if (statusMessage != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = statusMessage!!, fontSize = 11.sp, color = PurplePrimary)
            }

            // Excerpts List Section
            if (excerpts.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text("Gesammelte Auszüge (${excerpts.size}):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextMain)
                Spacer(modifier = Modifier.height(6.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    excerpts.forEachIndexed { idx, excerpt ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = PurpleLightContainer),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("\"$excerpt\"", fontSize = 11.sp, color = TextMain)
                                Spacer(modifier = Modifier.width(4.dp))
                                IconButton(
                                    onClick = { excerpts.removeAt(idx) },
                                    modifier = Modifier.size(16.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Remove", tint = TextMuted)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action Export Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        onExportText(initialText, excerpts.toList())
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("export_text_button")
                ) {
                    Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Exportieren", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}
