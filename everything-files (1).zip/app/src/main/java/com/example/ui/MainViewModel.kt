package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.borderline.BorderlineSDK
import com.example.engine.FileIndexingEngine
import com.example.model.FileItem
import com.example.model.FileVersion
import com.example.model.StorageStats
import com.example.ui.components.FileCategory
import com.example.ui.components.LanDevice
import com.example.ui.components.SortMode
import com.example.ui.components.ViewMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

enum class MainTab {
    MANAGER, INDEX, SHADOW_VOLUMES, BORDERLINE
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val engine = FileIndexingEngine(application)

    private val _currentTab = MutableStateFlow(MainTab.MANAGER)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow<FileCategory?>(null)
    val selectedCategory: StateFlow<FileCategory?> = _selectedCategory.asStateFlow()

    private val _viewMode = MutableStateFlow(ViewMode.LIST)
    val viewMode: StateFlow<ViewMode> = _viewMode.asStateFlow()

    private val _sortMode = MutableStateFlow(SortMode.NAME)
    val sortMode: StateFlow<SortMode> = _sortMode.asStateFlow()

    private val _showHiddenFiles = MutableStateFlow(false)
    val showHiddenFiles: StateFlow<Boolean> = _showHiddenFiles.asStateFlow()

    private val _applyToAllFolders = MutableStateFlow(true)
    val applyToAllFolders: StateFlow<Boolean> = _applyToAllFolders.asStateFlow()

    private val _rootExplorerActive = MutableStateFlow(false)
    val rootExplorerActive: StateFlow<Boolean> = _rootExplorerActive.asStateFlow()

    private val _isViewSortSheetOpen = MutableStateFlow(false)
    val isViewSortSheetOpen: StateFlow<Boolean> = _isViewSortSheetOpen.asStateFlow()

    private val _activeToolDialog = MutableStateFlow<String?>(null)
    val activeToolDialog: StateFlow<String?> = _activeToolDialog.asStateFlow()

    private val _trashFiles = MutableStateFlow<List<FileItem>>(emptyList())
    val trashFiles: StateFlow<List<FileItem>> = _trashFiles.asStateFlow()

    private val _isTrashBinOpen = MutableStateFlow(false)
    val isTrashBinOpen: StateFlow<Boolean> = _isTrashBinOpen.asStateFlow()

    private val _isTextEditorOpen = MutableStateFlow(false)
    val isTextEditorOpen: StateFlow<Boolean> = _isTextEditorOpen.asStateFlow()

    private val _isVaultDialogOpen = MutableStateFlow(false)
    val isVaultDialogOpen: StateFlow<Boolean> = _isVaultDialogOpen.asStateFlow()

    private val _isVaultUnlocked = MutableStateFlow(false)
    val isVaultUnlocked: StateFlow<Boolean> = _isVaultUnlocked.asStateFlow()

    private val _isAdultMode = MutableStateFlow(false)
    val isAdultMode: StateFlow<Boolean> = _isAdultMode.asStateFlow()

    private var masterPassword = "master123"
    private var recoveryAnswer = "everything"

    private val _vaultFiles = MutableStateFlow<List<FileItem>>(emptyList())
    val vaultFiles: StateFlow<List<FileItem>> = _vaultFiles.asStateFlow()

    private val _isRemoteManagerOpen = MutableStateFlow(false)
    val isRemoteManagerOpen: StateFlow<Boolean> = _isRemoteManagerOpen.asStateFlow()

    private val _isFtpRunning = MutableStateFlow(false)
    val isFtpRunning: StateFlow<Boolean> = _isFtpRunning.asStateFlow()

    private val _ftpAddress = MutableStateFlow("192.168.1.105")
    val ftpAddress: StateFlow<String> = _ftpAddress.asStateFlow()

    private val _ftpPort = MutableStateFlow(2121)
    val ftpPort: StateFlow<Int> = _ftpPort.asStateFlow()

    private val _lanDevices = MutableStateFlow<List<LanDevice>>(emptyList())
    val lanDevices: StateFlow<List<LanDevice>> = _lanDevices.asStateFlow()

    private val _isLanScanning = MutableStateFlow(false)
    val isLanScanning: StateFlow<Boolean> = _isLanScanning.asStateFlow()

    private val _files = MutableStateFlow<List<FileItem>>(emptyList())
    val files: StateFlow<List<FileItem>> = _files.asStateFlow()

    private val _stats = MutableStateFlow(StorageStats())
    val stats: StateFlow<StorageStats> = _stats.asStateFlow()

    private val _selectedFileForVersions = MutableStateFlow<FileItem?>(null)
    val selectedFileForVersions: StateFlow<FileItem?> = _selectedFileForVersions.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    init {
        viewModelScope.launch {
            engine.allFileItems.collectLatest { list ->
                _files.value = filterList(list, _searchQuery.value, _selectedCategory.value)
            }
        }
        viewModelScope.launch {
            engine.storageStats.collectLatest { s ->
                _stats.value = s
            }
        }
        // Run initial scan & deduplication
        triggerScan()
    }

    fun selectTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
        refreshFileList()
    }

    fun selectCategory(category: FileCategory?) {
        _selectedCategory.value = category
        refreshFileList()
    }

    fun setViewMode(mode: ViewMode) {
        _viewMode.value = mode
    }

    fun setSortMode(mode: SortMode) {
        _sortMode.value = mode
        refreshFileList()
    }

    fun setShowHiddenFiles(show: Boolean) {
        _showHiddenFiles.value = show
        refreshFileList()
    }

    fun setApplyToAllFolders(apply: Boolean) {
        _applyToAllFolders.value = apply
    }

    fun setRootExplorerActive(active: Boolean) {
        _rootExplorerActive.value = active
        _userMessage.value = if (active) "Root-Explorer mode enabled!" else "Root-Explorer mode disabled."
    }

    fun openViewSortSheet() {
        _isViewSortSheetOpen.value = true
    }

    fun closeViewSortSheet() {
        _isViewSortSheetOpen.value = false
    }

    fun openToolDialog(toolName: String) {
        when (toolName) {
            "Papierkorb" -> {
                // Initialize default sample trash items if empty
                if (_trashFiles.value.isEmpty()) {
                    val now = System.currentTimeMillis()
                    _trashFiles.value = listOf(
                        FileItem("t1", "temp_cache_v1.tmp", "/storage/emulated/0/Android/data/cache", "tmp", 482000L, "hash1", now - 86400000L, now - 86400000L, contentSnippet = "Cache backup"),
                        FileItem("t2", "old_document_draft.docx", "/storage/emulated/0/Documents", "docx", 1250000L, "hash2", now - 172800000L, now - 172800000L, contentSnippet = "Draft doc"),
                        FileItem("t3", "unused_screenshot.png", "/storage/emulated/0/DCIM/Screenshots", "png", 2300000L, "hash3", now - 259200000L, now - 259200000L, contentSnippet = "Screenshot")
                    )
                }
                _isTrashBinOpen.value = true
            }
            "Super-Texteditor" -> {
                _isTextEditorOpen.value = true
            }
            "Secure Vault", "Vault" -> {
                openVaultDialog()
            }
            "Remote / LAN", "FTP Server", "Remote- & Netzwerk-Manager" -> {
                openRemoteManager()
            }
            else -> {
                _activeToolDialog.value = toolName
            }
        }
    }

    fun openVaultDialog() {
        if (_vaultFiles.value.isEmpty()) {
            val now = System.currentTimeMillis()
            _vaultFiles.value = listOf(
                FileItem("v1", "private_photo.jpg", "/storage/emulated/0/Vault", "jpg", 1850000L, "vhash1", now - 432000000L, now - 432000000L, isProtected = true),
                FileItem("v2", "confidential_video.mp4", "/storage/emulated/0/Vault", "mp4", 14500000L, "vhash2", now - 864000000L, now - 864000000L, isProtected = true)
            )
        }
        _isVaultDialogOpen.value = true
    }

    fun closeVaultDialog() {
        _isVaultDialogOpen.value = false
    }

    fun authenticateVault(password: String): Boolean {
        return if (password == masterPassword) {
            _isVaultUnlocked.value = true
            _userMessage.value = "Vault freigeschaltet!"
            true
        } else {
            false
        }
    }

    fun recoverVaultPassword(answer: String): String? {
        return if (answer.lowercase().trim() == recoveryAnswer) {
            masterPassword
        } else {
            null
        }
    }

    fun toggleAdultMode() {
        _isAdultMode.value = !_isAdultMode.value
        _userMessage.value = if (_isAdultMode.value) "Adult Mode aktiviert (Tresor im Hintergrund entsperrt)" else "Adult Mode deaktiviert"
    }

    fun importFileToVault() {
        val now = System.currentTimeMillis()
        val newItem = FileItem(
            id = "v_${System.currentTimeMillis()}",
            canonicalName = "imported_media_${_vaultFiles.value.size + 1}.jpg",
            currentPath = "/storage/emulated/0/Vault",
            extension = "jpg",
            sizeBytes = 2450000L,
            contentHash = "hash_${System.currentTimeMillis()}",
            lastModified = now,
            creationTime = now,
            isProtected = true
        )
        _vaultFiles.value = _vaultFiles.value + newItem
        _userMessage.value = "Datei erfolgreich in den Vault verschoben & verschlüsselt!"
    }

    fun removeFileFromVault(file: FileItem) {
        _vaultFiles.value = _vaultFiles.value.filter { it.id != file.id }
        _userMessage.value = "${file.canonicalName} aus dem Vault entschlüsselt & exportiert."
    }

    fun openRemoteManager() {
        if (_lanDevices.value.isEmpty()) {
            _lanDevices.value = listOf(
                LanDevice("l1", "FRITZ!Box 7590 NAS", "192.168.1.1", "Router", 3),
                LanDevice("l2", "Wohnzimmer Workstation", "192.168.1.12", "PC", 5),
                LanDevice("l3", "Synology DS920+", "192.168.1.50", "NAS", 12)
            )
        }
        _isRemoteManagerOpen.value = true
    }

    fun closeRemoteManager() {
        _isRemoteManagerOpen.value = false
    }

    fun toggleFtpServer() {
        _isFtpRunning.value = !_isFtpRunning.value
        _userMessage.value = if (_isFtpRunning.value) "FTP-Server gestartet auf Port ${_ftpPort.value}" else "FTP-Server gestoppt."
    }

    fun scanLanNetwork() {
        viewModelScope.launch {
            _isLanScanning.value = true
            kotlinx.coroutines.delay(1200)
            _lanDevices.value = listOf(
                LanDevice("l1", "FRITZ!Box 7590 NAS", "192.168.1.1", "Router", 3),
                LanDevice("l2", "Wohnzimmer Workstation", "192.168.1.12", "PC", 5),
                LanDevice("l3", "Synology DS920+", "192.168.1.50", "NAS", 12),
                LanDevice("l4", "Media-Server SMB", "192.168.1.88", "NAS", 8)
            )
            _isLanScanning.value = false
            _userMessage.value = "LAN-Scan abgeschlossen. 4 Geräte gefunden."
        }
    }

    fun connectToLanDevice(device: LanDevice) {
        val updated = _lanDevices.value.map {
            if (it.id == device.id) it.copy(isConnected = !it.isConnected) else it
        }
        _lanDevices.value = updated
        val nowConnected = updated.find { it.id == device.id }?.isConnected == true
        _userMessage.value = if (nowConnected) "Mit ${device.name} (SMB) verbunden!" else "Verbindung zu ${device.name} getrennt."
    }

    fun closeToolDialog() {
        _activeToolDialog.value = null
    }

    fun closeTrashBin() {
        _isTrashBinOpen.value = false
    }

    fun closeTextEditor() {
        _isTextEditorOpen.value = false
    }

    fun restoreTrashFile(file: FileItem) {
        _trashFiles.value = _trashFiles.value.filter { it.id != file.id }
        _userMessage.value = "${file.canonicalName} wiederhergestellt!"
    }

    fun deleteTrashFilePermanently(file: FileItem) {
        _trashFiles.value = _trashFiles.value.filter { it.id != file.id }
        _userMessage.value = "${file.canonicalName} dauerhaft gelöscht."
    }

    fun emptyTrash() {
        _trashFiles.value = emptyList()
        _userMessage.value = "Papierkorb geleert!"
    }

    fun exportTextAndExcerpts(fullText: String, excerpts: List<String>) {
        _userMessage.value = "Text & ${excerpts.size} Auszüge erfolgreich exportiert!"
    }

    private fun refreshFileList() {
        viewModelScope.launch {
            engine.allFileItems.collectLatest { list ->
                _files.value = filterList(list, _searchQuery.value, _selectedCategory.value)
            }
        }
    }

    fun triggerScan() {
        viewModelScope.launch {
            _isScanning.value = true
            try {
                engine.runFullScanAndCleanup()
                _userMessage.value = "Scan & deduplication complete!"
            } catch (e: Exception) {
                _userMessage.value = "Scan error: ${e.message}"
            } finally {
                _isScanning.value = false
            }
        }
    }

    fun openFileVersionsSheet(file: FileItem) {
        _selectedFileForVersions.value = file
    }

    fun closeFileVersionsSheet() {
        _selectedFileForVersions.value = null
    }

    fun toggleFileProtection(fileId: String, currentProtection: Boolean) {
        viewModelScope.launch {
            engine.toggleFileProtection(fileId, !currentProtection)
            _selectedFileForVersions.value = _selectedFileForVersions.value?.copy(isProtected = !currentProtection)
            _userMessage.value = if (!currentProtection) "Version protected from deletion!" else "Protection removed."
        }
    }

    fun toggleVersionProtection(versionId: String, currentProtection: Boolean) {
        viewModelScope.launch {
            engine.toggleVersionProtection(versionId, !currentProtection)
            val curr = _selectedFileForVersions.value
            if (curr != null) {
                val updatedVersions = curr.versions.map { v ->
                    if (v.versionId == versionId) v.copy(isProtected = !currentProtection) else v
                }
                _selectedFileForVersions.value = curr.copy(versions = updatedVersions)
            }
        }
    }

    fun switchActiveVersion(fileId: String, versionNumber: Int) {
        viewModelScope.launch {
            engine.setActiveVersion(fileId, versionNumber)
            _userMessage.value = "Switched to Version v$versionNumber!"
            closeFileVersionsSheet()
        }
    }

    fun sendToBorderlineSnippet(file: FileItem) {
        val context = getApplication<Application>().applicationContext
        val title = file.canonicalName
        val content = "Path: ${file.currentPath}\nHash: ${file.contentHash}\nSnippet: ${file.contentSnippet}"
        BorderlineSDK.addSnippet(context, title, content, "Everything File")
        _userMessage.value = "Sent '$title' as Borderline Snippet!"
    }

    fun sendToBorderlineAppendix(file: FileItem) {
        val context = getApplication<Application>().applicationContext
        val text = "File: ${file.canonicalName} (Size: ${formatFileSize(file.sizeBytes)}, Path: ${file.currentPath})"
        BorderlineSDK.appendToAppendix(context, text)
        _userMessage.value = "Appended '${file.canonicalName}' to Borderline Appendix!"
    }

    fun openBorderlineMenu(menuIndex: Int) {
        val context = getApplication<Application>().applicationContext
        BorderlineSDK.openMenu(context, menuIndex)
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    private fun filterList(list: List<FileItem>, query: String, category: FileCategory?): List<FileItem> {
        var result = list

        if (!_showHiddenFiles.value) {
            result = result.filter { !it.canonicalName.startsWith(".") }
        }

        if (category != null) {
            result = result.filter { item ->
                category.extensions.contains(item.extension.lowercase())
            }
        }

        if (query.isNotBlank()) {
            val q = query.lowercase().trim()
            result = result.filter {
                it.canonicalName.lowercase().contains(q) ||
                it.extension.lowercase().contains(q) ||
                it.contentSnippet.lowercase().contains(q)
            }
        }

        result = when (_sortMode.value) {
            SortMode.NAME -> result.sortedBy { it.canonicalName.lowercase() }
            SortMode.TYPE -> result.sortedBy { it.extension.lowercase() }
            SortMode.SIZE -> result.sortedByDescending { it.sizeBytes }
            SortMode.DATE -> result.sortedByDescending { it.lastModified }
        }

        return result
    }

    private fun formatFileSize(bytes: Long): String {
        return when {
            bytes >= 1024 * 1024 * 1024 -> "%.1f GB".format(bytes / (1024.0 * 1024.0 * 1024.0))
            bytes >= 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
            bytes >= 1024 -> "%.1f KB".format(bytes / 1024.0)
            else -> "$bytes B"
        }
    }
}
