package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MergeType
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.StorageStats
import com.example.ui.theme.BorderColor
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.PurpleContainer
import com.example.ui.theme.PurpleLightContainer
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.SurfaceCardElevated
import com.example.ui.theme.TextMain
import com.example.ui.theme.TextMuted

@Composable
fun AutomationCard(
    stats: StorageStats,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(SurfaceCardElevated)
            .border(1.dp, BorderColor, RoundedCornerShape(24.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "AUTOMATION: DOWNLOADS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = PurplePrimary,
                letterSpacing = 1.2.sp
            )
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = "Automation icon",
                tint = PurplePrimary,
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Card 1: Shadow Versions
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(DarkBackground)
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "${stats.shadowVersionsCount}",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Light,
                        color = TextMain
                    )
                    Text(
                        text = "Shadow Versions",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }

            // Card 2: Dupes Cleaned & Saved Space
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(DarkBackground)
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = formatBytes(stats.bytesSaved),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Light,
                        color = TextMain
                    )
                    Text(
                        text = "${stats.duplicatesCleanedCount} Dupes Cleaned",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Banner: Folder Consolidation & Retention status
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(PurpleLightContainer.copy(alpha = 0.08f))
                .border(1.dp, PurpleLightContainer.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(PurplePrimary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.MergeType,
                    contentDescription = "Merge icon",
                    tint = PurpleContainer,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Consolidation & Retention Active",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextMain
                )
                Text(
                    text = "+10d auto-purge • max 10 versions (<5MB) • duplicates removed",
                    fontSize = 10.sp,
                    color = TextMuted
                )
            }
        }
    }
}

private fun formatBytes(bytes: Long): String {
    return when {
        bytes >= 1024 * 1024 * 1024 -> "%.1f GB".format(bytes / (1024.0 * 1024.0 * 1024.0))
        bytes >= 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
        bytes >= 1024 -> "%.1f KB".format(bytes / 1024.0)
        else -> "$bytes B"
    }
}
