package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.StorageStats
import com.example.ui.theme.PurpleContainer
import com.example.ui.theme.PurpleLightContainer
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMain
import com.example.ui.theme.TextMuted

enum class FileCategory(
    val label: String,
    val icon: ImageVector,
    val color: Color,
    val extensions: Set<String>
) {
    IMAGES("Bilder", Icons.Default.Image, Color(0xFFFFC107), setOf("jpg", "jpeg", "png", "gif", "webp", "svg", "bmp")),
    VIDEOS("Videos", Icons.Default.Videocam, Color(0xFF00BCD4), setOf("mp4", "mkv", "avi", "mov", "webm", "3gp")),
    AUDIOS("Audios", Icons.Default.AudioFile, Color(0xFFAB47BC), setOf("mp3", "wav", "flac", "m4a", "ogg", "aac")),
    APPS("Apps", Icons.Default.Android, Color(0xFF66BB6A), setOf("apk", "aab", "xapk")),
    DOCUMENTS("Dokumente", Icons.Default.Description, Color(0xFFFF7043), setOf("pdf", "doc", "docx", "txt", "md", "xls", "xlsx", "ppt", "json", "xml")),
    COMPRESSED("Komprimiert", Icons.Default.Archive, Color(0xFF42A5F5), setOf("zip", "rar", "7z", "tar", "gz", "bz2"))
}

@Composable
fun CategoryStorageSection(
    stats: StorageStats,
    selectedCategory: FileCategory?,
    onSelectCategory: (FileCategory?) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 6 Category Grid
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(SurfaceCard)
                .padding(12.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Kategorien",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted
                    )
                    if (selectedCategory != null) {
                        Text(
                            text = "Filter zurücksetzen",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = PurplePrimary,
                            modifier = Modifier
                                .clickable { onSelectCategory(null) }
                                .testTag("reset_category_filter")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                val categories = FileCategory.values()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    categories.take(3).forEach { category ->
                        CategoryItem(
                            category = category,
                            isSelected = selectedCategory == category,
                            onClick = {
                                if (selectedCategory == category) onSelectCategory(null)
                                else onSelectCategory(category)
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    categories.drop(3).forEach { category ->
                        CategoryItem(
                            category = category,
                            isSelected = selectedCategory == category,
                            onClick = {
                                if (selectedCategory == category) onSelectCategory(null)
                                else onSelectCategory(category)
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Storage Usage Card (Inspired by MiXplorer / Device Storage Meter)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(SurfaceCard)
                .padding(14.dp)
                .testTag("storage_meter_card")
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(PurpleContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Smartphone,
                            contentDescription = "Speicher",
                            tint = PurplePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Interner Speicher",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextMain
                        )
                        val totalGB = 512.0
                        val usedGB = (stats.totalIndexedSizeBytes / (1024.0 * 1024.0 * 1024.0)).coerceAtLeast(12.4)
                        Text(
                            text = "%.2f GB / %.2f GB".format(usedGB, totalGB),
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(PurpleLightContainer)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PieChart,
                            contentDescription = "Chart",
                            tint = PurplePrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        val percent = ((stats.totalIndexedSizeBytes / (512.0 * 1024 * 1024 * 1024)) * 100).toInt().coerceIn(15, 84)
                        Text(
                            text = "$percent%",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextMain
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Progress bar
                val progress = ((stats.totalIndexedSizeBytes.toDouble() / (512.0 * 1024 * 1024 * 1024))).toFloat().coerceIn(0.15f, 0.84f)
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = Color(0xFF4CAF50),
                    trackColor = Color(0xFF2C2C2E)
                )
            }
        }
    }
}

@Composable
private fun CategoryItem(
    category: FileCategory,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .border(
                width = if (isSelected) 1.5.dp else 0.dp,
                color = if (isSelected) PurplePrimary else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .padding(vertical = 8.dp, horizontal = 4.dp)
            .testTag("category_${category.name.lowercase()}")
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(category.color.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = category.icon,
                contentDescription = category.label,
                tint = category.color,
                modifier = Modifier.size(22.dp)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = category.label,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) PurplePrimary else TextMain,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}
