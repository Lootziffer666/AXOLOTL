package com.example.ui

import com.example.model.FileItem
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Dataset
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.IntegrationInstructions
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AutomationCard
import com.example.ui.components.BorderlineSection
import com.example.ui.components.EverythingSearchBar
import com.example.ui.components.FileListItem
import com.example.ui.components.FileVersionsBottomSheet
import com.example.ui.theme.BottomNavBackground
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.PurpleContainer
import com.example.ui.theme.PurpleLightContainer
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMain
import com.example.ui.theme.TextMuted

import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import com.example.ui.components.CategoryStorageSection
import com.example.ui.components.FileCategory
import com.example.ui.components.FileGridItem
import com.example.ui.components.ViewMode

import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.rememberCoroutineScope
import com.example.ui.components.AppNavigationDrawerContent
import com.example.ui.components.CleaningAnalysisDialog
import com.example.ui.components.RemoteNetworkManagerDialog
import com.example.ui.components.SecureVaultDialog
import com.example.ui.components.SuperTextEditorDialog
import com.example.ui.components.TrashBinDialog
import com.example.ui.components.ViewSortBottomSheet
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val viewMode by viewModel.viewMode.collectAsState()
    val sortMode by viewModel.sortMode.collectAsState()
    val showHiddenFiles by viewModel.showHiddenFiles.collectAsState()
    val applyToAllFolders by viewModel.applyToAllFolders.collectAsState()
    val rootExplorerActive by viewModel.rootExplorerActive.collectAsState()
    val isViewSortSheetOpen by viewModel.isViewSortSheetOpen.collectAsState()
    val activeToolDialog by viewModel.activeToolDialog.collectAsState()
    val trashFiles by viewModel.trashFiles.collectAsState()
    val isTrashBinOpen by viewModel.isTrashBinOpen.collectAsState()
    val isTextEditorOpen by viewModel.isTextEditorOpen.collectAsState()
    val isVaultDialogOpen by viewModel.isVaultDialogOpen.collectAsState()
    val isVaultUnlocked by viewModel.isVaultUnlocked.collectAsState()
    val isAdultMode by viewModel.isAdultMode.collectAsState()
    val vaultFiles by viewModel.vaultFiles.collectAsState()
    val isRemoteManagerOpen by viewModel.isRemoteManagerOpen.collectAsState()
    val isFtpRunning by viewModel.isFtpRunning.collectAsState()
    val ftpAddress by viewModel.ftpAddress.collectAsState()
    val ftpPort by viewModel.ftpPort.collectAsState()
    val lanDevices by viewModel.lanDevices.collectAsState()
    val isLanScanning by viewModel.isLanScanning.collectAsState()
    val files by viewModel.files.collectAsState()
    val stats by viewModel.stats.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val selectedFileForVersions by viewModel.selectedFileForVersions.collectAsState()
    val userMessage by viewModel.userMessage.collectAsState()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(userMessage) {
        userMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearUserMessage()
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            AppNavigationDrawerContent(
                selectedCategory = selectedCategory,
                showHiddenFiles = showHiddenFiles,
                rootExplorerActive = rootExplorerActive,
                onSelectCategory = { cat ->
                    viewModel.selectCategory(cat)
                    coroutineScope.launch { drawerState.close() }
                },
                onToggleShowHidden = { viewModel.setShowHiddenFiles(it) },
                onToggleRootExplorer = { viewModel.setRootExplorerActive(it) },
                onOpenTool = { tool ->
                    viewModel.openToolDialog(tool)
                    coroutineScope.launch { drawerState.close() }
                }
            )
        }
    ) {
        Scaffold(
            modifier = modifier.fillMaxSize(),
            containerColor = DarkBackground,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                NavigationBar(
                    containerColor = BottomNavBackground,
                    tonalElevation = 8.dp,
                    modifier = Modifier.height(72.dp)
                ) {
                    NavigationBarItem(
                        selected = currentTab == MainTab.MANAGER,
                        onClick = { viewModel.selectTab(MainTab.MANAGER) },
                        icon = { Icon(Icons.Default.GridView, contentDescription = "Manager") },
                        label = { Text("Manager", fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DarkBackground,
                            selectedTextColor = TextMain,
                            indicatorColor = PurpleLightContainer,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        ),
                        modifier = Modifier.testTag("nav_tab_manager")
                    )

                    NavigationBarItem(
                        selected = currentTab == MainTab.INDEX,
                        onClick = { viewModel.selectTab(MainTab.INDEX) },
                        icon = { Icon(Icons.Default.Dataset, contentDescription = "Index") },
                        label = { Text("Index", fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DarkBackground,
                            selectedTextColor = TextMain,
                            indicatorColor = PurpleLightContainer,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        ),
                        modifier = Modifier.testTag("nav_tab_index")
                    )

                    NavigationBarItem(
                        selected = currentTab == MainTab.SHADOW_VOLUMES,
                        onClick = { viewModel.selectTab(MainTab.SHADOW_VOLUMES) },
                        icon = { Icon(Icons.Default.CleaningServices, contentDescription = "Shadow") },
                        label = { Text("Shadow", fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DarkBackground,
                            selectedTextColor = TextMain,
                            indicatorColor = PurpleLightContainer,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        ),
                        modifier = Modifier.testTag("nav_tab_shadow")
                    )

                    NavigationBarItem(
                        selected = currentTab == MainTab.BORDERLINE,
                        onClick = { viewModel.selectTab(MainTab.BORDERLINE) },
                        icon = { Icon(Icons.Default.IntegrationInstructions, contentDescription = "Borderline") },
                        label = { Text("Borderline", fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DarkBackground,
                            selectedTextColor = TextMain,
                            indicatorColor = PurpleLightContainer,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        ),
                        modifier = Modifier.testTag("nav_tab_borderline")
                    )
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Header Search Bar with Drawer and View/Sort Actions
                EverythingSearchBar(
                    query = searchQuery,
                    onQueryChange = { viewModel.updateSearchQuery(it) },
                    totalFilesIndexed = stats.totalIndexedFiles,
                    isScanning = isScanning,
                    onTriggerScan = { viewModel.triggerScan() },
                    onOpenDrawer = { coroutineScope.launch { drawerState.open() } },
                    onOpenViewSort = { viewModel.openViewSortSheet() }
                )

            Spacer(modifier = Modifier.height(16.dp))

            when (currentTab) {
                MainTab.MANAGER -> {
                    CategoryStorageSection(
                        stats = stats,
                        selectedCategory = selectedCategory,
                        onSelectCategory = { cat -> viewModel.selectCategory(cat) }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    AutomationCard(stats = stats)
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (selectedCategory != null) "${selectedCategory?.label} (${files.size})" else "Managed Files (${files.size})",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextMain
                        )
                        Text(
                            text = "Long press for Shadow Versions",
                            fontSize = 11.sp,
                            color = PurplePrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    FileListOrGrid(
                        files = files,
                        viewMode = viewMode,
                        onClick = { file -> viewModel.openFileVersionsSheet(file) },
                        onLongClick = { file -> viewModel.openFileVersionsSheet(file) }
                    )
                }

                MainTab.INDEX -> {
                    Text(
                        text = "FULL-CONTENT SEARCH INDEX",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = PurplePrimary,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    FileListOrGrid(
                        files = files,
                        viewMode = viewMode,
                        onClick = { file -> viewModel.openFileVersionsSheet(file) },
                        onLongClick = { file -> viewModel.openFileVersionsSheet(file) }
                    )
                }

                MainTab.SHADOW_VOLUMES -> {
                    AutomationCard(stats = stats)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "VERSION HISTORY & DEDUPLICATION",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = PurplePrimary,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    FileListOrGrid(
                        files = files,
                        viewMode = viewMode,
                        onClick = { file -> viewModel.openFileVersionsSheet(file) },
                        onLongClick = { file -> viewModel.openFileVersionsSheet(file) }
                    )
                }

                MainTab.BORDERLINE -> {
                    BorderlineSection(
                        onOpenMenu = { index -> viewModel.openBorderlineMenu(index) },
                        onAddCustomSnippet = { title, content -> viewModel.sendToBorderlineSnippet(FileItem(id="temp", canonicalName=title, currentPath="", extension="", sizeBytes=0, contentHash="", lastModified=System.currentTimeMillis(), creationTime=System.currentTimeMillis(), contentSnippet=content)) },
                        onAppendAppendix = { text -> viewModel.sendToBorderlineAppendix(FileItem(id="temp", canonicalName=text, currentPath="", extension="", sizeBytes=0, contentHash="", lastModified=System.currentTimeMillis(), creationTime=System.currentTimeMillis())) }
                    )
                }
            }
        }
    }

        // Long-Press Shadow Volume Bottom Sheet
        selectedFileForVersions?.let { file ->
            FileVersionsBottomSheet(
                file = file,
                onDismiss = { viewModel.closeFileVersionsSheet() },
                onToggleProtection = { fileId, curr -> viewModel.toggleFileProtection(fileId, curr) },
                onToggleVersionProtection = { versionId, curr -> viewModel.toggleVersionProtection(versionId, curr) },
                onSwitchVersion = { fileId, verNum -> viewModel.switchActiveVersion(fileId, verNum) },
                onSendToBorderlineSnippet = { f -> viewModel.sendToBorderlineSnippet(f) },
                onSendToBorderlineAppendix = { f -> viewModel.sendToBorderlineAppendix(f) }
            )
        }

        // View & Sort Bottom Sheet
        if (isViewSortSheetOpen) {
            ViewSortBottomSheet(
                currentViewMode = viewMode,
                currentSortMode = sortMode,
                showHiddenFiles = showHiddenFiles,
                applyToAllFolders = applyToAllFolders,
                onViewModeSelected = { viewModel.setViewMode(it) },
                onSortModeSelected = { viewModel.setSortMode(it) },
                onToggleShowHiddenFiles = { viewModel.setShowHiddenFiles(it) },
                onToggleApplyToAll = { viewModel.setApplyToAllFolders(it) },
                onDismiss = { viewModel.closeViewSortSheet() }
            )
        }

        // Cleaning & Analysis Sheet
        activeToolDialog?.let { toolName ->
            CleaningAnalysisDialog(
                toolName = toolName,
                stats = stats,
                onRunCleanAction = { viewModel.triggerScan() },
                onDismiss = { viewModel.closeToolDialog() }
            )
        }

        // Trash Bin Sheet
        if (isTrashBinOpen) {
            TrashBinDialog(
                initialTrashFiles = trashFiles,
                onRestoreFile = { file -> viewModel.restoreTrashFile(file) },
                onDeletePermanently = { file -> viewModel.deleteTrashFilePermanently(file) },
                onEmptyTrash = { viewModel.emptyTrash() },
                onDismiss = { viewModel.closeTrashBin() }
            )
        }

        // Super Text Editor Sheet
        if (isTextEditorOpen) {
            SuperTextEditorDialog(
                onExportText = { fullText, excerpts ->
                    viewModel.exportTextAndExcerpts(fullText, excerpts)
                },
                onDismiss = { viewModel.closeTextEditor() }
            )
        }

        // Secure Vault Sheet
        if (isVaultDialogOpen) {
            SecureVaultDialog(
                isUnlocked = isVaultUnlocked,
                isAdultMode = isAdultMode,
                vaultFiles = vaultFiles,
                onAuthenticate = { password -> viewModel.authenticateVault(password) },
                onRecoverPassword = { answer -> viewModel.recoverVaultPassword(answer) },
                onImportFile = { viewModel.importFileToVault() },
                onRemoveFromVault = { file -> viewModel.removeFileFromVault(file) },
                onToggleAdultMode = { viewModel.toggleAdultMode() },
                onDismiss = { viewModel.closeVaultDialog() }
            )
        }

        // Remote & Network Manager Sheet
        if (isRemoteManagerOpen) {
            RemoteNetworkManagerDialog(
                isFtpRunning = isFtpRunning,
                ftpAddress = ftpAddress,
                ftpPort = ftpPort,
                lanDevices = lanDevices,
                isLanScanning = isLanScanning,
                onToggleFtpServer = { viewModel.toggleFtpServer() },
                onScanLanNetwork = { viewModel.scanLanNetwork() },
                onConnectToDevice = { device -> viewModel.connectToLanDevice(device) },
                onDismiss = { viewModel.closeRemoteManager() }
            )
        }
    }
}

@Composable
private fun FileListOrGrid(
    files: List<FileItem>,
    viewMode: ViewMode,
    onClick: (FileItem) -> Unit,
    onLongClick: (FileItem) -> Unit
) {
    if (viewMode == ViewMode.LIST) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(files, key = { it.id }) { file ->
                FileListItem(
                    file = file,
                    onClick = { onClick(file) },
                    onLongClick = { onLongClick(file) }
                )
            }
        }
    } else {
        val columnCount = when (viewMode) {
            ViewMode.LARGE -> 2
            ViewMode.MEDIUM, ViewMode.RASTER -> 3
            ViewMode.COMPACT, ViewMode.TINY -> 4
            else -> 3
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(columnCount),
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(files, key = { it.id }) { file ->
                FileGridItem(
                    file = file,
                    viewMode = viewMode,
                    onClick = { onClick(file) },
                    onLongClick = { onLongClick(file) }
                )
            }
        }
    }
}
