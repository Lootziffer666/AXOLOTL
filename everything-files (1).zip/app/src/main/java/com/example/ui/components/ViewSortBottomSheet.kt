package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.SortByAlpha
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.filled.ViewComfy
import androidx.compose.material.icons.filled.ViewCompact
import androidx.compose.material.icons.filled.ViewModule
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BottomSheetBackground
import com.example.ui.theme.PurpleContainer
import com.example.ui.theme.PurpleLightContainer
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.TextMain
import com.example.ui.theme.TextMuted

enum class ViewMode(val label: String, val icon: ImageVector) {
    RASTER("Raster", Icons.Default.GridView),
    COMPACT("Kompakt", Icons.Default.ViewCompact),
    LIST("Liste", Icons.Default.FormatListBulleted),
    LARGE("Größer", Icons.Default.ViewComfy),
    MEDIUM("Mittel", Icons.Default.ViewModule),
    TINY("Sehr klein", Icons.Default.GridOn)
}

enum class SortMode(val label: String, val icon: ImageVector) {
    NAME("Name", Icons.Default.SortByAlpha),
    TYPE("Typ", Icons.Default.InsertDriveFile),
    SIZE("Größe", Icons.Default.Storage),
    DATE("Datum", Icons.Default.CalendarToday)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ViewSortBottomSheet(
    currentViewMode: ViewMode,
    currentSortMode: SortMode,
    showHiddenFiles: Boolean,
    applyToAllFolders: Boolean,
    onViewModeSelected: (ViewMode) -> Unit,
    onSortModeSelected: (SortMode) -> Unit,
    onToggleShowHiddenFiles: (Boolean) -> Unit,
    onToggleApplyToAll: (Boolean) -> Unit,
    onDismiss: () -> Unit,
    sheetState: SheetState = rememberModalBottomSheetState()
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = BottomSheetBackground,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .testTag("view_sort_bottom_sheet")
        ) {
            // Ansicht Section
            Text(
                text = "Ansicht",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextMain
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 2 rows of ViewModes (3 in row 1, 3 in row 2)
            val viewModes = ViewMode.values()
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                viewModes.take(3).forEach { mode ->
                    ViewModeButton(
                        mode = mode,
                        isSelected = currentViewMode == mode,
                        onClick = { onViewModeSelected(mode) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                viewModes.drop(3).forEach { mode ->
                    ViewModeButton(
                        mode = mode,
                        isSelected = currentViewMode == mode,
                        onClick = { onViewModeSelected(mode) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Sortieren Section
            Text(
                text = "Sortieren",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextMain
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                SortMode.values().forEach { mode ->
                    SortModeButton(
                        mode = mode,
                        isSelected = currentSortMode == mode,
                        onClick = { onSortModeSelected(mode) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Toggles
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleApplyToAll(!applyToAllFolders) }
            ) {
                Checkbox(
                    checked = applyToAllFolders,
                    onCheckedChange = { onToggleApplyToAll(it) },
                    colors = CheckboxDefaults.colors(
                        checkedColor = PurplePrimary,
                        uncheckedColor = TextMuted
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Auf alle Ordner anwenden",
                    fontSize = 13.sp,
                    color = TextMain
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleShowHiddenFiles(!showHiddenFiles) }
            ) {
                Checkbox(
                    checked = showHiddenFiles,
                    onCheckedChange = { onToggleShowHiddenFiles(it) },
                    colors = CheckboxDefaults.colors(
                        checkedColor = PurplePrimary,
                        uncheckedColor = TextMuted
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Versteckte Dateien anzeigen",
                    fontSize = 13.sp,
                    color = TextMain
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun ViewModeButton(
    mode: ViewMode,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(8.dp)
            .testTag("view_mode_${mode.name.lowercase()}")
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(if (isSelected) PurpleLightContainer else Color(0xFF2C2C2E)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = mode.icon,
                contentDescription = mode.label,
                tint = if (isSelected) PurplePrimary else TextMuted,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = mode.label,
            fontSize = 11.sp,
            color = if (isSelected) PurplePrimary else TextMuted,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun SortModeButton(
    mode: SortMode,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(8.dp)
            .testTag("sort_mode_${mode.name.lowercase()}")
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(if (isSelected) PurplePrimary else Color(0xFF2C2C2E)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = mode.icon,
                contentDescription = mode.label,
                tint = if (isSelected) Color.White else TextMuted,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = mode.label,
            fontSize = 11.sp,
            color = if (isSelected) PurplePrimary else TextMuted,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
