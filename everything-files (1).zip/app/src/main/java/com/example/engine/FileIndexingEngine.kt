package com.example.engine

import android.content.Context
import com.example.data.AppDatabase
import com.example.data.AppStatsEntity
import com.example.data.FileVersionEntity
import com.example.data.IndexedFileEntity
import com.example.model.FileItem
import com.example.model.FileVersion
import com.example.model.StorageStats
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.security.MessageDigest
import java.util.UUID
import java.util.regex.Pattern

class FileIndexingEngine(private val context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val dao = db.fileDao()

    companion object {
        const val MAX_FILE_SIZE_FOR_VERSIONING = 5 * 1024 * 1024L // 5 MB
        const val MAX_VERSIONS_PER_FILE = 10
        const val RETENTION_PERIOD_MS = 10L * 24 * 60 * 60 * 1000L // 10 Days
    }

    val allFileItems: Flow<List<FileItem>> = combine(
        dao.getAllFiles(),
        dao.getStats()
    ) { entities, stats ->
        entities.map { entity ->
            val versions = dao.getVersionsForFileSync(entity.id).map { v ->
                FileVersion(
                    versionId = v.versionId,
                    fileId = v.fileId,
                    versionNumber = v.versionNumber,
                    filePath = v.filePath,
                    sizeBytes = v.sizeBytes,
                    contentHash = v.contentHash,
                    timestamp = v.timestamp,
                    isProtected = v.isProtected,
                    note = v.note
                )
            }
            FileItem(
                id = entity.id,
                canonicalName = entity.canonicalName,
                currentPath = entity.currentPath,
                extension = entity.extension,
                sizeBytes = entity.sizeBytes,
                contentHash = entity.contentHash,
                lastModified = entity.lastModified,
                creationTime = entity.creationTime,
                isProtected = entity.isProtected,
                contentSnippet = entity.contentSnippet,
                versions = versions,
                activeVersionNumber = entity.activeVersionNumber
            )
        }
    }

    val storageStats: Flow<StorageStats> = dao.getStats().map { entity ->
        if (entity == null) StorageStats()
        else StorageStats(
            totalIndexedFiles = entity.totalIndexedFiles,
            totalIndexedSizeBytes = entity.totalIndexedSizeBytes,
            shadowVersionsCount = entity.shadowVersionsCount,
            duplicatesCleanedCount = entity.duplicatesCleanedCount,
            bytesSaved = entity.bytesSaved,
            lastScanTimestamp = entity.lastScanTimestamp,
            isMonitoringActive = entity.isMonitoringActive
        )
    }

    suspend fun runFullScanAndCleanup() = withContext(Dispatchers.IO) {
        val rootDirs = getTargetDirectories()
        var totalIndexedFiles = 0
        var totalIndexedSizeBytes = 0L
        var duplicatesCleaned = 0
        var bytesSaved = 0L
        var shadowVersionsCreated = 0

        val existingStats = dao.getStatsSync() ?: AppStatsEntity()

        // Step 1: Discover & Index Files
        val foundFiles = mutableListOf<File>()
        for (dir in rootDirs) {
            if (dir.exists() && dir.isDirectory) {
                dir.walkTopDown().filter { it.isFile }.forEach { file ->
                    foundFiles.add(file)
                }
            }
        }

        // Pre-populate mock samples if filesystem is minimal (e.g., sandbox environment)
        if (foundFiles.isEmpty()) {
            populateSampleFiles(rootDirs.firstOrNull() ?: context.filesDir)
            rootDirs.forEach { dir ->
                if (dir.exists()) {
                    dir.walkTopDown().filter { it.isFile }.forEach { foundFiles.add(it) }
                }
            }
        }

        // Step 2: Group by canonical name to detect version strings (e.g. file.pdf, file (1).pdf, file (2).pdf)
        val fileGroups = foundFiles.groupBy { extractCanonicalName(it.name) }

        for ((canonicalName, filesInGroup) in fileGroups) {
            val sortedByMod = filesInGroup.sortedByDescending { it.lastModified() }
            val latestFile = sortedByMod.first()
            val fileHash = computeSHA256(latestFile)
            val fileId = UUID.nameUUIDFromBytes(canonicalName.toByteArray()).toString()

            val existingEntity = dao.getFileById(fileId)
            val isProtected = existingEntity?.isProtected ?: false

            // Extract content preview for Everything indexing
            val snippet = extractTextSnippet(latestFile)

            val indexedEntity = IndexedFileEntity(
                id = fileId,
                canonicalName = canonicalName,
                currentPath = latestFile.absolutePath,
                extension = latestFile.extension.lowercase(),
                sizeBytes = latestFile.length(),
                contentHash = fileHash,
                lastModified = latestFile.lastModified(),
                creationTime = latestFile.lastModified() - 86400000L, // baseline creation estimate
                isProtected = isProtected,
                contentSnippet = snippet,
                activeVersionNumber = sortedByMod.size
            )
            dao.insertOrUpdateFile(indexedEntity)

            totalIndexedFiles++
            totalIndexedSizeBytes += latestFile.length()

            // Step 3: Handle Versions & Deduplication
            val existingVersions = dao.getVersionsForFileSync(fileId).toMutableList()

            for ((index, file) in sortedByMod.withIndex()) {
                val currentHash = computeSHA256(file)
                val versionNumber = sortedByMod.size - index

                // Deduplication check: if file is byte-for-byte identical duplicate to primary
                if (index > 0 && currentHash == fileHash) {
                    // Exact duplicate -> remove duplicate file to save space if not protected
                    if (!isProtected && file.exists()) {
                        bytesSaved += file.length()
                        duplicatesCleaned++
                        file.delete()
                    }
                } else {
                    // Store as Shadow Volume Version
                    val versionId = UUID.nameUUIDFromBytes("${fileId}_v${versionNumber}".toByteArray()).toString()
                    val versionEntity = FileVersionEntity(
                        versionId = versionId,
                        fileId = fileId,
                        versionNumber = versionNumber,
                        filePath = file.absolutePath,
                        sizeBytes = file.length(),
                        contentHash = currentHash,
                        timestamp = file.lastModified(),
                        isProtected = false,
                        note = if (index == 0) "Active primary" else "Shadow snapshot"
                    )
                    dao.insertVersion(versionEntity)
                    shadowVersionsCreated++
                }
            }

            // Step 4: Interval & Size Retention Cleanup (+10 Days & max 10 versions for <5MB)
            applyRetentionRules(fileId, latestFile.length())
        }

        // Step 5: Update App Stats
        dao.updateStats(
            AppStatsEntity(
                id = 1,
                totalIndexedFiles = totalIndexedFiles,
                totalIndexedSizeBytes = totalIndexedSizeBytes,
                shadowVersionsCount = shadowVersionsCreated + existingStats.shadowVersionsCount,
                duplicatesCleanedCount = duplicatesCleaned + existingStats.duplicatesCleanedCount,
                bytesSaved = bytesSaved + existingStats.bytesSaved,
                lastScanTimestamp = System.currentTimeMillis(),
                isMonitoringActive = true
            )
        )
    }

    private suspend fun applyRetentionRules(fileId: String, primarySizeBytes: Long) {
        val versions = dao.getVersionsForFileSync(fileId).sortedByDescending { it.versionNumber }
        val now = System.currentTimeMillis()

        // Rule: Max 10 versions allowed only for files < 5MB
        val maxAllowed = if (primarySizeBytes <= MAX_FILE_SIZE_FOR_VERSIONING) MAX_VERSIONS_PER_FILE else 3

        var currentCount = 0
        for (v in versions) {
            currentCount++
            val ageMs = now - v.timestamp

            // Check if version is expired (+10 days relative to creation/mod date) or exceeds max count
            val isExpiredByAge = ageMs > RETENTION_PERIOD_MS
            val isExceedingMax = currentCount > maxAllowed

            if ((isExpiredByAge || isExceedingMax) && !v.isProtected && v.versionNumber > 1) {
                // Delete expired shadow version file if exists
                val f = File(v.filePath)
                if (f.exists() && f.absolutePath != dao.getFileById(fileId)?.currentPath) {
                    f.delete()
                }
                dao.deleteVersion(v.versionId)
            }
        }
    }

    suspend fun toggleFileProtection(fileId: String, isProtected: Boolean) = withContext(Dispatchers.IO) {
        dao.updateProtection(fileId, isProtected)
    }

    suspend fun toggleVersionProtection(versionId: String, isProtected: Boolean) = withContext(Dispatchers.IO) {
        dao.updateVersionProtection(versionId, isProtected)
    }

    suspend fun setActiveVersion(fileId: String, versionNumber: Int) = withContext(Dispatchers.IO) {
        val versions = dao.getVersionsForFileSync(fileId)
        val selectedVersion = versions.find { it.versionNumber == versionNumber }
        if (selectedVersion != null) {
            val fileEntity = dao.getFileById(fileId)
            if (fileEntity != null) {
                dao.insertOrUpdateFile(
                    fileEntity.copy(
                        currentPath = selectedVersion.filePath,
                        sizeBytes = selectedVersion.sizeBytes,
                        contentHash = selectedVersion.contentHash,
                        lastModified = selectedVersion.timestamp,
                        activeVersionNumber = versionNumber
                    )
                )
            }
        }
    }

    private fun getTargetDirectories(): List<File> {
        val dirs = mutableListOf<File>()
        // Download dir
        val downloads = File(context.getExternalFilesDir(null), "Downloads").apply { mkdirs() }
        dirs.add(downloads)
        // Main App documents dir
        val docs = File(context.filesDir, "Documents").apply { mkdirs() }
        dirs.add(docs)
        return dirs
    }

    private fun extractCanonicalName(filename: String): String {
        val dotIndex = filename.lastIndexOf('.')
        val nameWithoutExt = if (dotIndex > 0) filename.substring(0, dotIndex) else filename
        val ext = if (dotIndex > 0) filename.substring(dotIndex) else ""

        // Strip pattern like " (1)", " (2)", "_v2", "-copy"
        val pattern = Pattern.compile("(?i)(\\s*\\(\\d+\\)|_v\\d+|-copy)$")
        val cleanedName = pattern.matcher(nameWithoutExt).replaceAll("")
        return "$cleanedName$ext"
    }

    private fun computeSHA256(file: File): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val inputStream: InputStream = file.inputStream()
            val buffer = ByteArray(8192)
            var bytesRead: Int
            while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                digest.update(buffer, 0, bytesRead)
            }
            inputStream.close()
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            file.name + "_" + file.length()
        }
    }

    private fun extractTextSnippet(file: File): String {
        val ext = file.extension.lowercase()
        return try {
            if (ext in listOf("txt", "json", "md", "csv", "xml", "html", "log")) {
                file.readText().take(300)
            } else {
                "Indexed binary file [${file.extension.uppercase()}]"
            }
        } catch (e: Exception) {
            "Indexed binary object"
        }
    }

    private fun populateSampleFiles(dir: File) {
        try {
            dir.mkdirs()
            // Sample 1: Project Report versions
            val f1 = File(dir, "Q3_Financial_Report.pdf")
            if (!f1.exists()) f1.writeText("Q3 Financial Report - Final Draft v1. Includes Q3 revenue projections.")

            val f2 = File(dir, "Q3_Financial_Report (1).pdf")
            if (!f2.exists()) f2.writeText("Q3 Financial Report - Final Draft v2. Updated EBITDA numbers.")

            val f3 = File(dir, "Q3_Financial_Report (2).pdf")
            if (!f3.exists()) f3.writeText("Q3 Financial Report - Final Draft v2. Updated EBITDA numbers.") // Identical duplicate!

            // Sample 2: Design Asset
            val f4 = File(dir, "app_architecture_diagram.png")
            if (!f4.exists()) f4.writeBytes(ByteArray(1024 * 12) { 0x41 })

            val f5 = File(dir, "app_architecture_diagram (1).png")
            if (!f5.exists()) f5.writeBytes(ByteArray(1024 * 12) { 0x41 }) // Duplicate PNG

            // Sample 3: Code / Notes
            val f6 = File(dir, "meeting_notes_august.txt")
            if (!f6.exists()) f6.writeText("Sprint Planning: Implement Everything search indexer & Borderline SDK capsule integration.")

            val f7 = File(dir, "backup_config.json")
            if (!f7.exists()) f7.writeText("{\"version\": 4, \"auto_clean\": true, \"retention_days\": 10}")

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
