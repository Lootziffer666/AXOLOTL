package com.example.model

data class FileItem(
    val id: String,
    val canonicalName: String,
    val currentPath: String,
    val extension: String,
    val sizeBytes: Long,
    val contentHash: String,
    val lastModified: Long,
    val creationTime: Long,
    val isProtected: Boolean = false,
    val contentSnippet: String = "",
    val versions: List<FileVersion> = emptyList(),
    val isDuplicate: Boolean = false,
    val activeVersionNumber: Int = 1
)

data class FileVersion(
    val versionId: String,
    val fileId: String,
    val versionNumber: Int,
    val filePath: String,
    val sizeBytes: Long,
    val contentHash: String,
    val timestamp: Long,
    val isProtected: Boolean = false,
    val note: String = ""
)

data class StorageStats(
    val totalIndexedFiles: Int = 0,
    val totalIndexedSizeBytes: Long = 0L,
    val shadowVersionsCount: Int = 0,
    val duplicatesCleanedCount: Int = 0,
    val bytesSaved: Long = 0L,
    val lastScanTimestamp: Long = 0L,
    val isMonitoringActive: Boolean = true
)
