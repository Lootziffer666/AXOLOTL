package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "indexed_files")
data class IndexedFileEntity(
    @PrimaryKey val id: String,
    val canonicalName: String,
    val currentPath: String,
    val extension: String,
    val sizeBytes: Long,
    val contentHash: String,
    val lastModified: Long,
    val creationTime: Long,
    val isProtected: Boolean = false,
    val contentSnippet: String = "",
    val activeVersionNumber: Int = 1
)

@Entity(tableName = "file_versions")
data class FileVersionEntity(
    @PrimaryKey val versionId: String,
    val fileId: String,
    val versionNumber: Int,
    val filePath: String,
    val sizeBytes: Long,
    val contentHash: String,
    val timestamp: Long,
    val isProtected: Boolean = false,
    val note: String = ""
)

@Entity(tableName = "app_stats")
data class AppStatsEntity(
    @PrimaryKey val id: Int = 1,
    val totalIndexedFiles: Int = 0,
    val totalIndexedSizeBytes: Long = 0L,
    val shadowVersionsCount: Int = 0,
    val duplicatesCleanedCount: Int = 0,
    val bytesSaved: Long = 0L,
    val lastScanTimestamp: Long = 0L,
    val isMonitoringActive: Boolean = true
)
