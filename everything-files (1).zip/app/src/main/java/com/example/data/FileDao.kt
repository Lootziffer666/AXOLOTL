package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface FileDao {
    @Query("SELECT * FROM indexed_files ORDER BY lastModified DESC")
    fun getAllFiles(): Flow<List<IndexedFileEntity>>

    @Query("SELECT * FROM indexed_files WHERE canonicalName LIKE '%' || :query || '%' OR contentSnippet LIKE '%' || :query || '%' ORDER BY lastModified DESC")
    fun searchFiles(query: String): Flow<List<IndexedFileEntity>>

    @Query("SELECT * FROM indexed_files WHERE id = :fileId LIMIT 1")
    suspend fun getFileById(fileId: String): IndexedFileEntity?

    @Query("SELECT * FROM indexed_files WHERE contentHash = :hash")
    suspend fun getFilesByHash(hash: String): List<IndexedFileEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateFile(file: IndexedFileEntity)

    @Query("DELETE FROM indexed_files WHERE id = :fileId")
    suspend fun deleteFile(fileId: String)

    @Query("UPDATE indexed_files SET isProtected = :isProtected WHERE id = :fileId")
    suspend fun updateProtection(fileId: String, isProtected: Boolean)

    @Query("UPDATE indexed_files SET activeVersionNumber = :versionNumber WHERE id = :fileId")
    suspend fun updateActiveVersion(fileId: String, versionNumber: Int)

    @Query("SELECT * FROM file_versions WHERE fileId = :fileId ORDER BY versionNumber DESC")
    fun getVersionsForFile(fileId: String): Flow<List<FileVersionEntity>>

    @Query("SELECT * FROM file_versions WHERE fileId = :fileId ORDER BY versionNumber DESC")
    suspend fun getVersionsForFileSync(fileId: String): List<FileVersionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVersion(version: FileVersionEntity)

    @Query("DELETE FROM file_versions WHERE versionId = :versionId")
    suspend fun deleteVersion(versionId: String)

    @Query("UPDATE file_versions SET isProtected = :isProtected WHERE versionId = :versionId")
    suspend fun updateVersionProtection(versionId: String, isProtected: Boolean)

    @Query("SELECT * FROM app_stats WHERE id = 1 LIMIT 1")
    fun getStats(): Flow<AppStatsEntity?>

    @Query("SELECT * FROM app_stats WHERE id = 1 LIMIT 1")
    suspend fun getStatsSync(): AppStatsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun updateStats(stats: AppStatsEntity)
}
