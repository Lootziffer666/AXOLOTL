package com.example

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.example.data.DockDatabase
import com.example.data.DockRepository
import com.example.data.SettingsManager
import com.example.data.SnippetEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ShortcutActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val data = intent.data

        val database = DockDatabase.getDatabase(this)
        val repository = DockRepository(
            database.dockAppDao(),
            database.dockItemDao(),
            database.snippetDao(),
            database.clipDao()
        )
        val settingsManager = SettingsManager.getInstance(this)
        val scope = CoroutineScope(Dispatchers.IO)

        if (data != null && data.scheme == "borderline") {
            when (data.host) {
                "open" -> {
                    val menuStr = data.getQueryParameter("menu") ?: "0"
                    val menuIndex = menuStr.toIntOrNull() ?: 0
                    openBorderlineMenu(this, menuIndex)
                }
                "add-snippet" -> {
                    val title = data.getQueryParameter("title") ?: "Shortcut Snippet"
                    val content = data.getQueryParameter("content") ?: ""
                    val category = data.getQueryParameter("category") ?: "Prompt"
                    if (content.isNotBlank()) {
                        scope.launch {
                            repository.insertSnippet(SnippetEntity(title = title, content = content, category = category))
                        }
                        Toast.makeText(this, "Snippet saved to Borderline!", Toast.LENGTH_SHORT).show()
                    }
                }
                "appendix" -> {
                    val text = data.getQueryParameter("text") ?: ""
                    if (text.isNotBlank()) {
                        settingsManager.appendToAppendix(text)
                        Toast.makeText(this, "Appended to Borderline Appendix!", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        } else {
            val menuIndex = intent.getIntExtra("menu_index", 0)
            openBorderlineMenu(this, menuIndex)
        }

        finish()
    }

    private fun openBorderlineMenu(context: Context, menuIndex: Int) {
        val intent = Intent(context, DockOverlayService::class.java).apply {
            action = DockOverlayService.ACTION_OPEN_MENU
            putExtra(DockOverlayService.EXTRA_MENU_INDEX, menuIndex)
        }
        context.startForegroundService(intent)
    }
}
